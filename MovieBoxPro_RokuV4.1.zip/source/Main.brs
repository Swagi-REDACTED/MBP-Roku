'*************************************************************
'** Hello World example 
'** Copyright (c) 2015 Roku, Inc.  All rights reserved.
'** Use of the Roku Platform is subject to the Roku SDK Licence Agreement:
'** https://docs.roku.com/doc/developersdk/en-us
'*************************************************************

sub Main()
    print "in showChannelSGScreen"
    'Indicate this is a Roku SceneGraph application'
    screen = CreateObject("roSGScreen")
    m.port = CreateObject("roMessagePort")
    screen.setMessagePort(m.port)

    'Create a scene and load /components/helloworld.xml'
    
    scene = screen.CreateScene("rootScene")
    screen.show()
    ' scene = screen.CreateScene("HelloWorld")
    ' screen.show()
    scene.observeField("exitApp", m.port)

    ' remoteFileUrl = "https://usa7-cache9-1.shegu.net/vip/p1/speedtest/test100MB.bin?KEY1=qztB11vlMfa26l5FmJf9jA&KEY2=1704279305"

    ' ' 创建 roUrlTransfer 对象
    ' urlTransfer = CreateObject("roUrlTransfer")

    ' ' 设置URL
    ' urlTransfer.SetUrl(remoteFileUrl)
    ' urlTransfer.EnablePeerVerification(false)
    ' urlTransfer.EnableHostVerification(false)

    ' port = CreateObject("roMessagePort")
    ' urlTransfer.SetMessagePort(port)

    ' urlTransfer.AsyncGetToFile("tmp:/test100MB.bin")
    ' ' sleep(6)
    ' ' urlTransfer.AsyncCancel()
    ' msg = Wait(10000, urlTransfer.GetPort())
    ' ba = CreateObject("roByteArray")
    ' ba.ReadFile("tmp:/test100MB.bin")
    ' ' print ba

    ' numBytes = ba.Count()
    ' print numBytes
    ' 启动下载
    ' if urlTransfer.AsyncGetToFile("tmp:/test100MB.bin") then
    '     ' 下载进行的时间（秒）
    '     downloadDuration = 100 ' 设置下载时间为6秒

    '     ' 定期测量下载速度
    '     for i = 1 to downloadDuration
    '         sleep(1000) ' 等待1秒

    '         ' 获取当前传输的字节数
    '         ' response = urlTransfer.GetToFile()
    '         ' print response
    '         ' currentBytesTransferred = urlTransfer.GetTransferBytes()
    '         ba = CreateObject("roByteArray")
    '         ba.ReadFile("tmp:/test100MB.bin")
    '         print ba

    '         numBytes = ba.Count()
    '         print numBytes

    '         ' 计算下载速度（字节/秒）
    '         downloadSpeed = CalculateDownloadSpeed(numBytes, i)
    '         print "当前下载速度: " + downloadSpeed.ToStr() + " bytes/秒"
    '     end for

    '     ' 取消下载
    '     print "1234"
    '     ' urlTransfer.AsyncCancel()
    ' else
    '     print "无法启动下载。"
    ' end if

    while(true)
        msg = wait(0, m.port)
        msgType = type(msg)
        ' print msgType
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if msgType = "roSGNodeEvent" then
            field = msg.getField()
            if field = "exitApp" then
              return
            end if
        end if
    end while
end sub