'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

sub Init()
    m.setbg = m.top.findNode("settingbg")

    setbgplerect = m.setbg.boundingRect()
    centerx = (1280 - setbgplerect.width) / 2
    centery = (720 - setbgplerect.height) / 2
    m.setbg.translation = [ centerx, centery ]
    
    m.btn2 = m.top.findNode("btn2")
    m.btn2_text = m.top.findNode("btn_text")
    m.btn_skip = m.top.findNode("btn_skip")
    m.btn_skip_text = m.top.findNode("btn_skip_text")
    m.btn_episodes = m.top.findNode("btn_episodes")
    m.btn_episodes_text = m.top.findNode("btn_episodes_text")
    m.typelist = m.top.findNode("Typelist")

    m.qualitys = m.top.findNode("qualitys")
    m.audios = m.top.findNode("audios")
    m.audiolist = m.top.findNode("audiolist")
    m.subtitles = m.top.findNode("subtitles")

    m.categoryList = m.top.FindNode("categoryList")
    m.itemsList = m.top.FindNode("itemsList")
    m.subtitle_ops = m.top.FindNode("subtitle_ops")
    m.srt_view_title = m.top.FindNode("srt_view_title")
    m.srt_view_status = m.top.FindNode("srt_view_status")
    
    m.sub_settingbg = m.top.FindNode("sub_settingbg")
    m.subtitle_btns = m.top.FindNode("subtitle_btns")
    m.subtitle_delaybg = m.top.FindNode("subtitle_delaybg")
    m.srt_time = m.top.FindNode("srt_time")
    m.subtitle_delay = m.top.FindNode("subtitle_delay")
    m.subtitle_appearancebg = m.top.FindNode("subtitle_appearancebg")
    m.srt_bg_opacity = m.top.FindNode("srt_bg_opacity")
    m.srt_text_opacity = m.top.FindNode("srt_text_opacity")
    m.subtitle_bg_opacity = m.top.FindNode("subtitle_bg_opacity")
    m.subtitle_text_opacity = m.top.FindNode("subtitle_text_opacity")
    m.subtitle_sizebg = m.top.FindNode("subtitle_sizebg")
    m.srt_size = m.top.FindNode("srt_size")
    m.subtitle_size = m.top.FindNode("subtitle_size")
    m.font_list = m.top.FindNode("font_list")
    m.subtitle_movebg = m.top.FindNode("subtitle_movebg")
    m.subtitle_move = m.top.FindNode("subtitle_move")

    m.opensubtitles = m.top.FindNode("opensubtitles")
    m.tip_text = m.top.FindNode("tip_text")
    m.langlist2 = m.top.FindNode("langlist")
    m.more = m.top.FindNode("more")
    m.srtlist2 = m.top.FindNode("srtlist")
    m.langlist2.ObserveField("itemFocused", "getSearchSrt")
    m.srtlist2.ObserveField("itemSelected", "getsrtfile")
    m.more.ObserveField("itemSelected", "lang_more")
    m.languages = m.top.FindNode("languages")
    m.letters = m.top.FindNode("langs")
    m.letters.ObserveField("itemFocused", "getlanguage")
    m.language_list = m.top.FindNode("language_list")
    m.language_list.ObserveField("itemSelected", "getSearchSrt2")
    m.srt_viewbg = m.top.FindNode("srt_viewbg")
    m.srt_content = m.top.FindNode("srt_content")
    m.srt_btns = m.top.FindNode("srt_btns")
    m.srt_btns.ObserveField("itemSelected", "srtoperate")

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "More"
    m.more.content = contentRoot2

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Done"
    m.srt_btns.content = contentRoot2
    m.lang_pick_mode = "opensubtitle"
    m.srt_preview_mode = "opensubtitle"

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Preview"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Translate"
    if m.subtitle_ops <> invalid
        m.subtitle_ops.content = contentRoot2
        m.subtitle_ops.ObserveField("itemSelected", "subtitle_list_operate")
    end if

    m.default = [
                {"code":"en", "name":"English"},
                {"code":"fr", "name":"French"},
                {"code":"de", "name":"German"},
                {"code":"it", "name":"Italian"},
                {"code":"es", "name":"Spanish"},
                {"code":"ar", "name":"Arabic"},
                {"code":"tr", "name":"Turkish"},
                {"code":"ru", "name":"Russian"},
                {"code":"th", "name":"Thai"},
                {"code":"in", "name":"Indonesian"},
                {"code":"zh-CN", "name":"Chinese (Simplified)"},
                {"code":"pt", "name":"Portuguese"},
                {"code":"hi", "name":"Hindi"},
                {"code":"ja", "name":"Japanese"},
                {"code":"kr", "name":"Korean"}
            ]

    m.langs = [{"lang":"en","language":"English"},{"lang":"zh-CN","language":"Chinese (Simplified)"},{"lang":"zh-TW","language":"Chinese (Traditional)"},{"lang":"ja","language":"Japanese"},{"lang":"fr","language":"French"},{"lang":"ru","language":"Russian"},{"lang":"es","language":"Spanish"},{"lang":"ar","language":"Arabic"},{"lang":"af","language":"Afrikaans"},{"lang":"agq","language":"Aghem"},{"lang":"ak","language":"Akan"},{"lang":"sq","language":"Albanian"},{"lang":"am","language":"Amharic"},{"lang":"hy","language":"Armenian"},{"lang":"as","language":"Assamese"},{"lang":"asa","language":"Asu"},{"lang":"ay","language":"Aymara"},{"lang":"az","language":"Azerbaijani"},{"lang":"bm","language":"Bambara"},{"lang":"eu","language":"Basque"},{"lang":"bm","language":"Bambara"},{"lang":"be","language":"Belarusian"},{"lang":"bem","language":"Bemba"},{"lang":"bez","language":"Bena"},{"lang":"bn","language":"Bengali"},{"lang":"bho","language":"Bhojpuri"},{"lang":"brx","language":"Bodo"},{"lang":"bs","language":"Bosnian"},{"lang":"br","language":"Breton"},{"lang":"bg","language":"Bulgarian"},{"lang":"my","language":"Burmese"},{"lang":"ca","language":"Catalan"},{"lang":"tzm","language":"Tamazight"},{"lang":"ceb","language":"Cebuano"},{"lang":"chr","language":"Cherokee"},{"lang":"cgg","language":"Chiga"},{"lang":"kw","language":"Cornish"},{"lang":"co","language":"Corsican"},{"lang":"hr","language":"Croatian"},{"lang":"cs","language":"Czech"},{"lang":"da","language":"Danish"},{"lang":"dv","language":"Dhivehi"},{"lang":"doi","language":"Dogri"},{"lang":"dua","language":"Duala"},{"lang":"nl","language":"Dutch"},{"lang":"dz","language":"Dzongkha"},{"lang":"ebu","language":"Embu"},{"lang":"eo","language":"Esperanto"},{"lang":"et","language":"Estonian"},{"lang":"ee","language":"Ewe"},{"lang":"ewo","language":"Ewondo"},{"lang":"fo","language":"Faroese"},{"lang":"fil","language":"Filipino"},{"lang":"fi","language":"Finnish"},{"lang":"fy","language":"Frisian"},{"lang":"ff","language":"Fulah"},{"lang":"gl","language":"Galician"},{"lang":"lg","language":"Ganda"},{"lang":"ka","language":"Georgian"},{"lang":"el","language":"Greek"},{"lang":"gn","language":"Guarani"},{"lang":"gu","language":"Gujarati"},{"lang":"guz","language":"Gusii"},{"lang":"ha","language":"Hausa"},{"lang":"ht","language":"Haitian Creole"},{"lang":"haw","language":"Hawaiian"},{"lang":"iw","language":"Hebrew"},{"lang":"hi","language":"Hindi"},{"lang":"hmn","language":"Hmong"},{"lang":"hu","language":"Hungarian"},{"lang":"is","language":"Icelandic"},{"lang":"ig","language":"Igbo"},{"lang":"ilo","language":"Ilocano"},{"lang":"in","language":"Indonesian"},{"lang":"ga","language":"Irish"},{"lang":"ga","language":"Irish"},{"lang":"it","language":"Italian"},{"lang":"jv","language":"Javanese"},{"lang":"dyo","language":"Jola-Fonyi"},{"lang":"kea","language":"Kabuverdianu"},{"lang":"kab","language":"Kabyle"},{"lang":"kl","language":"Kalaallisut"},{"lang":"kam","language":"Kamba"},{"lang":"kn","language":"Kannada"},{"lang":"ks","language":"Kashmiri"},{"lang":"kk","language":"Kazakh"},{"lang":"km","language":"Khmer"},{"lang":"ki","language":"Kikuyu"},{"lang":"rw","language":"Kinyarwanda"},{"lang":"ko","language":"Korean"},{"lang":"gom","language":"Konkani"},{"lang":"khq","language":"Koyra Chiini"},{"lang":"kri","language":"Krio"},{"lang":"nmg","language":"Kwasio"},{"lang":"ky","language":"Kyrgyz"},{"lang":"lkt","language":"Lakota"},{"lang":"lo","language":"Lao"},{"lang":"lv","language":"Latvian"},{"lang":"la","language":"Latin"},{"lang":"ln","language":"Lingala"},{"lang":"lt","language":"Lithuanian"},{"lang":"lu","language":"Luba-Katanga"},{"lang":"lb","language":"Luxembourgish"},{"lang":"mk","language":"Macedonian"},{"lang":"jmc","language":"Machame"},{"lang":"mai","language":"Maithili"},{"lang":"kde","language":"Makonde"},{"lang":"mg","language":"Malagasy"},{"lang":"ms","language":"Malay"},{"lang":"ml","language":"Malayalam"},{"lang":"mt","language":"Maltese"},{"lang":"gv","language":"Manx"},{"lang":"mr","language":"Marathi"},{"lang":"mi","language":"Maori"},{"lang":"mas","language":"Masai"},{"lang":"mer","language":"Meru"},{"lang":"mni-Mtei","language":"Meiteilon (Manipuri)"},{"lang":"lus","language":"Mizo"},{"lang":"mn","language":"Mongolian"},{"lang":"mfe","language":"Morisyen"},{"lang":"mua","language":"Mundang"},{"lang":"naq","language":"Nama"},{"lang":"ne","language":"Nepali"},{"lang":"jgo","language":"Ngomba"},{"lang":"nd","language":"North Ndebele"},{"lang":"nb","language":"Norwegian Bokm\u00e5l"},{"lang":"nn","language":"Norwegian Nynorsk"},{"lang":"nus","language":"Nuer"},{"lang":"nyn","language":"Nyankole"},{"lang":"ny","language":"Nyanja (Chichewa)"},{"lang":"or","language":"Oriya"},{"lang":"om","language":"Oromo"},{"lang":"ps","language":"Pashto"},{"lang":"fa","language":"Persian"},{"lang":"pl","language":"Polish"},{"lang":"pt","language":"Portuguese"},{"lang":"pb","language":"Portuguese (BR)"},{"lang":"pa","language":"Punjabi"},{"lang":"qu","language":"Quechua"},{"lang":"ro","language":"Romanian"},{"lang":"rm","language":"Romansh"},{"lang":"rn","language":"Rundi"},{"lang":"ja","language":"sabra"},{"lang":"saq","language":"Samburu"},{"lang":"sm","language":"Samoan"},{"lang":"sg","language":"Sango"},{"lang":"sbp","language":"Sangu"},{"lang":"sa","language":"Sanskrit"},{"lang":"gd","language":"Scots Gaelic"},{"lang":"nso","language":"Sepedi"},{"lang":"she","language":"Sena"},{"lang":"sr","language":"Serbian"},{"lang":"st","language":"Sesotho"},{"lang":"ksb","language":"Shambala"},{"lang":"sn","language":"Shona"},{"lang":"ii","language":"Sichuan Yi"},{"lang":"sd","language":"Sindhi"},{"lang":"si","language":"Sinhala"},{"lang":"sk","language":"Slovak"},{"lang":"sl","language":"Slovenian"},{"lang":"xog","language":"Soga"},{"lang":"so","language":"Somali"},{"lang":"zgh","language":"Standard Moroccan Tamazight"},{"lang":"su","language":"Sundanese"},{"lang":"sw","language":"Swahili"},{"lang":"sv","language":"Swedish"},{"lang":"gsw","language":"Swiss German"},{"lang":"shi","language":"Tachelhit"},{"lang":"dav","language":"Taita"},{"lang":"tg","language":"Tajik"},{"lang":"ta","language":"Tamil"},{"lang":"tt","language":"Tatar"},{"lang":"twq","language":"Tasawaq"},{"lang":"te","language":"Telugu"},{"lang":"th","language":"Thai"},{"lang":"bo","language":"Tibetan"},{"lang":"ti","language":"Tigrinya"},{"lang":"to","language":"Tongan"},{"lang":"tr","language":"Turkish"},{"lang":"tk","language":"Turkmen"},{"lang":"ts","language":"Tsonga"},{"lang":"uk","language":"Ukrainian"},{"lang":"ur","language":"Urdu"},{"lang":"ug","language":"Uyghur"},{"lang":"uz","language":"Uzbek"},{"lang":"vai","language":"Vai"},{"lang":"vi","language":"Vietnamese"},{"lang":"vun","language":"Vunjo"},{"lang":"cy","language":"Welsh"},{"lang":"xh","language":"Xhosa"},{"lang":"yav","language":"Yangben"},{"lang":"yi","language":"Yiddish"},{"lang":"yo","language":"Yoruba"},{"lang":"dje","language":"Zarma"},{"lang":"zu","language":"Zulu"}]
    m.lang_lists = {}
    for each key in m.langs
        m.lang_lists[key.lang] = key.language
    end for

    m.langs2 = SplitArrayByFirstLetter(m.langs, "language")

    ' typelist2 = m.typelist

    ' focusedTargetSet1 = createObject("roSGNode", "TargetSet")
    ' focusedTargetSet2 = createObject("roSGNode", "TargetSet")
    ' ' focusedTargetSet3 = createObject("roSGNode", "TargetSet")
    ' ' focusedTargetSet4 = createObject("roSGNode", "TargetSet")
    ' typelist2.focusedTargetSet = [ focusedTargetSet1, focusedTargetSet2 ]
    ' ' m.typelist.focusedTargetSet = focusedTargetSet

    ' focusedTargetSet1.targetRects = [
    '     { x:-170, y:-30, height:55, width:150 },
    '     { x:0, y:-30, height:55, width:150 },
    '     { x:170, y:-30, height:55, width:150 },
    '     { x:340, y:-30, height:55, width:150 }
    ' ]
    ' focusedTargetSet1.color = "0x00202020AA"
    ' focusedTargetSet1.focusIndex = 0

    ' focusedTargetSet2.targetRects = [
    '     { x:-170, y:-30, height:55, width:150 },
    '     { x:0, y:-30, height:55, width:150 },
    '     { x:170, y:-30, height:55, width:150 },
    '     { x:340, y:-30, height:55, width:150 }
    ' ]
    ' focusedTargetSet2.color = "0x00202020AA"
    ' focusedTargetSet2.focusIndex = 1

    ' focusedTargetSet3.targetRects = [
    '     { x:-170, y:-30, height:55, width:150 },
    '     { x:0, y:-30, height:55, width:150 },
    '     { x:170, y:-30, height:55, width:150 },
    '     { x:340, y:-30, height:55, width:150 }
    ' ]
    ' focusedTargetSet3.color = "0x00202020AA"
    ' focusedTargetSet3.focusIndex = 2

    ' focusedTargetSet4.targetRects = [
    '     { x:-170, y:-30, height:55, width:150 },
    '     { x:0, y:-30, height:55, width:150 },
    '     { x:170, y:-30, height:55, width:150 },
    '     { x:340, y:-30, height:55, width:150 }
    ' ]
    ' focusedTargetSet4.color = "0x00202020AA"
    ' focusedTargetSet4.focusIndex = 3

    ' m.typelist.targetSet = typelist2.focusedTargetSet[0]
    ' ' m.typelist.showTargetRects = true
    ' m.typelist.duration = 0
    ' m.typelist.itemComponentName = "TypeItemComponent"

    contentRoot = createObject("roSGNode", "ContentNode")
    m.type_panel_map = invalid
    m.audio_tab_visible = false
    m.audio_tracks_known = false
    m.audio_tracks_signature = invalid
    m.suppress_tab_change = false
    m.videoNode = invalid
    m.video_tracks_observer_set = false
    m.top.observeField("videoNode", "onVideoNodeSet")
    m.top.observeField("audioStreamUrl", "onAudioStreamUrlChanged")
    video_setting_update_type_tabs()
    m.typelist.ObserveField("itemFocused", "on_type_tab_changed")
    m.typelist.ObserveField("itemSelected", "getsubtitles")

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Subtitle Delay"
    child2.hdposterurl = "pkg:/images/tortoise2.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Subtitle Size"
    child2.hdposterurl = "pkg:/images/subtitle_size.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Subtitle Move"
    child2.hdposterurl = "pkg:/images/subtitle_move.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Appearance"
    child2.hdposterurl = "pkg:/images/setting.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "Subtitles Off"
    child2.hdposterurl = "pkg:/images/srt_close.png"
    m.subtitle_btns.content = contentRoot2
    m.subtitle_btns.ObserveField("itemSelected", "subtitle_operate")

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "jian"
    child2.hdposterurl = "pkg:/images/jian_black.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "jia"
    child2.hdposterurl = "pkg:/images/jia.png"
    m.subtitle_delay.content = contentRoot2

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "decrease"
    child2.hdposterurl = "pkg:/images/jian_black.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "increase"
    child2.hdposterurl = "pkg:/images/jia.png"
    m.subtitle_bg_opacity.content = contentRoot2

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "decrease"
    child2.hdposterurl = "pkg:/images/jian_black.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "increase"
    child2.hdposterurl = "pkg:/images/jia.png"
    m.subtitle_text_opacity.content = contentRoot2

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "jian"
    child2.hdposterurl = "pkg:/images/jian_black.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "jia"
    child2.hdposterurl = "pkg:/images/jia.png"
    m.subtitle_size.content = contentRoot2

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "up"
    child2.hdposterurl = "pkg:/images/up_black.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "down"
    child2.hdposterurl = "pkg:/images/down.png"
    m.subtitle_move.content = contentRoot2

    m.top.observeField("visible", "onPanelVisibleChanged")
end sub

sub onPanelVisibleChanged()
    if m.top.visible = true
        resetTopBarBtnStyle()
        video_setting_show_panel("video")
        updateAudioTabs()
        refreshAudioTracks()
    else
        ' Reset visual/modal state while hidden so the next Down press always
        ' opens a clean root settings card rather than a stale nested panel.
        if m.setbg <> invalid
            m.setbg.visible = true
        end if
        if m.sub_settingbg <> invalid
            m.sub_settingbg.visible = false
        end if
        if m.subtitle_delaybg <> invalid
            m.subtitle_delaybg.visible = false
        end if
        if m.subtitle_sizebg <> invalid
            m.subtitle_sizebg.visible = false
        end if
        if m.subtitle_movebg <> invalid
            m.subtitle_movebg.visible = false
        end if
        if m.subtitle_appearancebg <> invalid
            m.subtitle_appearancebg.visible = false
        end if
        if m.opensubtitles <> invalid
            m.opensubtitles.visible = false
        end if
        if m.languages <> invalid
            m.languages.visible = false
        end if
        if m.srt_viewbg <> invalid
            m.srt_viewbg.visible = false
        end if
        clearAudioTrackList()
    end if
end sub

sub resetTopBarBtnStyle()
    if m.btn2 <> invalid
        m.btn2.color = "0xffffff19"
        m.btn2_text.color = "0xddddddff"
    end if
    setIconBtnFocus(m.btn_skip, false)
    setIconBtnFocus(m.btn_episodes, false)
end sub

sub setIconBtnFocus(btn as Object, focused as Boolean)
    if btn = invalid
        return
    end if
    if focused = true
        btn.color = "0xFFFFFF3D"
    else
        btn.color = "0xffffff19"
    end if
end sub

sub OnContentChange()
    if m.qualitylist = invalid
        list = m.top.content
        v = 1
        k = 1
        k2 = 1
        qqq = 0
        for each item in list.list
            if item.select = 1
                v = K
                qqq = 1
                Exit for
            end if
            k = k + 1
        end for
        if qqq = 0
            for each item in list.list
                if item.quality = "1080p"
                    v = k2
                    qqq = 1
                    Exit for
                end if
                k2 = k2 + 1
            end for
        end if
        if qqq = 0 and list.list.Count() > 1
            if list.list[0].quality = "org"
                v = 2
            end if
        end if
        m.qualitylist = m.top.findNode("vlist")
        content = createObject("roSGNode", "ContentNode")
        q = 1
        for each item in list.list
            videoItem = content.createChild("ContentNode")
            if item.quality = "org"
                name = "ORG (Original Video File)"
            elseif item.quality = "4K"
                name = "UHD · 4K"
            elseif item.quality = "1080p"
                name = "FHD · 1080P"
            elseif item.quality = "720p"
                name = "HD · 720P"
            elseif item.quality = "360p"
                name = "SD · 360P"
            else
                name = item.quality
            end if
            videoItem.title = name
            videoItem.SecondaryTitle = "false"
            if q = v
                print videoItem
                videoItem.SecondaryTitle = "true"
            end if
            if item.DoesExist("bitstream") = false
                item["bitstream"] = "false"
            end if
            data = {"quality":item.quality,"size":item.size,"vip_only":item.vip_only,"h265":item.h265,"bitstream":item.bitstream}
            json = FormatJson(data)
            ba = CreateObject("roByteArray")
            ba.FromAsciiString(json)
            aa = ba.ToBase64String()
            videoItem.Description = aa
            q = q + 1
        end for
        m.qualitylist.content = content
        selectedIndex = v - 1
        if selectedIndex < 0
            selectedIndex = 0
        end if
        if content.getChildCount() > 0 and selectedIndex >= content.getChildCount()
            selectedIndex = content.getChildCount() - 1
        end if
        m.selected_quality_index = selectedIndex
        if content.getChildCount() > 0
            m.qualitylist.jumpToItem = selectedIndex
        end if
    end if
    if m.sublist <> invalid
        m.sublist = m.top.content.subtitle_list
    end if
    if m.top.content.subtitle_list <> invalid and m.sublist = invalid
        m.sublist = m.top.content.subtitle_list
        m.langlist = ConvertToContentNode(m.sublist.list)
        m.categoryList.content = m.langlist
        m.categoryList.ObserveField("itemFocused", "OnCategoryItemFocused")
        m.categoryList.ObserveField("itemSelected", "OnCategoryItemSelect")
        if m.sublist.list.Count() > 0
            ' m.sublist.list = DataSet(m.sublist.list)
            print(m.sublist)
            m.srtlist = ConvertToContentNode2(m.sublist.list[0].subtitles)
        else
            m.srtlist = ConvertToContentNode2([])
        end if
        m.itemsList.content = m.srtlist
    end if
    if m.top.content <> invalid and m.top.content.moviedata <> invalid and m.top.content.moviedata.box_type = 2
        m.btn_skip.visible = true
        m.btn_episodes.visible = true
    else
        m.btn_skip.visible = false
        m.btn_episodes.visible = false
    end if
end sub

function getActiveTabTitle() as String
    if m.typelist = invalid or m.typelist.content = invalid
        return ""
    end if
    if m.typelist.itemFocused < 0 or m.typelist.itemFocused >= m.typelist.content.getChildCount()
        return ""
    end if
    return m.typelist.content.getChild(m.typelist.itemFocused).title
end function

function video_setting_panel_id_at_index(idx as Integer) as String
    if m.type_panel_map = invalid or m.type_panel_map.Count() = 0
        return "video"
    end if
    if idx < 0
        idx = 0
    end if
    if idx >= m.type_panel_map.Count()
        idx = m.type_panel_map.Count() - 1
    end if
    return m.type_panel_map[idx]
end function

function video_setting_panel_id_at_focus() as String
    if m.typelist = invalid
        return "video"
    end if
    idx = m.typelist.itemFocused
    if idx = invalid
        idx = 0
    end if
    return video_setting_panel_id_at_index(idx)
end function

sub video_setting_apply_panel(panelId as String)
    if panelId = "video"
        video_setting_show_panel("video")
    else if panelId = "audio"
        video_setting_show_panel("audio")
    else if panelId = "subtitle"
        if shouldRefetchSubtitles()
            fetchSubtitleList()
            return
        end if
        if m.sublist <> invalid
            video_setting_show_panel("subtitle")
        else if m.top.content <> invalid and m.top.content.subtitle_list <> invalid
            m.sublist = m.top.content.subtitle_list
            m.langlist = ConvertToContentNode(m.sublist.list)
            m.categoryList.content = m.langlist
            m.categoryList.ObserveField("itemFocused", "OnCategoryItemFocused")
            m.categoryList.ObserveField("itemSelected", "OnCategoryItemSelect")
            if m.sublist.list.Count() > 0 and m.sublist.list[0].subtitles <> invalid
                m.srtlist = ConvertToContentNode2(m.sublist.list[0].subtitles)
            else
                ' Off is a synthetic item and must exist even when this source has
                ' no subtitle tracks at all.
                m.srtlist = ConvertToContentNode2([])
            end if
            m.itemsList.content = m.srtlist
            video_setting_show_panel("subtitle")
        else
            arr = m.top.content["moviedata"]
            arr["type"] = "subtitles"
            m.SubtitlesContentTask = createObject("RoSGNode","GetContentReader")
            m.SubtitlesContentTask.content = arr
            m.SubtitlesContentTask.observeField("content", "SubtitlesSet")
            m.SubtitlesContentTask.control = "RUN"
        end if
    end if
end sub

sub on_type_tab_changed()
    if m.suppress_tab_change = true
        return
    end if
    if m.typelist = invalid or m.typelist.hasFocus() <> true
        return
    end if
    video_setting_apply_panel(video_setting_panel_id_at_focus())
end sub

sub onVideoNodeSet()
    if m.video_tracks_observer_set = true and m.videoNode <> invalid
        m.videoNode.unobserveField("availableAudioTracks")
        m.video_tracks_observer_set = false
    end if
    m.videoNode = m.top.videoNode
    if m.videoNode <> invalid
        m.videoNode.observeField("availableAudioTracks", "on_available_audio_tracks")
        m.video_tracks_observer_set = true
    end if
    if m.audios = invalid or m.audios.visible <> true
        clearAudioTrackList()
    end if
    updateAudioTabs()
    if m.audios = invalid or m.audios.visible <> true
        refreshAudioTracks()
    end if
end sub

sub onAudioStreamUrlChanged()
    if m.audios <> invalid and m.audios.visible = true
        refreshAudioTracks()
        return
    end if
    clearAudioTrackList()
    updateAudioTabs()
end sub

sub clearAudioTrackList()
    m.audio_tracks_signature = invalid
    m.audio_tracks_known = false
    m.top.selectedAudioTrackId = ""
    m.top.currentAudioList = []
    if m.audiolist <> invalid
        m.audiolist.content = invalid
    end if
end sub

sub updateAudioTabs()
    video_setting_update_type_tabs()
end sub

function video_setting_as_string(val as Dynamic) as String
    if val = invalid
        return ""
    end if
    valType = Type(val)
    if valType = "roString" or valType = "String"
        return val
    end if
    return val.toStr()
end function

function video_setting_stream_ready() as Boolean
    if m.videoNode = invalid
        return false
    end if
    streamUrl = m.top.audioStreamUrl
    if streamUrl = invalid or streamUrl = ""
        return false
    end if
    if m.videoNode.content = invalid or m.videoNode.content.url = invalid
        return false
    end if
    return m.videoNode.content.url = streamUrl
end function

function video_setting_track_lang(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Language <> invalid and track.Language <> ""
        return track.Language
    end if
    if track.language <> invalid and track.language <> ""
        return track.language
    end if
    if track.lang <> invalid and track.lang <> ""
        return track.lang
    end if
    return ""
end function

function video_setting_track_name(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Name <> invalid and track.Name <> ""
        return track.Name
    end if
    if track.Track <> invalid and track.Track <> ""
        return track.Track
    end if
    if track.name <> invalid and track.name <> ""
        return track.name
    end if
    return ""
end function

function video_setting_api_lang(apiItem as Object) as String
    if apiItem = invalid
        return ""
    end if
    if apiItem.language <> invalid and apiItem.language <> ""
        return apiItem.language
    end if
    if apiItem.lang <> invalid and apiItem.lang <> ""
        return apiItem.lang
    end if
    if apiItem.Language <> invalid and apiItem.Language <> ""
        return apiItem.Language
    end if
    if apiItem.audio_lang <> invalid and apiItem.audio_lang <> ""
        return apiItem.audio_lang
    end if
    return ""
end function

function video_setting_api_name(apiItem as Object) as String
    if apiItem = invalid
        return ""
    end if
    if apiItem.title <> invalid and apiItem.title <> ""
        return apiItem.title
    end if
    if apiItem.name <> invalid and apiItem.name <> ""
        return apiItem.name
    end if
    if apiItem.Name <> invalid and apiItem.Name <> ""
        return apiItem.Name
    end if
    if apiItem.quality <> invalid and apiItem.quality <> "" and apiItem.quality <> "audio"
        return apiItem.quality
    end if
    return ""
end function

function video_setting_track_matches_api(track as Object, apiItem as Object) as Boolean
    apiLang = video_setting_api_lang(apiItem)
    apiName = video_setting_api_name(apiItem)
    trackLang = video_setting_track_lang(track)
    trackName = video_setting_track_name(track)
    if apiLang <> "" and trackLang <> ""
        if LCase(apiLang) <> LCase(trackLang)
            return false
        end if
    end if
    if apiName <> "" and trackName <> ""
        if LCase(apiName) <> LCase(trackName)
            return false
        end if
    end if
    return apiLang <> "" or apiName <> ""
end function

function video_setting_api_audio_title(apiItem as Object, track as Object) as String
    apiName = video_setting_api_name(apiItem)
    apiLang = video_setting_api_lang(apiItem)
    if apiName <> "" and apiLang <> "" and LCase(apiName) <> LCase(apiLang)
        return apiName + " (" + apiLang + ")"
    else if apiName <> ""
        return apiName
    else if apiLang <> ""
        return apiLang
    end if
    if track <> invalid
        return getAudioTrackName(track)
    end if
    return "Audio"
end function

function video_setting_resolve_audio_tracks(rokuTracks as Object) as Object
    if rokuTracks = invalid
        return []
    end if
    return video_setting_normalize_audio_tracks(rokuTracks)
end function

function video_setting_get_audio_tracks() as Object
    if m.videoNode = invalid
        return invalid
    end if
    if m.videoNode.availableAudioTracks = invalid
        return invalid
    end if
    tracks = m.videoNode.availableAudioTracks
    if tracks.Count() = 0
        return invalid
    end if
    return video_setting_resolve_audio_tracks(tracks)
end function

function video_setting_audio_track_key(track as Object) as String
    if track = invalid
        return ""
    end if
    trackId = video_setting_audio_track_id(track)
    if trackId <> ""
        return LCase(trackId)
    end if
    lang = ""
    name = ""
    if track.Language <> invalid and track.Language <> ""
        lang = track.Language
    end if
    if track.Name <> invalid and track.Name <> ""
        name = track.Name
    else if track.Track <> invalid and track.Track <> ""
        name = track.Track
    end if
    if lang <> "" or name <> ""
        return LCase(lang + "|" + name)
    end if
    return ""
end function

function video_setting_normalize_audio_tracks(tracks as Object) as Object
    result = []
    if tracks = invalid
        return result
    end if
    for i = 0 to tracks.Count() - 1
        result.Push(tracks[i])
    end for
    return result
end function

function video_setting_has_multiple_audio() as Boolean
    tracks = video_setting_get_audio_tracks()
    if tracks = invalid
        return false
    end if
    return tracks.Count() > 1
end function

sub video_setting_update_type_tabs()
    hasMultiple = video_setting_has_multiple_audio()
    if hasMultiple = true
        m.audio_tracks_known = true
    end if
    showAudioTab = hasMultiple or m.audio_tracks_known = true
    tabsReady = false
    if m.typelist <> invalid and m.typelist.content <> invalid and m.typelist.content.getChildCount() > 0
        tabsReady = true
    end if
    if tabsReady = true and m.audio_tab_visible = showAudioTab and m.type_panel_map <> invalid
        return
    end if
    savedFocus = 0
    if m.typelist <> invalid and m.typelist.itemFocused <> invalid
        savedFocus = m.typelist.itemFocused
    end if
    m.audio_tab_visible = showAudioTab
    m.type_panel_map = ["video"]
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "Video"
    tabCount = 2
    if showAudioTab = true
        child = contentRoot.createChild("ContentNode")
        child.title = "Audio"
        m.type_panel_map.Push("audio")
        tabCount = 3
    end if
    child = contentRoot.createChild("ContentNode")
    child.title = "Subtitle"
    m.type_panel_map.Push("subtitle")
    if m.typelist <> invalid
        m.typelist.numColumns = tabCount
        if tabCount = 2
            m.typelist.itemSize = [150, 55]
            m.typelist.itemSpacing = [30, 0]
            m.typelist.translation = [370, 40]
        else
            m.typelist.itemSize = [136, 55]
            m.typelist.itemSpacing = [12, 0]
            m.typelist.translation = [300, 40]
        end if
        m.suppress_tab_change = true
        m.typelist.content = contentRoot
        if savedFocus >= tabCount
            savedFocus = tabCount - 1
        end if
        if savedFocus < 0
            savedFocus = 0
        end if
        m.typelist.jumpToItem = savedFocus
        m.suppress_tab_change = false
        video_setting_apply_panel(video_setting_panel_id_at_index(savedFocus))
    end if
end sub

sub on_available_audio_tracks()
    if m.videoNode <> invalid and m.videoNode.availableAudioTracks <> invalid
        if m.videoNode.availableAudioTracks.Count() > 1
            m.audio_tracks_known = true
        end if
    end if
    if m.audios <> invalid and m.audios.visible = true
        refreshAudioTracks()
        return
    end if
    updateAudioTabs()
    m.audio_tracks_signature = invalid
end sub

function video_setting_audio_track_id(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Track <> invalid and track.Track <> ""
        return video_setting_as_string(track.Track)
    end if
    return ""
end function

function getAudioTrackName(track as Object) as String
    if track = invalid
        return "Unknown"
    end if
    name = ""
    lang = ""
    if track.Name <> invalid and track.Name <> ""
        name = track.Name
    else if track.Track <> invalid and track.Track <> ""
        name = track.Track
    else if track.name <> invalid and track.name <> ""
        name = track.name
    end if
    if track.Language <> invalid and track.Language <> ""
        lang = track.Language
    else if track.language <> invalid and track.language <> ""
        lang = track.language
    else if track.lang <> invalid and track.lang <> ""
        lang = track.lang
    end if
    if name <> "" and lang <> "" and LCase(name) <> LCase(lang)
        return name + " (" + lang + ")"
    else if name <> ""
        return name
    else if lang <> ""
        return lang
    end if
    return "Audio"
end function

function video_setting_audio_item_description() as String
    data = {"quality":"audio","size":"","vip_only":0,"h265":0,"bitstream":"false"}
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(FormatJson(data))
    return ba.ToBase64String()
end function

sub refreshAudioTracks()
    if m.audiolist = invalid
        return
    end if
    if m.audiolist.hasFocus() = true
        return
    end if
    m.top.audioTrackRefreshing = true
    currentId = ""
    if m.videoNode <> invalid and m.videoNode.audioTrack <> invalid and m.videoNode.audioTrack <> ""
        currentId = video_setting_as_string(m.videoNode.audioTrack)
    end if
    if currentId = "" and m.top.selectedAudioTrackId <> invalid and m.top.selectedAudioTrackId <> ""
        currentId = m.top.selectedAudioTrackId
    end if
    tracks = video_setting_get_audio_tracks()
    trackCount = 0
    if tracks <> invalid
        trackCount = tracks.Count()
    end if
    if trackCount = 0
        m.top.audioTrackRefreshing = false
        return
    end if
    streamUrl = m.top.audioStreamUrl
    if streamUrl = invalid
        streamUrl = ""
    end if
    sig = streamUrl + "#" + trackCount.toStr() + "#" + currentId
    if tracks <> invalid
        for i = 0 to tracks.Count() - 1
            track = tracks[i]
            sig = sig + "|" + video_setting_audio_track_id(track)
            if video_setting_audio_track_id(track) = ""
                sig = sig + ":" + i.toStr()
            end if
        end for
    end if
    if m.audio_tracks_signature <> invalid and m.audio_tracks_signature = sig
        m.top.audioTrackRefreshing = false
        return
    end if
    content = createObject("roSGNode", "ContentNode")
    selectedMarked = false
    trackIndex = 0
    if tracks <> invalid
        for each track in tracks
            item = content.createChild("ContentNode")
            trackId = video_setting_audio_track_id(track)
            if trackId = ""
                trackId = "idx_" + trackIndex.toStr()
            end if
            item.id = trackId
            item.title = getAudioTrackName(track)
            item.SecondaryTitle = "false"
            if currentId <> "" and item.id = currentId
                item.SecondaryTitle = "true"
                selectedMarked = true
            end if
            item.Description = video_setting_audio_item_description()
            trackIndex = trackIndex + 1
        end for
    end if
    if trackCount <= 1
        m.audiolist.content = content
        m.audio_tracks_signature = sig
        m.top.audioTrackRefreshing = false
        return
    end if
    if selectedMarked = false and content.getChildCount() > 0
        firstItem = content.getChild(0)
        if firstItem <> invalid
            firstItem.SecondaryTitle = "true"
            if m.top.selectedAudioTrackId = invalid or m.top.selectedAudioTrackId = ""
                m.top.selectedAudioTrackId = firstItem.id
            end if
        end if
    end if
    m.audiolist.content = content
    m.audio_tracks_signature = sig
    m.top.audioTrackRefreshing = false
end sub

sub video_setting_mark_audio_track(index as Integer)
    if m.audiolist = invalid or m.audiolist.content = invalid
        return
    end if
    for i = 0 to m.audiolist.content.getChildCount() - 1
        item = m.audiolist.content.getChild(i)
        if i = index
            item.update({"SecondaryTitle":"true"}, false)
        else
            item.update({"SecondaryTitle":"false"}, false)
        end if
    end for
end sub

sub video_setting_restore_quality_focus()
    if m.qualitylist = invalid or m.qualitylist.content = invalid
        return
    end if
    count = m.qualitylist.content.getChildCount()
    if count <= 0
        return
    end if

    selectedIndex = -1
    for i = 0 to count - 1
        row = m.qualitylist.content.getChild(i)
        if row <> invalid and row.SecondaryTitle = "true"
            selectedIndex = i
            exit for
        end if
    end for
    if selectedIndex < 0
        selectedIndex = 0
        if m.selected_quality_index <> invalid
            selectedIndex = m.selected_quality_index
        end if
    end if
    if selectedIndex < 0
        selectedIndex = 0
    else if selectedIndex >= count
        selectedIndex = count - 1
    end if
    m.selected_quality_index = selectedIndex

    focused = m.qualitylist.itemFocused
    if focused = invalid or focused < 0 or focused >= count
        m.qualitylist.jumpToItem = selectedIndex
    end if
end sub

sub video_setting_show_panel(panelId as String)
    if m.qualitys <> invalid
        m.qualitys.visible = false
    end if
    if m.audios <> invalid
        m.audios.visible = false
    end if
    if m.subtitles <> invalid
        m.subtitles.visible = false
    end if
    if panelId = "video" and m.qualitys <> invalid
        m.qualitys.visible = true
    else if panelId = "audio" and m.audios <> invalid
        m.audios.visible = true
        if m.audiolist.content = invalid or m.audiolist.content.getChildCount() = 0
            refreshAudioTracks()
        end if
    else if panelId = "subtitle" and m.subtitles <> invalid
        m.subtitles.visible = true
        if m.subtitle_ops <> invalid
            m.subtitle_ops.visible = true
        end if
    end if
    if panelId <> "subtitle" and m.subtitle_ops <> invalid
        m.subtitle_ops.visible = false
    end if
end sub

function shouldRefetchSubtitles() as Boolean
    if m.top.content = invalid
        return false
    end if
    if m.top.content.subtitle_list = invalid
        return true
    end if
    if m.top.content.subtitle_list.list = invalid
        return true
    end if
    return false
end function

sub fetchSubtitleList()
    if m.top.content = invalid or m.top.content.moviedata = invalid
        return
    end if
    arr = m.top.content.moviedata
    arr["type"] = "subtitles"
    if m.SubtitlesContentTask <> invalid and m.SubtitlesContentTask.state = "run"
        m.SubtitlesContentTask.control = "STOP"
    end if
    m.SubtitlesContentTask = createObject("RoSGNode","GetContentReader")
    m.SubtitlesContentTask.content = arr
    m.SubtitlesContentTask.observeField("content", "SubtitlesSet")
    m.SubtitlesContentTask.control = "RUN"
end sub

sub getsubtitles()
    if m.typelist.itemSelected < 0 or m.typelist.content = invalid
        return
    end if
    selectedTab = m.typelist.content.getChild(m.typelist.itemSelected).title
    if selectedTab = "Subtitle"
        if shouldRefetchSubtitles()
            fetchSubtitleList()
            return
        end if
        arr = m.top.content["moviedata"]
        arr["type"] = "subtitles"
        m.SubtitlesContentTask = createObject("RoSGNode","GetContentReader")
        m.SubtitlesContentTask.content = arr
        m.SubtitlesContentTask.observeField("content", "SubtitlesSet")
        m.SubtitlesContentTask.control = "RUN"
    end if
end sub

sub subtitle_operate()
    index = m.subtitle_btns.itemSelected
    if index = 0
        m.sub_settingbg.visible = false
        m.subtitle_delaybg.visible = true
        m.subtitle_delay.SetFocus(true)
    elseif index = 1
        m.sub_settingbg.visible = false
        m.subtitle_sizebg.visible = true
        m.subtitle_size.SetFocus(true)
    elseif index = 2
        m.sub_settingbg.visible = false
        m.subtitle_movebg.visible = true
        m.subtitle_move.SetFocus(true)
    elseif index = 3
        m.sub_settingbg.visible = false
        m.subtitle_appearancebg.visible = true
        m.subtitle_bg_opacity.SetFocus(true)
    end if
end sub

function SubtitlesSet()
    if m.SubtitlesContentTask.content = invalid or Type(m.SubtitlesContentTask.content) <> "roAssociativeArray"
        return false
    end if
    if m.SubtitlesContentTask.content.type <> invalid
        return false
    end if
    m.sublist = m.SubtitlesContentTask.content
    if m.sublist.list = invalid
        m.sublist["list"] = []
    end if
    arr = m.top.content
    arr.subtitle_list = m.sublist
    m.top.content = arr
    ' m.sublist.list = DataSet(m.sublist.list)
    m.langlist = ConvertToContentNode(m.sublist.list)
    m.categoryList.content = m.langlist
    m.categoryList.ObserveField("itemFocused", "OnCategoryItemFocused")
    m.categoryList.ObserveField("itemSelected", "OnCategoryItemSelect")
    if m.sublist.list.Count() > 0
        m.srtlist = ConvertToContentNode2(m.sublist.list[0].subtitles)
    else
        m.srtlist = ConvertToContentNode2([])
    end if
    m.itemsList.content = m.srtlist
    m.qualitys.visible = false
    m.audios.visible = false
    m.subtitles.visible = true
    if m.subtitle_ops <> invalid
        m.subtitle_ops.visible = true
    end if
end function

sub refreshSubtitleContent()
    if m.top.content = invalid or m.top.content.subtitle_list = invalid
        return
    end if
    m.sublist = m.top.content.subtitle_list
    if m.sublist.list = invalid
        m.sublist["list"] = []
    end if
    m.langlist = ConvertToContentNode(m.sublist.list)
    m.categoryList.content = m.langlist
    if m.sublist.list.Count() > 0
        m.srtlist = ConvertToContentNode2(m.sublist.list[0].subtitles)
    else
        m.srtlist = ConvertToContentNode2([])
    end if
    m.itemsList.content = m.srtlist
end sub

sub OnCategoryItemFocused()
    if m.categoryList.itemFocused = 0
        return
    else
        index = m.categoryList.itemFocused - 1
        ' m.sublist = m.top.content.subtitle_list
        if m.sublist.list.Count() = 0
            return
        end if
        if m.sublist.list[index] = invalid
            index = m.sublist.list.Count() - 1
        end if
        m.srtlist = ConvertToContentNode2(m.sublist.list[index].subtitles)
        m.itemsList.content = m.srtlist
    end if
end sub

sub OnCategoryItemSelect()
    if m.categoryList.itemSelected = 0
        m.srtpage = 1
        user = CreateObject("roRegistrySection", "User")
        if user.Exists("subtitle_lang")
            subtitle_lang = user.Read("subtitle_lang")
            subtitle_lang = ParseJson(subtitle_lang)
            new_default = [subtitle_lang]
            for each key in m.default
                if key.code <> subtitle_lang.code
                    new_default.Push(key)
                end if
            end for
            m.langlist2.content = lang_ConvertToContentNode(new_default)
        else
            m.langlist2.content = lang_ConvertToContentNode(m.default)
        end if    
        
        if m.top.content.moviedata.imdb_id <> invalid
            m.imdb_id = m.top.content.moviedata.imdb_id
            m.tip_text.text = "Loading..."
            m.tip_text.visible = true
            m.lang = "en"
            m.getContentTask = createObject("RoSGNode","GetContentReader")
            m.getContentTask.content = {"type":"opensubtitle","imdb_id":m.imdb_id,"lang":"en","page":1}
            m.getContentTask.observeField("content", "opensubtitles")
            m.getContentTask.control = "RUN"
            m.opensubtitles.visible = true
            m.langlist2.SetFocus(true)
        end if
    end if
end sub

sub opensubtitles()
    m.tip_text.visible = false
    content = m.getContentTask.content
    if content.type <> invalid
        return
    end if
    if content = invalid or content.code <= 0
        m.tip_text.text = content.msg
        m.tip_text.visible = true
        return
    end if
    if content.data.list.Count() = 0
        m.tip_text.text = "No Subtitles"
        m.tip_text.visible = true
    end if
    m.srtlist2.content = srt_ConvertToContentNode(content.data.list)
end sub

sub lang_more()
    if m.letters.content = invalid
        ContentNode = createObject("RoSGNode","ContentNode")
        for each key in m.langs2.letters
            itemContent = ContentNode.createChild("ContentNode")
            itemContent.title = key
        end for
        m.letters.content = ContentNode

        ContentNode = createObject("RoSGNode","ContentNode")
        for each key in m.langs2["a"]
            itemContent = ContentNode.createChild("ContentNode")
            itemContent.id = key.lang
            itemContent.title = key.language
        end for
        m.language_list.content = ContentNode
    end if
    m.letters.setFocus(true)
    m.languages.visible = true
end sub

sub getlanguage()
    aa = m.letters.content.getChild(m.letters.itemFocused)
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in m.langs2[aa.title]
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.id = key.lang
        itemContent.title = key.language
    end for
    m.language_list.content = ContentNode
end sub

sub getSearchSrt()
    aa = m.langlist2.content.getChild(m.langlist2.itemFocused)
    if m.lang = aa.id
        return
    end if
    m.lang = aa.id
    if m.getContentTask <> invalid and m.getContentTask.state = "run"
        m.getContentTask.control = "stop"
    end if
    m.srtpage = 1
    m.srtlist2.content = invalid
    m.tip_text.text = "Loading..."
    m.tip_text.visible = true
    m.getContentTask = createObject("RoSGNode","GetContentReader")
    m.getContentTask.content = {"type":"opensubtitle","imdb_id":m.imdb_id,"lang":m.lang,"page":1}
    m.getContentTask.observeField("content", "opensubtitles")
    m.getContentTask.control = "RUN"
end sub

sub getSearchSrt2()
    aa = m.language_list.content.getChild(m.language_list.itemSelected)
    if m.lang_pick_mode = "translate"
        startListSubtitleTranslate(aa.id, aa.title)
        return
    end if
    if m.lang = aa.id
        return
    end if
    m.lang = aa.id
    if m.getContentTask <> invalid and m.getContentTask.state = "run"
        m.getContentTask.control = "stop"
    end if
    m.srtpage = 1
    m.srtlist2.content = invalid
    m.tip_text.text = "Loading..."
    m.tip_text.visible = true
    m.getContentTask = createObject("RoSGNode","GetContentReader")
    m.getContentTask.content = {"type":"opensubtitle","imdb_id":m.imdb_id,"lang":m.lang,"page":1}
    m.getContentTask.observeField("content", "opensubtitles")
    m.getContentTask.control = "RUN"
    user = CreateObject("roRegistrySection", "User")
    user.Write("subtitle_lang",FormatJson({"code":m.lang, "name":aa.title}))
    new_default = [{"code":m.lang, "name":aa.title}]
    for each key in m.default
        if key.code <> m.lang
            new_default.Push(key)
        end if
    end for
    m.default = new_default
    m.langlist2.content = lang_ConvertToContentNode(m.default)
    m.languages.visible = false
    m.langlist2.SetFocus(true)
end sub

sub getsrtfile()
    aa = m.srtlist2.content.getChild(m.srtlist2.itemSelected)
    if m.loading <> invalid
        return
    end if
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
    m.getpathTask = createObject("RoSGNode","GetContentReader")
    m.getpathTask.content = {"type":"get_srtpath","subtitle_id":aa.id}
    m.getpathTask.observeField("content", "getSrt")
    m.getpathTask.control = "RUN"
end sub

sub getSrt()
    content = m.getpathTask.content
    if content.type <> invalid
        return
    end if
    if content = invalid or content.code <= 0
        m.top.removeChild(m.loading)
        m.loading = invalid
        return
    end if
    link = content.data.link
    m.srtlink = link
    m.file_name = content.data.file_name
    m.getContentTask2 = createObject("RoSGNode","ReadsrtFile")
    m.getContentTask2.content = link
    m.getContentTask2.observeField("content", "srt_download")
    m.getContentTask2.control = "RUN"
end sub

sub srt_download()
    content = m.getContentTask2.content
    if content = ""
        m.top.removeChild(m.loading)
        m.loading = invalid
        return
    end if

    if m.loading = invalid
        return
    end if
    m.top.removeChild(m.loading)
    m.loading = invalid
    ' byteArray = CreateObject("roByteArray")
    ' byteArray.FromAsciiString(content)

    ' srtFrameCommonBytes = createObject("roByteArray")
    ' srtFrameCommonBytes.append(byteArray)
    ' m.tempFile = "tmp:/"+m.file_name
    ' srtFrameCommonBytes.writeFile(m.tempFile)
    m.srt_text = content
    m.srt_preview_mode = "opensubtitle"
    setSrtPreviewButtons("Done")
    setSrtPreviewTitle("Subtitle Preview")
    setSrtPreviewStatus("")
    m.srt_content.text = createSrtText(content)
    m.srt_content.setFocus(true)
    m.srt_viewbg.visible = true
end sub

sub srtoperate()
    index = m.srt_btns.itemSelected
    if m.srt_preview_mode = "translating"
        cancelSubtitleTranslate()
        return
    end if
    if m.srt_preview_mode = "list"
        if index = 0
            openTranslateLanguagePicker()
        else
            closeSrtPreview()
        end if
        return
    end if
    if m.srt_preview_mode = "translated"
        if index = 0
            confirmTranslatedSubtitle()
        else
            closeSrtPreview()
        end if
        return
    end if
    if m.srt_preview_mode = "error"
        closeSrtPreview()
        return
    end if
    if index <> 0
        return
    end if
    if m.loading <> invalid
        return
    end if
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
    arr = m.top.content.moviedata
    m.uploadTask = createObject("RoSGNode","GetContentReader")
    if arr.box_type = 2
        m.uploadTask.content = {"type":"upload_srt","mid":arr.mid,"box_type":arr.box_type,"season":arr.season,"episode":arr.episode,"lang":m.lang,"language":m.lang_lists[m.lang],"format":"srt","charset":"UTF-8","trans_from":"","filepath":m.srtlink,"filename":m.file_name}
    else
        m.uploadTask.content = {"type":"upload_srt","mid":arr.mid,"box_type":arr.box_type,"lang":m.lang,"language":m.lang_lists[m.lang],"format":"srt","charset":"UTF-8","trans_from":"","filepath":m.srtlink,"filename":m.file_name}
    end if
    m.uploadTask.observeField("content", "srt_select")
    m.uploadTask.control = "RUN"
end sub

sub srt_select()
    content = m.uploadTask.content
    if content.type <> invalid
        return
    end if
    if content = invalid or content.code <= 0
        m.top.removeChild(m.loading)
        m.loading = invalid
        return
    end if
    m.top.srt_con = m.srt_text
    arr = m.top.content["moviedata"]
    arr["sid"] = content.data.srt_info.sid
    arr["type"] = "sub_select"
    m.selectContentTask = createObject("RoSGNode","GetContentReader")
    m.selectContentTask.content = arr
    m.selectContentTask.observeField("content", "getsrtlist")
    m.selectContentTask.control = "RUN"
end sub

sub getsrtlist()
    arr2 = m.top.content["moviedata"]
    arr2["type"] = "subtitles"
    m.SubtitlesContentTask = createObject("RoSGNode","GetContentReader")
    m.SubtitlesContentTask.content = arr2
    m.SubtitlesContentTask.observeField("content", "SubtitlesSet")
    m.SubtitlesContentTask.control = "RUN"
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
    m.srt_viewbg.visible = false
    m.opensubtitles.visible = false
    if m.subtitle_ops <> invalid
        m.subtitle_ops.visible = true
        m.subtitle_ops.SetFocus(true)
    else
        m.categoryList.SetFocus(true)
    end if
end sub

sub SrtScroll()
    if m.srtPageStatus = invalid
        m.srtPageStatus = false
    end if
    if m.srtPageStatus = false
        m.srtPageStatus = true
        m.srtpage = m.srtpage + 1
        m.srtsearchTask = createObject("RoSGNode","GetContentReader")
        m.srtsearchTask.content = {"type":"opensubtitle","imdb_id":m.imdb_id,"lang":m.lang,"page":m.srtpage}
        m.srtsearchTask.observeField("content", "set_subtitles")
        m.srtsearchTask.control = "RUN"
    end if
end sub

sub set_subtitles()
    m.srtPageStatus = false
    if m.srtsearchTask.content.type <> invalid
        return
    end if
    if m.srtsearchTask.content = invalid
        m.srtpage = m.srtpage - 1
        return
    end if
    if m.srtsearchTask.content.data.list.Count() > 0
        arr = srt_ConvertToContentNode2(m.srtsearchTask.content.data.list)
        m.srtlist2.content.appendChildren(arr)
        m.srtlist2.jumpToItem = m.srtlist2.itemFocused + 1
    else
        m.srtpage = m.srtpage - 1
    end if
end sub

function DataSet(Content as Object) as Object
    data = []
    i = 0
    j = 0
    for each subItem in Content
        h = 0
        for each key in subItem.subtitles
            key["index"] = j
            subItem.subtitles[h] = key
            j = j+1
            h = h+1
        end for
        data[i] = subItem
        i = i+1
    end for
    return data
end function

function ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "Subtitles Search"
    for each subItem in Content
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = subItem.language
    end for
    return ContentNode
end function

function ConvertToContentNode2(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    select_sid = 0
    if m.sublist <> invalid and m.sublist.select <> invalid and m.sublist.select.sid <> invalid
        select_sid = m.sublist.select.sid
    end if

    offItem = ContentNode.createChild("ContentNode")
    offItem.id = "0"
    offItem.title = "Off"
    offItem.Description = ""
    if select_sid = 0
        offItem.SecondaryTitle = "true"
    else
        offItem.SecondaryTitle = "false"
    end if
    offData = CreateObject("roAssociativeArray")
    offData["is_off"] = true
    offData["delay"] = 0
    offData["language"] = "Off"
    offData["lang"] = ""
    offItem.addField("data", "assocarray", false)
    offItem.data = offData

    if Content = invalid
        return ContentNode
    end if
    for each subItem in Content
        if subItem = invalid or subItem.file_path = invalid or subItem.file_path = "" or subItem.sid = invalid
            Continue for
        end if
        parts = subItem.file_path.Split("/")
        fileName = parts[parts.Count() - 1]
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.id = subItem.sid
        itemContent.title = fileName
        itemContent.Description = subItem.file_path
        itemContent.SecondaryTitle = "false"
        if select_sid = subItem.sid
            itemContent.SecondaryTitle = "true"
        end if
        data = CreateObject("roAssociativeArray")
        data["delay"] = subItem.delay
        data["language"] = subItem.language
        if subItem.lang <> invalid
            data["lang"] = subItem.lang
        else
            data["lang"] = subItem.language
        end if
        if subItem.DoesExist("org_subtitle") and subItem.org_subtitle <> invalid
            orgLang = ""
            if subItem.org_subtitle.language <> invalid
                orgLang = subItem.org_subtitle.language
            else if subItem.org_subtitle.lang <> invalid
                orgLang = subItem.org_subtitle.lang
            end if
            if orgLang <> ""
                itemContent.shortdescriptionline1 = "From " + orgLang
                data["trans_from"] = orgLang
            end if
        else if subItem.DoesExist("trans_from") and subItem.trans_from <> invalid and subItem.trans_from <> ""
            itemContent.shortdescriptionline1 = "From " + subItem.trans_from
            data["trans_from"] = subItem.trans_from
        end if
        itemContent.addField("data", "assocarray", false)
        itemContent.data = data
    end for
    return ContentNode
end function

function lang_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.id =subItem.code
        itemContent.title = subItem.name
    end for
    return ContentNode
end function

function srt_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.id = subItem.files[0].file_id
        itemContent.title = subItem.files[0].file_name
        itemContent.description = subItem.upload_date
        data = CreateObject("roAssociativeArray")
        data["lang"] = subItem.language
        data["language"] = m.lang_lists[subItem.language]
        itemContent.addField("data", "assocarray", false)
        itemContent.data = data
    end for
    return ContentNode
end function

function srt_ConvertToContentNode2(Content as Object) as Object
    arr = []
    for each subItem in Content
        itemContent = createObject("RoSGNode","ContentNode")
        itemContent.id = subItem.files[0].file_id
        itemContent.title = subItem.files[0].file_name
        itemContent.description = subItem.upload_date
        data = CreateObject("roAssociativeArray")
        data["lang"] = subItem.language
        data["language"] = m.lang_lists[subItem.language]
        itemContent.addField("data", "assocarray", false)
        itemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

Function SplitArrayByFirstLetter(arrayContent as Object, fieldName as String) as Object
    sortedArray = CreateObject("roArray", arrayContent.Count(), true)
    for each item in arrayContent
        sortedArray.Push(item)
    end for
    sortedArray.SortBy(fieldName) '根据字段名排序

    result = CreateObject("roAssociativeArray")
    letters = []
    for each item in sortedArray
        firstLetter = Left(item[fieldName], 1) '获取字段名的首字母
        if result.DoesExist(firstLetter) = false
            result[firstLetter] = CreateObject("roArray", 10, true)
            letters.Push(firstLetter)
        end if
        result[firstLetter].Push(item)
    end for
    result["letters"] = letters
    return result
End Function

function createSrtText(srt as string) as Object
    reg = CreateObject("roRegex", "\n\n|\r\r|\r\n\r\n", "")
    arr = reg.Split(srt)
    if arr.Count() < 2
        arr = srt.Split(chr(10)+chr(13)+chr(10))
        if arr.Count() < 2
            arr = {}
        end if
    end if
    result = []
    r = CreateObject("roRegex", "<font[^>]*>", "i")

    Text = ""
    for each item in arr
        item = item.Trim()
        containArr = item.Split(chr(10))

        if containArr[1] <> invalid
            text2 = containArr.Slice(2).Join(chr(10))
            text2 = r.ReplaceAll(text2, "")
            Text = Text+chr(10)+text2.Replace("</font>", "")
            Text = Text.Replace("<i>", "")
            Text = Text.Replace("</i>", "")
        end if
    end for

    return Text
end function

function getFocusedSubtitleItem() as Object
    if m.itemsList = invalid or m.itemsList.content = invalid
        return invalid
    end if
    idx = m.itemsList.itemFocused
    if idx = invalid or idx < 0
        idx = m.itemsList.itemSelected
    end if
    if idx = invalid or idx < 0 or idx >= m.itemsList.content.getChildCount()
        return invalid
    end if
    return m.itemsList.content.getChild(idx)
end function

sub setSrtPreviewButtons(title as String)
    setSrtPreviewButtonPair(title, "")
end sub

sub setSrtPreviewButtonPair(primary as String, secondary as String)
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = primary
    if secondary <> invalid and secondary <> ""
        child = contentRoot.createChild("ContentNode")
        child.title = secondary
    end if
    m.srt_btns.content = contentRoot
end sub

sub setSrtPreviewStatus(text as String)
    if m.srt_view_status <> invalid
        m.srt_view_status.text = text
    end if
end sub

sub setSrtPreviewTitle(text as String)
    if m.srt_view_title <> invalid
        m.srt_view_title.text = text
    end if
end sub

function formatTranslateCount(doneCount as Dynamic, totalCount as Dynamic) as String
    doneText = "0"
    totalText = "0"
    if doneCount <> invalid
        doneText = video_setting_as_string(doneCount)
    end if
    if totalCount <> invalid
        totalText = video_setting_as_string(totalCount)
    end if
    if totalText <> "0" and totalText <> ""
        return doneText + "/" + totalText
    end if
    if doneText <> "0" and doneText <> ""
        return doneText
    end if
    return ""
end function

function clipTranslatePreview(text as String) as String
    if text = invalid
        return ""
    end if
    maxLen = 12000
    if text.Len() > maxLen
        return Left(text, maxLen) + chr(10) + chr(10) + "...(preview truncated)"
    end if
    return text
end function

sub closeSrtPreview()
    stopTranslateWaitUi()
    hideSubtitleLoading()
    m.srt_viewbg.visible = false
    if m.srt_preview_mode = "opensubtitle"
        m.srtlist2.setFocus(true)
    else if m.subtitle_ops <> invalid
        m.subtitle_ops.SetFocus(true)
    else if m.itemsList <> invalid
        m.itemsList.SetFocus(true)
    end if
end sub

function subtitlePreviewDisplayText(raw as String) as String
    if raw = invalid or raw = ""
        return ""
    end if
    parsed = createSrtText(raw)
    if parsed <> invalid and parsed <> ""
        return parsed
    end if
    return raw
end function

sub showSubtitleLoading()
    if m.loading <> invalid
        return
    end if
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
end sub

sub hideSubtitleLoading()
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
end sub

sub subtitle_list_operate()
    if m.subtitle_ops = invalid
        return
    end if
    index = m.subtitle_ops.itemSelected
    item = getFocusedSubtitleItem()
    if item = invalid
        return
    end if
    m.preview_item = item
    if index = 0
        previewListSubtitle()
    else if index = 1
        openTranslateLanguagePicker()
    end if
end sub

sub previewListSubtitle()
    item = m.preview_item
    if item = invalid
        item = getFocusedSubtitleItem()
        m.preview_item = item
    end if
    if item = invalid or item.Description = invalid or item.Description = ""
        return
    end if
    if m.loading <> invalid
        return
    end if
    showSubtitleLoading()
    m.listPreviewTask = createObject("RoSGNode", "ReadsrtFile")
    m.listPreviewTask.content = item.Description
    m.listPreviewTask.observeField("content", "onListSrtPreviewLoaded")
    m.listPreviewTask.control = "RUN"
end sub

sub onListSrtPreviewLoaded()
    hideSubtitleLoading()
    if m.listPreviewTask = invalid
        return
    end if
    content = m.listPreviewTask.content
    if content = invalid or content = ""
        showSrtPreviewError("Subtitle download failed")
        return
    end if
    m.srt_text = content
    m.srt_preview_mode = "list"
    setSrtPreviewButtonPair("Translate", "Back")
    setSrtPreviewTitle("Subtitle Preview")
    setSrtPreviewStatus("")
    m.srt_content.text = subtitlePreviewDisplayText(content)
    m.srt_content.setFocus(true)
    m.srt_viewbg.visible = true
end sub

sub showSrtPreviewError(msg as String)
    stopTranslateWaitUi()
    hideSubtitleLoading()
    m.srt_preview_mode = "error"
    setSrtPreviewButtons("Back")
    setSrtPreviewTitle("Translation Failed")
    setSrtPreviewStatus("Failed")
    if msg = invalid or msg = "" or msg = "ok" or msg = "success"
        msg = "Translation failed. Please try again."
    end if
    m.srt_content.text = msg
    m.srt_btns.setFocus(true)
    m.srt_viewbg.visible = true
end sub

sub openTranslateLanguagePicker()
    item = m.preview_item
    if item = invalid
        item = getFocusedSubtitleItem()
        m.preview_item = item
    end if
    if item = invalid
        return
    end if
    m.lang_pick_mode = "translate"
    m.srt_viewbg.visible = false
    lang_more()
end sub

function normalizeSrtLangCode(code as String) as String
    if code = invalid
        return ""
    end if
    v = LCase(code)
    if v = "zh-cn" or v = "zh_cn" or v = "zh"
        return "zh"
    end if
    if v = "zh-tw" or v = "zh_tw"
        return "zt"
    end if
    return code
end function

function getSubtitleItemLang(item as Object) as String
    if item = invalid or item.data = invalid
        return ""
    end if
    if item.data.lang <> invalid and item.data.lang <> ""
        return item.data.lang
    end if
    if item.data.language <> invalid
        return item.data.language
    end if
    return ""
end function

function parseSrtCues(srt as String) as Object
    cues = []
    if srt = invalid or srt = ""
        return cues
    end if
    text = srt.Replace(chr(13) + chr(10), chr(10))
    text = text.Replace(chr(13), chr(10))
    reg = CreateObject("roRegex", "\n[ \t]*\n", "")
    blocks = reg.Split(text)
    for each block in blocks
        block = block.Trim()
        if block <> ""
            lines = block.Split(chr(10))
            timeIdx = -1
            i = 0
            while i < lines.Count()
                if Instr(1, lines[i], "-->") > 0
                    timeIdx = i
                    exit while
                end if
                i = i + 1
            end while
            if timeIdx >= 0
                num = ""
                if timeIdx > 0
                    num = lines[timeIdx - 1].Trim()
                end if
                if num = ""
                    num = (cues.Count() + 1).ToStr()
                end if
                time = lines[timeIdx].Trim()
                content = ""
                j = timeIdx + 1
                while j < lines.Count()
                    if content <> ""
                        content = content + chr(10)
                    end if
                    content = content + lines[j]
                    j = j + 1
                end while
                cues.Push({
                    "num": num,
                    "time": time,
                    "content": content.Trim()
                })
            end if
        end if
    end for
    return cues
end function

function buildSrtFromCues(cues as Object) as String
    srt = ""
    if cues = invalid
        return srt
    end if
    for each cue in cues
        num = video_setting_as_string(cue.num)
        time = video_setting_as_string(cue.time)
        content = video_setting_as_string(cue.content)
        if num <> "" or time <> "" or content <> ""
            srt = srt + num + chr(10) + time + chr(10) + content + chr(10) + chr(10)
        end if
    end for
    return srt
end function

function cuesToPreviewText(cues as Object) as String
    text = ""
    if cues = invalid
        return text
    end if
    r = CreateObject("roRegex", "<font[^>]*>", "i")
    for each cue in cues
        content = video_setting_as_string(cue.content)
        if content <> ""
            content = r.ReplaceAll(content, "")
            content = content.Replace("</font>", "").Replace("<i>", "").Replace("</i>", "")
            if text <> ""
                text = text + chr(10)
            end if
            text = text + content
        end if
    end for
    return text
end function

sub startListSubtitleTranslate(toCode as String, toName as String)
    item = m.preview_item
    if item = invalid
        return
    end if
    fromCode = getSubtitleItemLang(item)
    fromNorm = normalizeSrtLangCode(fromCode)
    toNorm = normalizeSrtLangCode(toCode)
    if fromNorm <> "" and toNorm <> "" and LCase(fromNorm) = LCase(toNorm)
        m.languages.visible = false
        m.lang_pick_mode = "opensubtitle"
        showSrtPreviewError("Cannot translate the same language")
        return
    end if
    m.translate_to = toCode
    m.translate_to_name = toName
    m.translate_from = fromCode
    m.languages.visible = false
    m.lang_pick_mode = "opensubtitle"
    stopTranslatePoll()
    m.translate_cancelled = false
    m.translate_poll_count = 0
    m.translate_batch_mode = false
    m.translate_index = 0
    m.translate_total = 0
    m.translate_out_cues = []
    m.translate_slots = []
    m.translate_jobs = []
    m.translate_next_offset = 0
    m.translate_inflight = 0
    m.translate_done_count = 0
    m.translate_batch_errors = 0
    m.translated_sid = ""
    m.translated_url = ""
    m.translated_srt_text = ""
    showTranslateProgressPanel()
    prepareTranslateSource()
end sub

sub prepareTranslateSource()
    if m.srt_text <> invalid and m.srt_text <> ""
        beginTranslateBatches(m.srt_text)
        return
    end if
    item = m.preview_item
    if item = invalid or item.Description = invalid or item.Description = ""
        showSrtPreviewError("Subtitle not found")
        return
    end if
    setSrtPreviewStatus("Loading subtitle...")
    m.srt_content.text = "Loading subtitle for translation..."
    m.translateSourceTask = createObject("RoSGNode", "ReadsrtFile")
    m.translateSourceTask.content = item.Description
    m.translateSourceTask.observeField("content", "onTranslateSourceLoaded")
    m.translateSourceTask.control = "RUN"
end sub

sub onTranslateSourceLoaded()
    if m.translate_cancelled = true
        return
    end if
    if m.translateSourceTask = invalid
        return
    end if
    content = m.translateSourceTask.content
    if content = invalid or content = ""
        showSrtPreviewError("Subtitle download failed")
        return
    end if
    m.srt_text = content
    beginTranslateBatches(content)
end sub

sub beginTranslateBatches(srtText as String)
    cues = parseSrtCues(srtText)
    if cues.Count() = 0
        m.translate_batch_mode = false
        setSrtPreviewStatus("Translating...")
        requestSrtTranslateApi()
        return
    end if
    m.translate_batch_mode = true
    m.translate_cues = cues
    m.translate_total = cues.Count()
    m.translate_next_offset = 0
    m.translate_inflight = 0
    m.translate_done_count = 0
    m.translate_batch_errors = 0
    m.translate_batch_size = 24
    m.translate_concurrency = 4
    m.translate_jobs = []
    m.translate_out_cues = []
    m.translate_slots = []
    i = 0
    while i < m.translate_total
        m.translate_slots.Push(invalid)
        i = i + 1
    end while
    updateTranslateProgressUi()
    fillTranslateBatchSlots()
end sub

function translateBatchCuesAt(offset as Integer, count as Integer) as Object
    batch = []
    if m.translate_cues = invalid or count <= 0
        return batch
    end if
    lastIdx = offset + count
    if lastIdx > m.translate_total
        lastIdx = m.translate_total
    end if
    i = offset
    while i < lastIdx
        batch.Push(m.translate_cues[i])
        i = i + 1
    end while
    return batch
end function

sub fillTranslateBatchSlots()
    if m.translate_cancelled = true
        return
    end if
    if m.translate_concurrency = invalid or m.translate_concurrency <= 0
        m.translate_concurrency = 4
    end if
    while m.translate_inflight < m.translate_concurrency and m.translate_next_offset < m.translate_total
        if startTranslateBatchJob() = false
            exit while
        end if
    end while
    if m.translate_inflight <= 0
        if m.translate_done_count > 0
            finishTranslateBatches(m.translate_done_count < m.translate_total)
        else if m.translate_next_offset >= m.translate_total or m.translate_batch_errors > 0
            showSrtPreviewError("Translation failed. Please try again.")
        end if
    end if
end sub

function startTranslateBatchJob() as Boolean
    item = m.preview_item
    if item = invalid or m.top.content = invalid or m.top.content.moviedata = invalid
        return false
    end if
    offset = m.translate_next_offset
    remain = m.translate_total - offset
    if remain <= 0
        return false
    end if
    count = m.translate_batch_size
    if count > remain
        count = remain
    end if
    batch = translateBatchCuesAt(offset, count)
    if batch.Count() = 0
        return false
    end if
    arr = m.top.content.moviedata
    fromCode = m.translate_from
    if fromCode = invalid or fromCode = ""
        fromCode = "en"
    end if
    payload = {
        "type": "srt_translate",
        "box_type": arr.box_type,
        "sid": item.id,
        "from": fromCode,
        "to": m.translate_to,
        "language": m.translate_to_name,
        "content": buildSrtFromCues(batch)
    }
    task = createObject("RoSGNode", "GetContentReader")
    job = {
        "offset": offset,
        "count": batch.Count(),
        "done": false,
        "task": task
    }
    m.translate_jobs.Push(job)
    m.translate_next_offset = offset + batch.Count()
    m.translate_inflight = m.translate_inflight + 1
    task.content = payload
    task.observeField("content", "onSrtTranslateResult")
    task.control = "RUN"
    return true
end function

sub requestSrtTranslateApi()
    item = m.preview_item
    if item = invalid or m.top.content = invalid or m.top.content.moviedata = invalid
        showSrtPreviewError("Subtitle not found")
        return
    end if
    arr = m.top.content.moviedata
    fromCode = m.translate_from
    if fromCode = invalid or fromCode = ""
        fromCode = "en"
    end if
    m.translateTask = createObject("RoSGNode", "GetContentReader")
    m.translateTask.content = {
        "type": "srt_translate",
        "box_type": arr.box_type,
        "sid": item.id,
        "from": fromCode,
        "to": m.translate_to,
        "language": m.translate_to_name
    }
    m.translateTask.observeField("content", "onSrtTranslateResult")
    m.translateTask.control = "RUN"
end sub

function findFinishedTranslateJob() as Object
    if m.translate_jobs = invalid
        return invalid
    end if
    for each job in m.translate_jobs
        if job.done = false and job.task <> invalid
            content = job.task.content
            if content <> invalid and content.code <> invalid and (content.type = invalid or content.type <> "srt_translate")
                return job
            end if
        end if
    end for
    return invalid
end function

sub stopAllTranslateJobs()
    if m.translate_jobs <> invalid
        for each job in m.translate_jobs
            if job.task <> invalid and job.task.state = "run"
                job.task.unobserveField("content")
                job.task.control = "stop"
            end if
            job.done = true
        end for
    end if
    m.translate_inflight = 0
    if m.translateTask <> invalid and m.translateTask.state = "run"
        m.translateTask.control = "stop"
    end if
end sub

sub rebuildTranslateOutCues()
    out = []
    if m.translate_slots = invalid
        m.translate_out_cues = out
        return
    end if
    i = 0
    while i < m.translate_slots.Count()
        if m.translate_slots[i] <> invalid
            out.Push(m.translate_slots[i])
        end if
        i = i + 1
    end while
    m.translate_out_cues = out
end sub

sub showTranslateProgressPanel()
    hideSubtitleLoading()
    m.srt_preview_mode = "translating"
    langName = m.translate_to_name
    if langName = invalid or langName = ""
        langName = "target language"
    end if
    setSrtPreviewTitle("Translating")
    setSrtPreviewStatus("Translating to " + langName + "... 0/0")
    setSrtPreviewButtons("Cancel")
    m.srt_content.text = "Translated lines will appear here..."
    m.srt_btns.setFocus(true)
    m.srt_viewbg.visible = true
    startTranslateWaitUi()
end sub

sub updateTranslateProgressUi()
    if m.srt_preview_mode <> "translating"
        return
    end if
    langName = m.translate_to_name
    if langName = invalid or langName = ""
        langName = "target language"
    end if
    doneCount = 0
    if m.translate_done_count <> invalid
        doneCount = m.translate_done_count
    else if m.translate_out_cues <> invalid
        doneCount = m.translate_out_cues.Count()
    end if
    totalCount = 0
    if m.translate_total <> invalid
        totalCount = m.translate_total
    end if
    secText = "0"
    if m.translate_wait_sec <> invalid
        secText = m.translate_wait_sec.ToStr()
    end if
    pctText = "0"
    if totalCount > 0
        pctText = Int((doneCount * 100) / totalCount).ToStr()
    end if
    setSrtPreviewStatus("Translating to " + langName + "...  " + doneCount.ToStr() + "/" + totalCount.ToStr() + "  " + pctText + "%  " + secText + "s")
    preview = cuesToPreviewText(m.translate_out_cues)
    if preview = ""
        preview = "Translated lines will appear here..."
    end if
    m.srt_content.text = clipTranslatePreview(preview)
end sub

sub startTranslateWaitUi()
    m.translate_wait_sec = 0
    if m.translateWaitTimer = invalid
        m.translateWaitTimer = CreateObject("roSGNode", "Timer")
        m.translateWaitTimer.duration = 1
        m.translateWaitTimer.repeat = true
        m.translateWaitTimer.observeField("fire", "onTranslateWaitTick")
    end if
    m.translateWaitTimer.control = "start"
end sub

sub stopTranslateWaitUi()
    if m.translateWaitTimer <> invalid
        m.translateWaitTimer.control = "stop"
    end if
end sub

sub onTranslateWaitTick()
    if m.srt_preview_mode <> "translating"
        stopTranslateWaitUi()
        return
    end if
    if m.translate_wait_sec = invalid
        m.translate_wait_sec = 0
    end if
    m.translate_wait_sec = m.translate_wait_sec + 1
    updateTranslateProgressUi()
end sub

sub cancelSubtitleTranslate()
    m.translate_cancelled = true
    stopTranslatePoll()
    stopTranslateWaitUi()
    stopAllTranslateJobs()
    if m.translateSourceTask <> invalid and m.translateSourceTask.state = "run"
        m.translateSourceTask.control = "stop"
    end if
    hideSubtitleLoading()
    m.srt_viewbg.visible = false
    if m.subtitle_ops <> invalid
        m.subtitle_ops.SetFocus(true)
    else if m.itemsList <> invalid
        m.itemsList.SetFocus(true)
    end if
end sub

sub onSrtTranslateResult()
    if m.translate_cancelled = true
        return
    end if
    if m.translate_batch_mode = true
        job = findFinishedTranslateJob()
        if job = invalid
            return
        end if
        content = job.task.content
        job.done = true
        if job.task <> invalid
            job.task.unobserveField("content")
        end if
        if m.translate_inflight > 0
            m.translate_inflight = m.translate_inflight - 1
        end if
        handleTranslateBatchResult(job, content)
        return
    end if
    if m.translateTask = invalid
        return
    end if
    content = m.translateTask.content
    if content <> invalid and content.type <> invalid and content.type = "srt_translate"
        return
    end if
    if content = invalid
        showSrtPreviewError("Translation failed. Please try again.")
        return
    end if
    if content.code <> invalid and content.code = -3
        stopTranslatePoll()
        stopAllTranslateJobs()
        msg = "This feature is only available to VIP users."
        if content.msg <> invalid and content.msg <> ""
            msg = content.msg
        end if
        showSrtPreviewError(msg)
        return
    end if
    if content.code <> invalid and content.code = 1
        hideSubtitleLoading()
        stopTranslatePoll()
        data = content.data
        if data = invalid
            showSrtPreviewError("Translation returned empty result")
            return
        end if
        sid = ""
        if data.srt_id <> invalid
            sid = video_setting_as_string(data.srt_id)
        else if data.sid <> invalid
            sid = video_setting_as_string(data.sid)
        else if data.srt_info <> invalid and data.srt_info.sid <> invalid
            sid = video_setting_as_string(data.srt_info.sid)
        end if
        url = ""
        if data.srt_url <> invalid
            url = data.srt_url
        else if data.srt_info <> invalid and data.srt_info.file_path <> invalid
            url = data.srt_info.file_path
        end if
        m.translated_sid = sid
        m.translated_url = url
        m.translated_lang = m.translate_to
        m.translated_language = m.translate_to_name
        previewText = ""
        if data.preview_text <> invalid and data.preview_text <> ""
            previewText = data.preview_text
        end if
        if data.srt_content <> invalid and data.srt_content <> ""
            m.translated_srt_text = data.srt_content
            if previewText = ""
                previewText = subtitlePreviewDisplayText(data.srt_content)
            end if
            showTranslatedPreview(previewText, data)
        else if previewText <> ""
            m.translated_srt_text = previewText
            showTranslatedPreview(previewText, data)
        else if url <> ""
            setSrtPreviewStatus("Downloading translated subtitle...")
            m.srt_content.text = "Translation finished. Downloading subtitle file..."
            m.translatePreviewTask = createObject("RoSGNode", "ReadsrtFile")
            m.translatePreviewTask.content = url
            m.translatePreviewTask.observeField("content", "onTranslatedSrtLoaded")
            m.translatePreviewTask.control = "RUN"
        else
            showSrtPreviewError("Translation finished but no subtitle content was returned")
        end if
        return
    end if
    msg = "Translation failed"
    if content.msg <> invalid and content.msg <> "" and content.msg <> "ok" and content.msg <> "success"
        msg = content.msg
    end if
    stopTranslatePoll()
    showSrtPreviewError(msg)
end sub

sub handleTranslateBatchResult(job as Object, content as Object)
    if content = invalid
        m.translate_batch_errors = m.translate_batch_errors + 1
        fillTranslateBatchSlots()
        return
    end if
    if content.code <> invalid and content.code = -3
        m.translate_cancelled = true
        stopTranslatePoll()
        stopAllTranslateJobs()
        msg = "This feature is only available to VIP users."
        if content.msg <> invalid and content.msg <> ""
            msg = content.msg
        end if
        showSrtPreviewError(msg)
        return
    end if
    if content.code = invalid or content.code <> 1 or content.data = invalid
        m.translate_batch_errors = m.translate_batch_errors + 1
        fillTranslateBatchSlots()
        return
    end if
    data = content.data
    if data.srt_id <> invalid
        m.translated_sid = video_setting_as_string(data.srt_id)
    else if data.sid <> invalid
        m.translated_sid = video_setting_as_string(data.sid)
    end if
    if data.srt_url <> invalid
        m.translated_url = data.srt_url
    end if
    newCues = []
    if data.srt_content <> invalid and data.srt_content <> ""
        newCues = parseSrtCues(data.srt_content)
    end if
    if newCues.Count() = 0 and data.preview_text <> invalid and data.preview_text <> ""
        sentBatch = translateBatchCuesAt(job.offset, job.count)
        previewLines = data.preview_text.Split(chr(10))
        i = 0
        while i < sentBatch.Count()
            line = ""
            if i < previewLines.Count()
                line = previewLines[i]
            end if
            cue = sentBatch[i]
            newCues.Push({
                "num": cue.num,
                "time": cue.time,
                "content": line
            })
            i = i + 1
        end while
    end if
    if newCues.Count() = 0
        m.translate_batch_errors = m.translate_batch_errors + 1
        fillTranslateBatchSlots()
        return
    end if
    i = 0
    while i < newCues.Count()
        slot = job.offset + i
        if slot < m.translate_slots.Count()
            if m.translate_slots[slot] = invalid
                m.translate_done_count = m.translate_done_count + 1
            end if
            m.translate_slots[slot] = newCues[i]
        end if
        i = i + 1
    end while
    rebuildTranslateOutCues()
    updateTranslateProgressUi()
    fillTranslateBatchSlots()
end sub

sub finishTranslateBatches(partial as Boolean)
    if m.srt_preview_mode <> "translating"
        return
    end if
    m.translate_cancelled = true
    stopAllTranslateJobs()
    stopTranslatePoll()
    if m.translate_out_cues = invalid or m.translate_out_cues.Count() = 0
        showSrtPreviewError("Translation finished but no subtitle content was returned")
        return
    end if
    m.translated_srt_text = buildSrtFromCues(m.translate_out_cues)
    m.translated_lang = m.translate_to
    m.translated_language = m.translate_to_name
    previewText = cuesToPreviewText(m.translate_out_cues)
    data = {
        "done_count": m.translate_out_cues.Count(),
        "total": m.translate_total
    }
    showTranslatedPreview(previewText, data)
    if partial = true
        setSrtPreviewStatus("Translation complete (partial)  " + m.translate_out_cues.Count().ToStr() + "/" + m.translate_total.ToStr())
    end if
end sub

sub onTranslatedSrtLoaded()
    if m.translate_cancelled = true
        return
    end if
    hideSubtitleLoading()
    if m.translatePreviewTask = invalid
        return
    end if
    content = m.translatePreviewTask.content
    if content = invalid or content = ""
        showSrtPreviewError("Translated subtitle download failed")
        return
    end if
    m.translated_srt_text = content
    showTranslatedPreview(subtitlePreviewDisplayText(content), invalid)
end sub

sub showTranslatedPreview(previewText as String, data as Dynamic)
    stopTranslateWaitUi()
    hideSubtitleLoading()
    if previewText = invalid or previewText = ""
        showSrtPreviewError("Translation succeeded but preview is empty")
        return
    end if
    m.srt_text = m.translated_srt_text
    m.srt_preview_mode = "translated"
    setSrtPreviewButtonPair("Confirm", "Back")
    setSrtPreviewTitle("Translated Subtitle")
    countText = ""
    if data <> invalid
        countText = formatTranslateCount(data.done_count, data.total)
    end if
    statusText = "Translation complete"
    if countText <> ""
        statusText = statusText + "  " + countText
    end if
    setSrtPreviewStatus(statusText)
    m.srt_content.text = clipTranslatePreview(previewText)
    m.srt_btns.setFocus(true)
    m.srt_viewbg.visible = true
end sub

sub startTranslatePoll()
    if m.translate_poll_count = invalid
        m.translate_poll_count = 0
    end if
    if m.translateTimer = invalid
        m.translateTimer = CreateObject("roSGNode", "Timer")
        m.translateTimer.duration = 3
        m.translateTimer.repeat = true
        m.translateTimer.observeField("fire", "pollSrtTranslate")
    end if
    m.translateTimer.control = "start"
end sub

sub stopTranslatePoll()
    if m.translateTimer <> invalid
        m.translateTimer.control = "stop"
    end if
end sub

sub pollSrtTranslate()
    m.translate_poll_count = m.translate_poll_count + 1
    if m.translate_poll_count > 40
        stopTranslatePoll()
        showSrtPreviewError("Translation timed out. Please try again.")
        return
    end if
    if m.translateTask <> invalid and m.translateTask.state = "run"
        return
    end if
    requestSrtTranslateApi()
end sub

sub confirmTranslatedSubtitle()
    if m.translated_srt_text = invalid or m.translated_srt_text = ""
        showSrtPreviewError("Please translate first")
        return
    end if
    if m.loading <> invalid
        return
    end if
    showSubtitleLoading()
    m.top.srt_con = m.translated_srt_text
    if m.translated_sid <> invalid
        m.top.srt_sid = m.translated_sid
    end if
    if m.translated_lang <> invalid
        m.top.srt_lang = m.translated_lang
    end if
    if m.translated_language <> invalid
        m.top.srt_language = m.translated_language
        user = CreateObject("roRegistrySection", "User")
        user.Write("select_subtitle_lang", m.translated_language)
    end if
    arr = m.top.content.moviedata
    if m.translated_sid = invalid or m.translated_sid = ""
        hideSubtitleLoading()
        m.srt_viewbg.visible = false
        if m.subtitle_ops <> invalid
            m.subtitle_ops.SetFocus(true)
        else
            m.itemsList.SetFocus(true)
        end if
        return
    end if
    arr["sid"] = m.translated_sid
    arr["type"] = "sub_select"
    m.selectContentTask = createObject("RoSGNode", "GetContentReader")
    m.selectContentTask.content = arr
    m.selectContentTask.observeField("content", "getsrtlist")
    m.selectContentTask.control = "RUN"
end sub

function OnKeyEvent(key as String, press as Boolean) as Boolean
    ' Invisible SceneGraph nodes can remain in the focus chain. If Settings is
    ' hidden, never consume or act on input; let it bubble back to HyperPlayer.
    if m.top.visible <> true
        return false
    end if

    ' Settings is a true modal input owner. Consume key releases too so an OK,
    ' Play, or D-pad release cannot bubble into HyperPlayer after a selection.
    if press = false
        return true
    end if

    result = false
    if press
        ' handle "left" key press
        if key = "up" and m.typelist.hasFocus() <> true
            if m.audiolist.hasFocus() = true
                if m.audiolist.itemFocused = invalid or m.audiolist.itemFocused <= 0
                    m.typelist.SetFocus(true)
                    return true
                end if
                return false
            end if
            if m.qualitylist.hasFocus() = true
                if m.qualitylist.itemFocused = invalid or m.qualitylist.itemFocused < 0
                    video_setting_restore_quality_focus()
                    return true
                end if
                if m.qualitylist.itemFocused <= 0
                    m.typelist.SetFocus(true)
                    return true
                end if
                return false
            end if
            if m.loading <> invalid
                return true
            end if
            if m.srt_viewbg.visible = true
                return true
            end if
            if m.language_list.hasFocus() = true
                m.letters.SetFocus(true)
                return true
            end if
            if m.more.hasFocus() = true
                m.langlist2.SetFocus(true)
                return true
            end if
            if m.opensubtitles.visible = true
                return true
            end if
            if m.subtitle_sizebg.visible = true and m.font_list.hasFocus() = true
                m.subtitle_size.SetFocus(true)
                return true
            end if
            if m.subtitle_appearancebg.visible = true and m.subtitle_text_opacity.hasFocus() = true
                m.subtitle_bg_opacity.SetFocus(true)
                return true
            end if
            if m.sub_settingbg.visible = true or m.subtitle_delaybg.visible = true or m.subtitle_sizebg.visible = true or m.subtitle_movebg.visible = true or m.subtitle_appearancebg.visible = true
                return true
            end if
            if m.setbg.visible = true and m.typelist.hasFocus() = false and m.sub_settingbg.visible = false and m.subtitle_delaybg.visible = false and m.subtitle_sizebg.visible = false and m.subtitle_movebg.visible = false and m.subtitle_appearancebg.visible = false
                if m.btn_skip.visible = true and m.btn_skip.hasFocus() = true
                    setIconBtnFocus(m.btn_skip, false)
                    m.typelist.jumpToItem = m.typelist.content.getChildCount() - 1
                    m.typelist.SetFocus(true)
                    result = true
                elseif m.btn_episodes <> invalid and m.btn_episodes.visible = true and m.btn_episodes.hasFocus() = true
                    setIconBtnFocus(m.btn_episodes, false)
                    m.typelist.jumpToItem = m.typelist.content.getChildCount() - 1
                    m.typelist.SetFocus(true)
                    result = true
                elseif m.btn2.hasFocus() = true
                    m.btn2.color = "0xffffff19"
                    m.btn2_text.color = "0xddddddff"
                    m.typelist.SetFocus(true)
                    result = true
                else
                    m.typelist.SetFocus(true)
                    result = true
                end if
            end if
        ' handle "right" key press
        else if key = "down"
            if m.audiolist.hasFocus() = true
                if m.audiolist.content <> invalid and m.audiolist.itemFocused >= m.audiolist.content.getChildCount() - 1
                    return true
                end if
                return false
            end if
            if m.qualitylist.hasFocus() = true
                if m.qualitylist.content <> invalid
                    qualityCount = m.qualitylist.content.getChildCount()
                    if qualityCount > 0
                        qualityFocus = m.qualitylist.itemFocused
                        if qualityFocus = invalid or qualityFocus < 0
                            video_setting_restore_quality_focus()
                            return true
                        end if
                        if qualityFocus >= qualityCount - 1
                            m.qualitylist.jumpToItem = qualityCount - 1
                            m.qualitylist.SetFocus(true)
                            return true
                        end if
                    end if
                end if
                return false
            end if
            if m.typelist <> invalid and m.typelist.hasFocus() = true and m.setbg.visible = true
                if m.audios.visible = true and m.audiolist <> invalid
                    if m.audiolist.content <> invalid and m.audiolist.content.getChildCount() > 0
                        m.audiolist.SetFocus(true)
                        return true
                    end if
                else if m.qualitys.visible = true and m.qualitylist <> invalid
                    video_setting_restore_quality_focus()
                    m.qualitylist.SetFocus(true)
                    return true
                else if m.subtitles.visible = true and m.categoryList <> invalid
                    m.categoryList.SetFocus(true)
                    return true
                end if
            end if
            if m.loading <> invalid
                return true
            end if
            if m.srt_viewbg.visible = true
                return true
            end if
            if m.subtitle_ops <> invalid and m.subtitle_ops.hasFocus() = true
                return true
            end if
            if m.letters.hasFocus() = true
                m.language_list.SetFocus(true)
                return true
            end if
            if m.langlist2.hasFocus() = true
                m.more.SetFocus(true)
                return true
            end if
            if m.opensubtitles.visible = true
                return true
            end if
            if m.subtitle_sizebg.visible = true and m.subtitle_size.hasFocus() = true
                m.font_list.SetFocus(true)
                return true
            end if
            if m.subtitle_appearancebg.visible = true and m.subtitle_bg_opacity.hasFocus() = true
                m.subtitle_text_opacity.SetFocus(true)
                return true
            end if
            if m.subtitle_movebg.visible = true and m.setbg.visible = false
                return true
            end if
            if m.sub_settingbg.visible = true or m.subtitle_delaybg.visible = true or m.subtitle_sizebg.visible = true or m.subtitle_movebg.visible = true or m.subtitle_appearancebg.visible = true
                return true
            end if
            if m.btn2.hasFocus() = true and m.setbg.visible = true
                m.btn2.color = "0xffffff19"
                m.btn2_text.color = "0xddddddff"
                if m.qualitys.visible = true and m.categoryList.hasFocus() = false
                    m.qualitylist.SetFocus(true)
                    result = true
                elseif m.subtitles.visible = true and m.qualitylist.hasFocus() = false and m.itemsList.hasFocus() = false
                    m.categoryList.SetFocus(true)
                    result = true
                end if
            end if
            if m.btn_skip.hasFocus() = true and m.setbg.visible = true
                setIconBtnFocus(m.btn_skip, false)
                if m.qualitys.visible = true and m.categoryList.hasFocus() = false
                    m.qualitylist.SetFocus(true)
                    result = true
                elseif m.subtitles.visible = true and m.qualitylist.hasFocus() = false and m.itemsList.hasFocus() = false
                    m.categoryList.SetFocus(true)
                    result = true
                end if
            end if
            if m.btn_episodes <> invalid and m.btn_episodes.hasFocus() = true and m.setbg.visible = true
                setIconBtnFocus(m.btn_episodes, false)
                if m.qualitys.visible = true and m.categoryList.hasFocus() = false
                    m.qualitylist.SetFocus(true)
                    result = true
                elseif m.subtitles.visible = true and m.qualitylist.hasFocus() = false and m.itemsList.hasFocus() = false
                    m.categoryList.SetFocus(true)
                    result = true
                end if
            end if
            if m.qualitys.visible = true and m.setbg.visible = true and m.typelist.hasFocus() = false and m.qualitylist.hasFocus() = false and m.categoryList.hasFocus() = false and m.btn2.hasFocus() = false and m.btn_skip.hasFocus() = false and (m.btn_episodes = invalid or m.btn_episodes.hasFocus() = false)
                m.qualitylist.SetFocus(true)
                result = true
            end if
            if m.audios.visible = true and m.setbg.visible = true and m.typelist.hasFocus() = false and m.audiolist.hasFocus() = false and m.btn2.hasFocus() = false and m.btn_skip.hasFocus() = false and (m.btn_episodes = invalid or m.btn_episodes.hasFocus() = false)
                m.audiolist.SetFocus(true)
                result = true
            end if
            if m.subtitles.visible = true and m.setbg.visible = true and m.typelist.hasFocus() = false and m.qualitylist.hasFocus() = false and m.itemsList.hasFocus() = false and (m.subtitle_ops = invalid or m.subtitle_ops.hasFocus() = false)
                m.categoryList.SetFocus(true)
                result = true
            end if
        else if key = "right"
            if m.audiolist.hasFocus() = true
                return false
            end if
            if m.loading <> invalid
                return true
            end if
            if m.srt_viewbg.visible = true and m.srt_content.hasFocus() = true
                m.srt_btns.SetFocus(true)
                return true
            end if
            if m.opensubtitles.visible = true and m.langlist2.hasFocus() = true and m.srtlist2.content <> invalid and m.srtlist2.content.getChildCount() > 0
                m.srtlist2.SetFocus(true)
                return true
            end if
            if m.languages.visible = true and m.srt_viewbg.visible = true
                return true
            end if
            if m.sub_settingbg.visible = true or m.subtitle_delaybg.visible = true or m.subtitle_sizebg.visible = true or m.subtitle_movebg.visible = true or m.subtitle_appearancebg.visible = true
                return true
            end if
            if m.itemsList.hasFocus() = true and m.subtitle_ops <> invalid
                m.preview_item = getFocusedSubtitleItem()
                m.subtitle_ops.visible = true
                m.subtitle_ops.SetFocus(true)
                return true
            end if
            if m.categoryList.hasFocus() = true
                m.itemsList.SetFocus(true)
                result = true
            end if
            if m.btn2.hasFocus() = true
                m.btn2.color = "0xffffff19"
                m.btn2_text.color = "0xddddddff"
                m.typelist.jumpToItem = 0
                m.typelist.SetFocus(true)
                result = true
            end if
            if m.btn_episodes <> invalid and m.btn_episodes.hasFocus() = true and m.btn_skip.visible = true
                setIconBtnFocus(m.btn_episodes, false)
                setIconBtnFocus(m.btn_skip, true)
                m.btn_skip.SetFocus(true)
                result = true
            else if m.typelist.hasFocus() = true and m.btn_episodes <> invalid and m.btn_episodes.visible = true
                setIconBtnFocus(m.btn_episodes, true)
                m.btn_episodes.SetFocus(true)
                result = true
            else if m.typelist.hasFocus() = true and m.btn_skip.visible = true
                setIconBtnFocus(m.btn_skip, true)
                m.btn_skip.SetFocus(true)
                result = true
            end if
        else if key = "left"
            if m.audiolist.hasFocus() = true
                return false
            end if
            if m.loading <> invalid
                return true
            end if
            if m.srt_viewbg.visible = true and m.srt_btns.hasFocus() = true
                m.srt_content.SetFocus(true)
                return true
            end if
            if m.opensubtitles.visible = true and m.srtlist2.hasFocus() = true
                m.langlist2.SetFocus(true)
                return true
            end if
            if m.languages.visible = true and m.srt_viewbg.visible = true
                return true
            end if
            if m.sub_settingbg.visible = true or m.subtitle_delaybg.visible = true or m.subtitle_sizebg.visible = true or m.subtitle_movebg.visible = true or m.subtitle_appearancebg.visible = true
                return true
            end if
            if m.subtitle_ops <> invalid and m.subtitle_ops.hasFocus() = true
                m.itemsList.SetFocus(true)
                return true
            end if
            if m.itemsList.hasFocus() = true
                m.categoryList.SetFocus(true)
                result = true
            end if
            if m.typelist.hasFocus() = true
                if m.typelist.itemFocused = 0 and m.btn2.visible = true
                    m.btn2.color = "0xffffffe5"
                    m.btn2_text.color = "0x000000ff"
                    m.btn2.SetFocus(true)
                    result = true
                end if
            end if
            if m.btn_skip.hasFocus() = true
                setIconBtnFocus(m.btn_skip, false)
                if m.btn_episodes <> invalid and m.btn_episodes.visible = true
                    setIconBtnFocus(m.btn_episodes, true)
                    m.btn_episodes.SetFocus(true)
                else
                    m.typelist.jumpToItem = m.typelist.content.getChildCount() - 1
                    m.typelist.SetFocus(true)
                end if
                result = true
            else if m.btn_episodes <> invalid and m.btn_episodes.hasFocus() = true
                setIconBtnFocus(m.btn_episodes, false)
                m.typelist.jumpToItem = m.typelist.content.getChildCount() - 1
                m.typelist.SetFocus(true)
                result = true
            end if
        else if key = "OK"
            if m.audiolist.hasFocus() = true and m.audios.visible = true
                m.top.audioSelectIndex = m.audiolist.itemFocused
                return true
            end if
            if m.btn2.hasFocus() = true
                m.setbg.visible = false
                m.sub_settingbg.visible = true
                m.subtitle_btns.SetFocus(true)
                return true
            end if
            if m.btn_skip.hasFocus() = true
                m.top.skip_request = true
                return true
            end if
            if m.btn_episodes <> invalid and m.btn_episodes.hasFocus() = true
                m.top.episode_request = true
                return true
            end if
        else if key = "back"
            ' if m.subtitle_delaybg.visible = true
            ' end if
            if m.loading <> invalid
                m.translate_cancelled = true
                stopTranslatePoll()
                m.top.removeChild(m.loading)
                m.loading = invalid
                return true
            end if
            if m.languages.visible = true
                m.languages.visible = false
                if m.lang_pick_mode = "translate"
                    m.lang_pick_mode = "opensubtitle"
                    if m.subtitle_ops <> invalid
                        m.subtitle_ops.SetFocus(true)
                    else
                        m.itemsList.SetFocus(true)
                    end if
                else
                    m.langlist2.setFocus(true)
                end if
                return true
            end if
            if m.srt_viewbg.visible = true
                if m.srt_preview_mode = "translating"
                    cancelSubtitleTranslate()
                    return true
                end if
                closeSrtPreview()
                return true
            end if
            if m.opensubtitles.visible = true
                m.opensubtitles.visible = false
                m.categoryList.SetFocus(true)
                return true
            end if
            if m.sub_settingbg.visible = true or m.subtitle_delaybg.visible = true or m.subtitle_sizebg.visible = true or m.subtitle_movebg.visible = true or m.subtitle_appearancebg.visible = true
                m.setbg.visible = true
                m.sub_settingbg.visible = false
                m.subtitle_delaybg.visible = false
                m.subtitle_sizebg.visible = false
                m.subtitle_movebg.visible = false
                m.subtitle_appearancebg.visible = false
                m.btn2.SetFocus(true)
                return true
            end if
        end if
    end if
    return result
end function