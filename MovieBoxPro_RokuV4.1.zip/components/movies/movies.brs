'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function makeMetaData()
    'database(DB) file loaction and its name
    ' DBdir = "pkg:/Database/"
    ' DBfile = DBdir + "Database.json"
    'Get artists data structure
    Content = getmovies()
    ' print Content
    'Convert to content meta-data node  
    if Content <> ""
        arr = ParseJson(Content)
    else
        arr = {"data":{}}
    end if
    if arr.data = invalid
        arr.data = {}
    end if
    ContentNode = ConvertToContentNode(arr.data)
    'return result by assigning it to top interface
    m.top.content = ContentNode
end function


function ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    count = 0
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.shortdescriptionline1 = key.name
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.quality_tag_new <> invalid
            data["quality_tag_new"] = key.quality_tag_new
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function


function getmovies()
    page = m.top.page
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Movie_list_v3"
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["year"] = ""
    arr["rating"] = ""
    arr["quality"] = ""
    arr["cid"] = []
    arr["orderby"] = "add"
    if page <> invalid
        arr["page"] = page
    else
        arr["page"] = "1"
    end if
    arr["pagelimit"] = "24"
    arr["lang"] = "en"
    arr["open_udid"] = udid
    
    result = api(arr)
    return result
end function

function api(arr)
    return mbpApiV2(arr)
end function