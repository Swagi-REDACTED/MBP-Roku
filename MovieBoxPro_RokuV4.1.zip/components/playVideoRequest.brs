
function isNaturalPlaybackFinish(video as Dynamic) as Boolean
    if video = invalid
        return false
    end if
    duration = video.duration
    position = video.position
    if duration = invalid or position = invalid or duration <= 0
        return false
    end if
    threshold = 12
    if duration < 60
        threshold = 2
    end if
    return position >= duration - threshold
end function

function toPlayInt(v as Dynamic) as Integer
    if v = invalid
        return 0
    end if
    t = Type(v)
    if t = "roString" or t = "String"
        if v = ""
            return 0
        end if
        return v.ToInt()
    end if
    return Int(v)
end function

sub showPlayLoading(playContext as Object, hidePlayer as Boolean)
    if hidePlayer = true
        if playContext.video <> invalid
            playContext.video.control = "stop"
            playContext.video.visible = false
        end if
        if playContext.video_play <> invalid
            playContext.video_play.visible = false
        end if
    end if
    if playContext.loading = invalid
        playContext.loading = createObject("RoSGNode", "Loading")
    end if
    if playContext.top <> invalid
        playContext.top.appendChild(playContext.loading)
    end if
    playContext.loading.visible = true
end sub

function playProgressCacheKey(arr as Dynamic) as String
    if arr = invalid or arr.mid = invalid
        return ""
    end if
    key = toPlayInt(arr.mid).ToStr()
    if arr.box_type <> invalid and toPlayInt(arr.box_type) = 2
        key = key + "_" + toPlayInt(arr.season).ToStr() + "_" + toPlayInt(arr.episode).ToStr()
    end if
    return key
end function

sub writePlayProgressCache(arr as Dynamic, seconds as Integer)
    key = playProgressCacheKey(arr)
    if key = ""
        return
    end if
    secReg = CreateObject("roRegistrySection", "PlayProgress")
    secReg.Write(key, seconds.ToStr())
    secReg.Flush()
end sub

function readPlayProgressCache(arr as Dynamic) as Integer
    key = playProgressCacheKey(arr)
    if key = ""
        return 0
    end if
    secReg = CreateObject("roRegistrySection", "PlayProgress")
    if secReg.Exists(key) = false
        return 0
    end if
    return toPlayInt(secReg.Read(key))
end function

sub persistPlayProgress(playContext as Object, seconds as Dynamic, overVal as Dynamic)
    sec = toPlayInt(seconds)
    overInt = toPlayInt(overVal)
    if playContext.top <> invalid and playContext.top.hasField("movieid") = true and playContext.top.movieid <> invalid and playContext.top.movieid <> ""
        arr = ParseJson(playContext.top.movieid)
        if arr <> invalid
            arr.seconds = sec
            arr.over = overInt
            playContext.top.movieid = FormatJson(arr)
            writePlayProgressCache(arr, sec)
        end if
    end if
    if playContext.moviedata <> invalid and playContext.moviedata <> ""
        arr2 = ParseJson(playContext.moviedata)
        if arr2 <> invalid
            arr2.seconds = sec
            arr2.over = overInt
            playContext.moviedata = FormatJson(arr2)
            writePlayProgressCache(arr2, sec)
        end if
    end if
end sub

function bestResumeSeconds(moviedata as Dynamic, videoinfo as Dynamic) as Integer
    sec = 0
    if moviedata <> invalid and moviedata.seconds <> invalid
        sec = toPlayInt(moviedata.seconds)
    end if
    if videoinfo <> invalid and videoinfo.seconds <> invalid
        apiSec = toPlayInt(videoinfo.seconds)
        if apiSec > sec
            sec = apiSec
        end if
    end if
    cached = readPlayProgressCache(moviedata)
    if cached > sec
        sec = cached
    end if
    return sec
end function

sub applyResumeSeconds(videoinfo as Object)
    if videoinfo = invalid
        return
    end if
    videoinfo.seconds = bestResumeSeconds(videoinfo.moviedata, videoinfo)
end sub

function startVideoContentReader(playContext as Object, videoStr as String) as Integer
    playContext.playRequestPayload = videoStr
    playContext.playRequestRetryCount = 0
    return launchVideoContentReader(playContext, videoStr)
end function

function launchVideoContentReader(playContext as Object, videoStr as String) as Integer
    if playContext.readVideoContentTask <> invalid
        if playContext.readVideoContentTask.state = "run"
            playContext.readVideoContentTask.control = "STOP"
        end if
    end if
    if playContext.playRequestId = invalid
        playContext.playRequestId = 0
    end if
    playContext.playRequestId = playContext.playRequestId + 1
    requestId = playContext.playRequestId
    playContext.readVideoContentTask = createObject("RoSGNode", "VideoContentReader")
    playContext.readVideoContentTask.requestId = requestId
    playContext.readVideoContentTask.videocontentstr = videoStr
    playContext.readVideoContentTask.observeField("videocontent", "setplaydata")
    playContext.readVideoContentTask.control = "RUN"

    if playContext.playRequestTimer <> invalid
        playContext.playRequestTimer.control = "stop"
    end if
    playContext.playRequestTimer = CreateObject("roSGNode", "Timer")
    playContext.playRequestTimer.duration = 42
    playContext.playRequestTimer.repeat = false
    playContext.playRequestTimer.ObserveField("fire", "onVideoContentRequestTimeout")
    playContext.playRequestTimer.control = "start"
    return requestId
end function

sub finishVideoContentRequest(playContext as Object)
    if playContext.playRequestTimer <> invalid
        playContext.playRequestTimer.control = "stop"
    end if
end sub

sub onVideoContentRequestTimeout()
    if m.readVideoContentTask = invalid
        return
    end if
    if m.playRequestId <> invalid and m.readVideoContentTask.requestId <> invalid and m.readVideoContentTask.requestId <> m.playRequestId
        return
    end if

    if m.readVideoContentTask.state = "run"
        m.readVideoContentTask.control = "STOP"
    end if

    if m.playRequestRetryCount = invalid
        m.playRequestRetryCount = 0
    end if
    if m.playRequestRetryCount < 1 and m.playRequestPayload <> invalid and m.playRequestPayload <> ""
        m.playRequestRetryCount = m.playRequestRetryCount + 1
        launchVideoContentReader(m, m.playRequestPayload)
        return
    end if

    finishVideoContentRequest(m)
    ' Force the normal setplaydata failure path so the loading UI cannot remain forever.
    m.readVideoContentTask.videoinfo = invalid
    m.readVideoContentTask.videocontent = CreateObject("RoSGNode", "ContentNode")
end sub

function isStaleVideoPlayRequest(playContext as Object) as Boolean
    if playContext.readVideoContentTask = invalid
        return true
    end if
    if playContext.playRequestId = invalid
        return false
    end if
    if playContext.readVideoContentTask.requestId = invalid
        return false
    end if
    return playContext.readVideoContentTask.requestId <> playContext.playRequestId
end function

sub onPlayEpisodeSelected()
    if m.video_play = invalid
        return
    end if
    ep = m.video_play.play_episode
    if ep = invalid or ep.episode = invalid
        return
    end if

    if m.timer <> invalid
        m.timer.control = "stop"
    end if
    if m.video <> invalid and m.videoinfo <> invalid
        progressSave()
    end if

    showPlayLoading(m, true)

    movieStr = invalid
    if m.top <> invalid and m.top.hasField("movieid") = true and m.top.movieid <> invalid and m.top.movieid <> ""
        movieStr = m.top.movieid
    else if m.moviedata <> invalid and m.moviedata <> ""
        movieStr = m.moviedata
    end if
    if movieStr = invalid
        return
    end if

    arr = ParseJson(movieStr)
    if arr = invalid or arr.box_type <> 2
        return
    end if

    arr.season = ep.season
    arr.episode = ep.episode
    if ep.imdb_id <> invalid
        arr.imdb_id = ep.imdb_id
    end if
    arr.seconds = toPlayInt(ep.seconds)
    arr.over = 0

    json = FormatJson(arr)
    if m.top <> invalid and m.top.hasField("movieid") = true
        m.top.movieid = json
    end if
    m.moviedata = json

    if ep.episodes <> invalid
        if m.top <> invalid and m.top.hasField("e_list") = true
            m.top.e_list = {"list": ep.episodes}
        end if
        m.elist = ep.episodes
        m.e_list2 = ep.episodes
    end if

    startVideoContentReader(m, json)
end sub
