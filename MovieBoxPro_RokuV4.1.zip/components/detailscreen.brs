'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

sub Init()
    print "detail"
    
    m.title = m.top.findNode("title")
    m.titlebg = m.top.findNode("titlebg")
    m.lang_bg = m.top.findNode("lang_bg")
    m.langtxt = m.top.findNode("lang")
    m.detail_page = m.top.findNode("detail_page")

    m.info = m.top.findNode("info")

    m.desc_bg = m.top.findNode("desc_bg")
    m.border = m.top.findNode("border")
	m.description = m.top.findNode("description")
    m.langlist_bg = m.top.findNode("langlist_bg")
    m.title_list = m.top.findNode("title_list")
    m.title_list.observeField("itemSelected","switchlang")

    m.cover = m.top.findNode("cover")

    m.trailers = m.top.findNode("Trailers")
    m.list = m.top.findNode("related")
    m.list.observeField("itemFocused","scorllpage")
    m.list.observeField("rowItemSelected","getdetail2")
    m.name = m.top.findNode("name")
    m.actor_title = m.top.findNode("actor_title")
    m.actor_list = m.top.findNode("actor_list")
    m.actor_list.observeField("rowItemSelected","onActorSelected")
    m.actor_all_bg = m.top.findNode("actor_all_bg")
    m.actor_all_list = m.top.findNode("actor_all_list")
    m.actor_all_list.observeField("itemFocused", "scrollActorAllList")
    m.actor_all_list.observeField("itemSelected", "onActorAllSelected")
    m.comment_bg = m.top.findNode("comment_bg")
    m.comment_list = m.top.findNode("comment_list")
    m.comment_empty = m.top.findNode("comment_empty")
    m.comment_list.observeField("itemSelected", "onCommentSelected")
    m.comment_detail_bg = m.top.findNode("comment_detail_bg")
    m.comment_detail_list = m.top.findNode("comment_detail_list")
    m.comment_detail_empty = m.top.findNode("comment_detail_empty")
    m.comment_detail_list.observeField("itemFocused", "onCommentDetailFocused")
    m.comment_detail_list.observeField("itemSelected", "onCommentDetailSelected")
    m.list2 = m.top.findNode("episodelist")
    m.list2.observeField("itemFocused","scorllpage2")
    m.list2.observeField("rowItemSelected","playvideo2")
    m.transAnimation = m.top.findNode("transAnimation")
    m.myInterp2 = m.top.findNode("myInterp2")

    m.seasons = m.top.findNode("seasons")
    m.seasonlist = m.top.findNode("seasonlist")

    m.addlist = m.top.findNode("addlist")
    m.movielist = m.top.findNode("movielist2")
    m.adds = m.top.findNode("addbuttons")
    m.error_tip = m.top.findNode("error_tip")
    m.error_msg = m.top.findNode("error_msg")
    m.desc_bg2 = m.top.findNode("desc_bg2")
    m.desc2 = m.top.findNode("desc2")
    m.tag_watchbg = m.top.findNode("tag_watchbg")
    m.tv_cover = m.top.findNode("tv_cover")
    m.tv_name = m.top.findNode("tv_name")
    m.progress_text = m.top.findNode("progress_text")
    m.season_watch = m.top.findNode("season_watch")
    m.addwatch_btns = m.top.findNode("addwatch_btns")
    m.watch_episodes = m.top.findNode("watch_episodes")
    m.watch_seasons = m.top.findNode("watch_seasons")
    m.seasonlist2 = m.top.findNode("seasonlist2")
    m.transAnimation2 = m.top.findNode("transAnimation2")
    m.myInterp3 = m.top.findNode("myInterp3")

    m.movielist.observeField("itemSelected","addmovielist")
    m.video2 = m.top.findNode("video2")

    m.greenPalette = createObject("roSGNode", "RSGPalette")
    m.greenPalette.colors = { DialogBackgroundColor: "0x202020FF" }
    m.error_tip.palette = m.greenPalette
    m.playRequestId = 0

    m.operates = m.top.findNode("operates")
    operates2 = m.operates
    
    focusedTargetSet1 = createObject("roSGNode", "TargetSet")
    focusedTargetSet2 = createObject("roSGNode", "TargetSet")
    focusedTargetSet3 = createObject("roSGNode", "TargetSet")
    operates2.focusedTargetSet = [ focusedTargetSet1, focusedTargetSet2, focusedTargetSet3 ]

    focusedTargetSet1.targetRects = [
        { x:0, y:0, height:70, width:360 },
        { x:380, y:0, height:70, width:80 },
        { x:480, y:0, height:70, width:80 }
    ]
    focusedTargetSet1.color = "0x00202020AA"
    focusedTargetSet1.focusIndex = 0

    focusedTargetSet2.targetRects = [
        { x:0, y:0, height:70, width:360 },
        { x:380, y:0, height:70, width:80 },
        { x:480, y:0, height:70, width:80 }
    ]
    focusedTargetSet2.color = "0x00202020AA"
    focusedTargetSet2.focusIndex = 1

    focusedTargetSet3.targetRects = [
        { x:0, y:0, height:70, width:360 },
        { x:380, y:0, height:70, width:80 },
        { x:480, y:0, height:70, width:80 }
    ]
    focusedTargetSet3.color = "0x00202020AA"
    focusedTargetSet3.focusIndex = 2

    m.operates.targetSet = operates2.focusedTargetSet[0]
    ' m.operates.showTargetRects = true
    m.operates.duration = 0
    m.operates.itemComponentName = "OperateButton"

    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "Play"
    child.Description = "Play"
    child = contentRoot.createChild("ContentNode")
    child.title = "add"
    child = contentRoot.createChild("ContentNode")
    child.title = "comment"
    m.operates.content = contentRoot
    m.has_actors = false
    m.actor_page_scroll = 0
    m.actor_all_visible_rows = 4
    m.actor_loading = false
    m.actor_all_cache = invalid
    m.detail_from_actor = false
end sub

function desc_show()
    m.desc_bg2.visible = true
end function

function titles_show()
    m.langlist_bg.visible = true
    m.title_list.setFocus(true)
end function

function contentset()
    if m.detail <> invalid
        return true
    end if
    arr = ParseJson(m.top.movieid)
    if arr.title <> invalid
        m.title.text = arr.title
        m.titlebg.width = 700
        m.lang_bg.visible = false
    end if
    if arr.cover <> invalid
        m.cover.uri = arr.cover
    end if
    if arr.box_type = 2
        m.list.visible = false
        ' m.name.visible = true
        m.list2.visible = true

        focusedTargetSet1 = createObject("roSGNode", "TargetSet")
        focusedTargetSet2 = createObject("roSGNode", "TargetSet")
        focusedTargetSet3 = createObject("roSGNode", "TargetSet")
        focusedTargetSet4 = createObject("roSGNode", "TargetSet")
        focusedTargetSet5 = createObject("roSGNode", "TargetSet")
        m.operates.focusedTargetSet = [ focusedTargetSet1, focusedTargetSet2, focusedTargetSet3, focusedTargetSet4, focusedTargetSet5 ]

        focusedTargetSet1.targetRects = [
            { x:0, y:0, height:70, width:360 },
            { x:380, y:0, height:70, width:180 },
            { x:580, y:0, height:70, width:80 },
            { x:680, y:0, height:70, width:80 },
            { x:780, y:0, height:70, width:80 }
        ]
        focusedTargetSet1.color = "0x00202020AA"
        focusedTargetSet1.focusIndex = 0

        focusedTargetSet2.targetRects = [
            { x:0, y:0, height:70, width:360 },
            { x:380, y:0, height:70, width:180 },
            { x:580, y:0, height:70, width:80 },
            { x:680, y:0, height:70, width:80 },
            { x:780, y:0, height:70, width:80 }
        ]
        focusedTargetSet2.color = "0x00202020AA"
        focusedTargetSet2.focusIndex = 1

        focusedTargetSet3.targetRects = [
            { x:0, y:0, height:70, width:360 },
            { x:380, y:0, height:70, width:180 },
            { x:580, y:0, height:70, width:80 },
            { x:680, y:0, height:70, width:80 },
            { x:780, y:0, height:70, width:80 }
        ]
        focusedTargetSet3.color = "0x00202020AA"
        focusedTargetSet3.focusIndex = 2

        focusedTargetSet4.targetRects = [
            { x:0, y:0, height:70, width:360 },
            { x:380, y:0, height:70, width:180 },
            { x:580, y:0, height:70, width:80 },
            { x:680, y:0, height:70, width:80 },
            { x:780, y:0, height:70, width:80 }
        ]
        focusedTargetSet4.color = "0x00202020AA"
        focusedTargetSet4.focusIndex = 3

        focusedTargetSet5.targetRects = [
            { x:0, y:0, height:70, width:360 },
            { x:380, y:0, height:70, width:180 },
            { x:580, y:0, height:70, width:80 },
            { x:680, y:0, height:70, width:80 },
            { x:780, y:0, height:70, width:80 }
        ]
        focusedTargetSet5.color = "0x00202020AA"
        focusedTargetSet5.focusIndex = 4
        m.operates.targetSet = m.operates.focusedTargetSet[0]
        m.operates.duration = 0
        m.operates.itemComponentName = "OperateButton"
    end if
    m.readerTask = createObject("RoSGNode","detailContentReader")
    m.readerTask.content = arr
    m.readerTask.observeField("content", "getdetail")
    m.readerTask.control = "RUN"

    if arr.box_type = 2
        arr["type"] = "watched_plan_episode"
        m.watchsTask = createObject("RoSGNode","GetContentReader")
        m.watchsTask.content = arr
        m.watchsTask.observeField("content", "watched_plan")
        m.watchsTask.control = "RUN"
    end if
end function

function getdetail()
    arr2 = m.readerTask.content
    m.detail = arr2
    if arr2.Count() = 0
        m.top.movieid = "false"
        m.error_msg.text = "Loading failed. Please return and try again"
        m.error_tip.visible = true
        return false
    end if

    if arr2.title = invalid or arr2.title_width = invalid
        return false
    end if
    m.operates.observeField("itemSelected","detailoperates")
    m.title.text = arr2.title
    m.title.width = arr2.title_width
    m.lang_bg.visible = true
    if m.lang <> invalid
        if Len(m.lang) > 2
            m.lang_bg.width = 80
            m.langtxt.width = 80
            m.titlebg.width = arr2.title_width + 112
        else
            m.lang_bg.width = 40
            m.langtxt.width = 40
            m.titlebg.width = arr2.title_width + 80
        end if
        m.langtxt.text = UCase(m.lang)
    else
        m.langtxt.text = "EN"
        m.lang_bg.width = 40
        m.langtxt.width = 40
        m.titlebg.width = arr2.title_width + 80
    end if
    m.lang_bg.translation = [ arr2.title_width+21, 8 ]
    if arr2.language.Count() = 1 and arr2.language[0].lang = ""
        m.lang_bg.visible = false
        m.titlebg.width = arr2.title_width + 16
    end if
    if arr2.box_type = 2
        m.info.text = arr2.imdb_rating+" | "+arr2.content_rating+" | "+arr2.cats
    else
        m.info.text = Str(arr2.runtime)+" minutes | "+arr2.content_rating+" | "+arr2.cats
    end if
    m.description.text = arr2.description
    m.desc2.text = arr2.description
    m.cover.uri = arr2.poster

    if arr2.box_type = 2
        if arr2.banner_mini <> ""
            m.tv_cover.uri = arr2.banner_mini
        else
            m.tv_cover.uri = arr2.poster
        end if
        m.tv_name.text = arr2.title
        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        if arr2.plan_watched = invalid
            child.title = "ADD TO WAITING"
        elseif arr2.plan_watched = 0
            child.title = "MARK AS WATCHED"
        elseif arr2.plan_watched = 1
            child.title = "ADD TO WAITING"
        end if
        child = contentRoot.createChild("ContentNode")
        if arr2.plan_watched = invalid
            child.title = "MARK AS WATCHED"
        elseif arr2.plan_watched = 0
            child.title = "REMOVE FROM WAITING"
        elseif arr2.plan_watched = 1
            child.title = "REMOVE FROM WATCHED"
        end if
        m.addwatch_btns.content = contentRoot
        m.addwatch_btns.observeField("itemSelected","add_watch")

        if arr2.history.Count() > 0
            moviearr = ParseJson(m.top.movieid)
            moviearr["season"] = arr2.history.season
            moviearr["episode"] = arr2.history.episode
            moviearr["seconds"] = arr2.history.seconds
            for each item in arr2.episode
                if arr2.history.episode = item.episode
                    moviearr["imdb_id"] = item.imdb_id
                    exit for
                end if
            end for
            m.top.movieid = FormatJson(moviearr)
            minutes = Int(arr2.history.seconds / 60)
            remainingSeconds = arr2.history.seconds - (minutes * 60)
            if remainingSeconds < 10
                remainingSeconds = "0" + remainingSeconds.ToStr()
            end if
            m.playtext = "CONTINUE S"+arr2.history.season.ToStr()+":E"+arr2.history.episode.ToStr()+" "+minutes.ToStr()+":"+remainingSeconds.ToStr()
        else
            moviearr = ParseJson(m.top.movieid)
            moviearr["season"] = 1
            moviearr["episode"] = 1
            moviearr["imdb_id"] = arr2.episode[0].imdb_id
            m.top.movieid = FormatJson(moviearr)
            m.playtext = "Play"
        end if

        moviearr = ParseJson(m.top.movieid)
        if arr2.season <> invalid
            moviearr["season_list"] = arr2.season
        end if
        if arr2.max_season <> invalid
            moviearr["max_season"] = arr2.max_season
        end if
        m.top.movieid = FormatJson(moviearr)

        m.top.e_list = {"list":arr2.episode}

        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = "Play"
        child.Description = m.playtext
        child = contentRoot.createChild("ContentNode")
        child.title = "season"
        child.Description = "Season "+arr2.episode[0]["season"].ToStr()+"/"+arr2.max_season.ToStr()
        child = contentRoot.createChild("ContentNode")
        child.title = "add"
        child = contentRoot.createChild("ContentNode")
        child.title = "watch"
        child = contentRoot.createChild("ContentNode")
        child.title = "comment"
        m.operates.content = contentRoot
        
        ' m.name.text = "Season "+arr2.episode[0]["season"].ToStr()+"/"+arr2.season.Count().ToStr() + " ( " +  arr2.episode.Count().ToStr() + " episode )"

        ContentNode = ConvertToContentNode2(arr2)
        m.list2.content = ContentNode
        m.list2.visible = true

        languages = lang_ConvertToContentNode(arr2.language)
        m.title_list.content = languages

        content2 = createObject("roSGNode", "ContentNode")
        for each item in arr2.season
            child = content2.createChild("ContentNode")
            child.title = "Season "+item.ToStr()
            child.id = item
        end for
        m.seasonlist.content = content2
        m.seasonlist.observeField("itemSelected","getseason")
        setupActorList(arr2)
    else
        moviearr = ParseJson(m.top.movieid)
        if arr2.plan_watched <> invalid
            moviearr["plan_watched"] = arr2.plan_watched
        end if
        moviearr["imdb_id"] = arr2.imdb_id
        m.top.movieid = FormatJson(moviearr)
        if arr2.seconds > 0
            minutes = Int(arr2.seconds / 60)
            remainingSeconds = arr2.seconds - (minutes * 60)
            if remainingSeconds < 10
                remainingSeconds = "0" + remainingSeconds.ToStr()
            end if
            playtext = "CONTINUE "+minutes.ToStr()+":"+remainingSeconds.ToStr()
        else
            playtext = "Play"
        end if

        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = "Play"
        child.Description = playtext
        ' child = contentRoot.createChild("ContentNode")
        ' child.title = "waiting"
        child = contentRoot.createChild("ContentNode")
        child.title = "add"
        child = contentRoot.createChild("ContentNode")
        child.title = "comment"
        m.operates.content = contentRoot

        if arr2.trailer_url_arr <> invalid and arr2.trailer_url_arr.Count() > 0
            if arr2.playlists.Count() > 0 and arr2.recommend.Count() > 0
                m.list.numRows = 3
                m.list.rowHeights = [150,230,150]
                m.list.rowItemSize = [ [260, 130], [140, 210], [266, 130] ]
            elseif arr2.recommend.Count() > 0
                m.list.numRows = 2
                m.list.rowHeights = [150,215]
                m.list.rowItemSize = [ [260, 130], [140, 210] ]
            elseif arr2.playlists.Count() > 0
                m.list.numRows = 2
                m.list.rowHeights = [150,150]
                m.list.rowItemSize = [ [260, 130], [266, 130] ]
            end if
        else
            if arr2.playlists.Count() > 0 and arr2.recommend.Count() > 0
                m.list.numRows = 2
                m.list.rowHeights = [215,150]
                m.list.rowItemSize = [ [140, 210], [266, 130] ]
            elseif arr2.playlists.Count() > 0
                m.list.numRows = 1
                m.list.rowHeights = [150]
                m.list.rowItemSize = [ [266, 130] ]
            else
                m.list.numRows = 1
                m.list.rowHeights = [215]
                m.list.rowItemSize = [ [140, 210] ]
            end if
        end if

        ContentNode = related_ConvertToContentNode(arr2)
        m.list.content = ContentNode
        if arr2.recommend.Count() = 0 and arr2.playlists.Count() = 0 and arr2.trailer_url_arr.Count() = 0
            m.related = false
        else
            m.related = true
        end if

        languages = lang_ConvertToContentNode(arr2.language)
        m.title_list.content = languages
        setupActorList(arr2)

        ' if arr2.trailer_url_arr <> invalid and arr2.trailer_url_arr.Count() > 0
        '     m.list.numRows = 2
        '     m.list.rowHeights = [120,215]
        '     m.list.rowItemSize = [ [185, 100], [120, 194] ]
        '     ContentNode2 = trailer_ConvertToContentNode(arr2)
        '     m.list.content = ContentNode2
        ' else
        '     ContentNode = ConvertToContentNode(arr2.recommend)
        '     m.list.content = ContentNode
        ' end if
    end if
end function

sub setupActorList(arr2)
    if arr2.actor_list = invalid or arr2.actor_list.Count() = 0
        m.actor_title.visible = false
        m.actor_list.visible = false
        m.list.translation = [80, 450]
        m.list2.translation = [40, 450]
        m.has_actors = false
        m.actor_page_scroll = 0
        return
    end if

    m.has_actors = true
    m.actor_page_scroll = 160
    m.actor_title.visible = true
    m.actor_list.visible = true
    moviearr = ParseJson(m.top.movieid)
    m.actor_fetch_data = {"mid": moviearr.mid, "box_type": moviearr.box_type, "lang": m.lang}
    if m.actor_fetch_data.lang = invalid or m.actor_fetch_data.lang = ""
        m.actor_fetch_data.lang = "en"
    end if

    actorTotal = arr2.actor_total
    if actorTotal = invalid
        actorTotal = arr2.actor_list.Count()
    end if
    seeAllThreshold = 4
    actorX = 80
    belowListY = 610
    if moviearr.box_type = 2
        seeAllThreshold = 10
        actorX = 40
    end if

    m.actor_title.translation = [actorX, 438]
    m.actor_list.translation = [actorX, 488]
    m.actor_list.focusXOffset = [4]

    ContentNode = actor_ConvertToContentNode(arr2.actor_list, actorTotal, seeAllThreshold)
    m.actor_list.content = ContentNode
    m.list.translation = [80, belowListY]
    m.list2.translation = [40, belowListY]
end sub

function actor_ConvertToContentNode(actors, total as Integer, seeAllThreshold as Integer) as Object
    ContentNode = createObject("RoSGNode", "ContentNode")
    row = ContentNode.createChild("ContentNode")
    for each actor in actors
        child = row.createChild("ContentNode")
        if actor.name <> invalid
            child.title = actor.name
        end if
        if actor.role <> invalid
            child.description = actor.role
        end if
        if actor.type <> invalid
            child.shortdescriptionline1 = actor.type
        end if
        if actor.avatar <> invalid
            child.hdposterurl = actor.avatar
        end if
        if actor.new_name <> invalid
            child.shortdescriptionline2 = actor.new_name
        end if
        if actor.actor_id <> invalid
            child.addField("actorId", "string", false)
            child.actorId = actor.actor_id.ToStr()
            child.id = actor.actor_id
        end if
    end for
    if total > seeAllThreshold
        child = row.createChild("ContentNode")
        child.title = "See All"
        child.description = "see_all"
    end if
    return ContentNode
end function

function actor_ConvertToGridContentNode(actors) as Object
    ContentNode = createObject("RoSGNode", "ContentNode")
    for i = 0 to actors.Count() - 1
        actor = actors[i]
        if actor <> invalid
            child = ContentNode.createChild("ContentNode")
            if actor.name <> invalid
                child.title = actor.name
            end if
            if actor.role <> invalid
                child.description = actor.role
            end if
            if actor.type <> invalid
                child.shortdescriptionline1 = actor.type
            end if
            if actor.avatar <> invalid and actor.avatar <> ""
                child.hdposterurl = actor.avatar
            end if
            if actor.new_name <> invalid
                child.shortdescriptionline2 = actor.new_name
            end if
            if actor.actor_id <> invalid
                child.addField("actorId", "string", false)
                child.actorId = actor.actor_id.ToStr()
            end if
        end if
    end for
    return ContentNode
end function

function getActorIdFromContent(item as Object) as String
    if item = invalid
        return ""
    end if
    if item.actorId <> invalid and item.actorId <> ""
        return item.actorId
    end if
    if item.id <> invalid
        return item.id.ToStr()
    end if
    return ""
end function

sub openActorDetail(actorId as Dynamic)
    actorIdStr = actorId.ToStr()
    if actorIdStr = ""
        return
    end if
    m.actorDetail = createObject("roSGNode", "ActorScreen")
    m.actorDetail.actorId = actorIdStr
    if m.lang <> invalid and m.lang <> ""
        m.actorDetail.lang = m.lang
    else
        m.actorDetail.lang = "en"
    end if
    m.actorDetail.observeField("workSelected", "onActorWorkSelected")
    m.top.appendChild(m.actorDetail)
end sub

sub onActorWorkSelected()
    if m.actorDetail = invalid or m.actorDetail.workSelected = invalid or m.actorDetail.workSelected = ""
        return
    end if
    m.detail_from_actor = true
    m.moviedata = m.actorDetail.workSelected
    m.actorDetail.visible = false
    m.detail2 = createObject("roSGNode", "DetailScreen")
    m.detail2.movieid = m.moviedata
    m.top.appendChild(m.detail2)
    m.operates2 = m.detail2.findNode("operates")
    m.operates2.setFocus(true)
    m.actorDetail.workSelected = ""
end sub

sub showActorAllFromCache()
    m.actor_all_list.numRows = m.actor_all_visible_rows
    m.actor_all_list.content = m.actor_all_cache
    m.actor_all_list.jumpToItem = 0
    m.actor_all_bg.visible = true
    m.actor_all_list.setFocus(true)
end sub

sub onActorSelected()
    if m.actor_list.rowItemSelected = invalid
        return
    end if
    rowIndex = m.actor_list.rowItemSelected[0]
    itemIndex = m.actor_list.rowItemSelected[1]
    row = m.actor_list.content.getChild(rowIndex)
    if row = invalid
        return
    end if
    aa = row.getChild(itemIndex)
    if aa = invalid
        return
    end if
    if aa.description = "see_all"
        showAllActors()
    else
        actorId = getActorIdFromContent(aa)
        if actorId <> ""
            openActorDetail(actorId)
        end if
    end if
end sub

sub onActorAllSelected()
    index = m.actor_all_list.itemSelected
    if index = invalid or index < 0
        return
    end if
    aa = m.actor_all_list.content.getChild(index)
    actorId = getActorIdFromContent(aa)
    if actorId <> ""
        openActorDetail(actorId)
    end if
end sub

sub showAllActors()
    if m.actor_fetch_data = invalid
        return
    end if
    if m.actor_all_cache <> invalid
        showActorAllFromCache()
        return
    end if
    if m.actor_loading = true
        return
    end if
    if m.actorTask <> invalid and m.actorTask.state = "RUN"
        return
    end if
    m.actor_loading = true
    m.actorTask = createObject("RoSGNode", "actorContentReader")
    fetchData = m.actor_fetch_data
    fetchData.pagelimit = 1000
    m.actorTask.content = fetchData
    m.actorTask.observeField("content", "onAllActorsLoaded")
    m.actorTask.control = "RUN"
end sub

sub onAllActorsLoaded()
    m.actor_loading = false
    result = m.actorTask.content
    if result = invalid or result.list = invalid or result.list.Count() = 0
        return
    end if
    ContentNode = actor_ConvertToGridContentNode(result.list)
    m.actor_all_cache = ContentNode
    showActorAllFromCache()
end sub

sub scrollActorAllList()
    if m.actor_all_bg.visible = false
        return
    end if
    index = m.actor_all_list.itemFocused
    if index = invalid or index < 0
        return
    end if
    m.actor_all_list.jumpToItem = index
end sub

sub getdetail2()
    aa = m.list.content.getChild(m.list.rowItemFocused[0]).getChild(m.list.rowItemFocused[1])
    if aa.Description = "playlist"
        data = {"id":aa.data.lid}
        m.list_detail = createObject("roSGNode", "PlayList2")
        m.list_detail.arr = data
        m.top.appendChild(m.list_detail)
      return
    end if
    if m.list.rowItemFocused[0] = 0 and aa.title = ""
        if m.loading <> invalid
            return
        end if
        m.loading = CreateObject("roSGNode", "Loading")
        m.top.appendChild(m.loading)
        m.playtrailer = 1
        m.trailerDataTask = CreateObject("roSGNode", "GetContentReader")
        m.trailerDataTask.content = {"type":"trailer","vid":aa.data.vid}
        m.trailerDataTask.observeField("content", "play_trailer")
        m.trailerDataTask.control = "RUN"
        return
    end if
    arr3 = aa.data
    arr3["title"] = aa.title
    arr3["cover"] = aa.hdposterurl
    m.moviedata = FormatJson(arr3)
    m.detail2 = createObject("roSGNode", "DetailScreen")
    m.detail2.movieid = m.moviedata
    m.top.appendChild(m.detail2)
    m.operates2 = m.detail2.findNode("operates")
    m.operates2.setFocus(true)
end sub

function getActorScrollExtra() as Integer
    if m.has_actors = true and m.actor_page_scroll <> invalid
        return m.actor_page_scroll
    end if
    return 0
end function

sub scrollDetailPageTo(targetY as Float)
    currentY = m.detail_page.translation[1]
    if currentY = targetY
        return
    end if
    m.myInterp2.keyValue = [ [0.0, currentY], [0.0, targetY] ]
    m.transAnimation.control = "start"
end sub

function scorllpage()
    extra = getActorScrollExtra()
    index = m.list.itemFocused
    if index = 0
        if m.ordindex <> invalid and m.ordindex = 1
            scrollDetailPageTo(-218.0 - extra)
        elseif extra > 0 and m.ordindex <> invalid and m.ordindex > 0
            scrollDetailPageTo(-198.0 - extra)
        end if
        m.ordindex = 0
    elseif index = 1
        if m.ordindex <> invalid and m.ordindex = 2
            scrollDetailPageTo(-406.0 - extra)
        elseif m.ordindex <> 1
            scrollDetailPageTo(-218.0 - extra)
        end if
        m.ordindex = 1
    elseif index = 2 and m.ordindex <> 2
        scrollDetailPageTo(-406.0 - extra)
        m.ordindex = 2
    end if
end function

function scorllpage2()
    extra = getActorScrollExtra()
    index = m.list2.itemFocused
    row1Scroll = -198.0 - extra
    if index = 0
        if m.ordindex <> invalid and m.ordindex = 1
            if extra > 0
                scrollDetailPageTo(-extra)
            else
                scrollDetailPageTo(0.0)
            end if
        end if
        m.ordindex = 0
    elseif index = 1
        if m.ordindex <> invalid and m.ordindex <> 1
            scrollDetailPageTo(row1Scroll)
        end if
        m.ordindex = 1
    end if
end function

sub play_trailer()
    if m.trailerDataTask.content.type <> invalid
        return
    end if
    if m.trailerDataTask.content = invalid or m.trailerDataTask.content.code = invalid
        m.error_msg.text = "Playback failed"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if m.trailerDataTask.content.code <= 0
        m.error_msg.text = m.trailerDataTask.content.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if

    if m.loading = invalid
        return
    end if
    m.top.removeChild(m.loading)
    m.loading = invalid
    
    content = m.trailerDataTask.content
    videocontent = createObject("RoSGNode","ContentNode")
    videocontent.setField("title","Trailer")
    videocontent.setField("url",content.data.best_link)
    m.video2.visible = true
    m.video2.content = videocontent
    m.video2.control = "play"
    m.video2.observeField("state", "controlvideoplay2")
    m.video2.setFocus(true)
end sub

function watched_plan()
    result = m.watchsTask.content
    if result.type <> invalid
        return false
    end if
    if result.data.Count() = 0
        return false
    end if
    
    m.watch_episode_list = result.data
    content = watch_ConvertToContentNode(result.data.episode_progress_list)
    if m.over_episode_count > 0
        progress = RoundToOneDecimalPlace((m.over_episode_count/m.episode_count)*100)
        m.progress_text.text = progress.ToStr()+"% WATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
    else
        m.progress_text.text = "UNWATCHED "+ "0/"+ m.episode_count.ToStr() + " EPISODES"
    end if
    num = result.data.episode_progress_list.Count()
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "SEASON 1/"+num.ToStr()
    child.description = "season"
    child = contentRoot.createChild("ContentNode")
    child.title = "watch_btn"
    child.description = "season"
    if m.season_over = 1
        child.shortdescriptionline1 = "1"
    else
        child.shortdescriptionline1 = "0"
    end if
    m.season_watch.content = contentRoot
    m.season_watch.observeField("itemSelected","getseasons2")
    m.watch_episodes.content = content
    m.watch_episodes.observeField("itemSelected","episode_over")
    contentRoot2 = createObject("roSGNode", "ContentNode")
    i = 0
    for each key in result.data.episode_progress_list
        child = contentRoot2.createChild("ContentNode")
        child.title = "Season "+key.season.ToStr()
        child.description = key.season.ToStr()
        child.id = i
        i++
    end for
    m.seasonlist2.content = contentRoot2
    m.seasonlist2.observeField("itemSelected","switch_season")
end function

sub add_watch()
    if m.markTask <> invalid
        if m.markTask.control <> "stop"
            return
        end if
    end if
    index = m.addwatch_btns.itemSelected
    if index = 0
        arr = ParseJson(m.top.movieid)
        if m.detail.plan_watched <> invalid and m.detail.plan_watched = 1
            arr["type"] = "watch_plan_mark"
            arr["watched"] = 0
            m.watched = 0
        elseif m.detail.plan_watched <> invalid and m.detail.plan_watched = 0
            arr["type"] = "watch_plan_mark"
            arr["watched"] = 1
            m.watched = 1
        else
            arr["type"] = "watch_plan_add"
            arr["watched"] = 0
            m.watched = 0
        end if
    elseif index = 1
        arr = ParseJson(m.top.movieid)
        if m.detail.plan_watched <> invalid and m.detail.plan_watched = 0
            arr["type"] = "watch_plan_del"
            m.watched = -1
        elseif m.detail.plan_watched <> invalid and m.detail.plan_watched = 1
            arr["type"] = "watch_plan_del"
            m.watched = -1
        else
            arr["type"] = "watch_plan_add"
            arr["watched"] = 1
            m.watched = 1
        end if
    end if
    m.markTask = createObject("RoSGNode","GetContentReader")
    m.markTask.content = arr
    m.markTask.observeField("content", "watch_mark")
    m.markTask.control = "RUN"
end sub

sub watch_mark()
    ' print m.watched
    if m.watched = -1
        m.detail.plan_watched = invalid
        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = "ADD TO WAITING"
        child = contentRoot.createChild("ContentNode")
        child.title = "MARK AS WATCHED"
        m.addwatch_btns.content = contentRoot
        m.over_episode_count = 0
        aa = m.season_watch.content.getChild(1)
        aa.Update({"shortdescriptionline1":"0"}, false)
        for i=0 to m.watch_episode_list.episode_progress_list.Count() - 1
            for h=0 to m.watch_episode_list.episode_progress_list[i].episode_list.Count() - 1
                m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 0
            end for
        end for
        m.progress_text.text = "UNWATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
        for j = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(j)
            episode.update({"shortdescriptionline1":"0"}, false)
        end for
    elseif m.watched = 0
        m.detail.plan_watched = 0
        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = "MARK AS WATCHED"
        child = contentRoot.createChild("ContentNode")
        child.title = "REMOVE FROM WAITING"
        m.addwatch_btns.content = contentRoot
        m.over_episode_count = 0
        aa = m.season_watch.content.getChild(1)
        aa.Update({"shortdescriptionline1":"0"}, false)
        for i=0 to m.watch_episode_list.episode_progress_list.Count() - 1
            for h=0 to m.watch_episode_list.episode_progress_list[i].episode_list.Count() - 1
                m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 0
            end for
        end for
        m.progress_text.text = "UNWATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
        for j = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(j)
            episode.update({"shortdescriptionline1":"0"}, false)
        end for
    elseif m.watched = 1
        m.detail.plan_watched = 1
        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = "ADD TO WAITING"
        child = contentRoot.createChild("ContentNode")
        child.title = "REMOVE FROM WATCHED"
        m.addwatch_btns.content = contentRoot
        m.over_episode_count = 0
        aa = m.season_watch.content.getChild(1)
        aa.Update({"shortdescriptionline1":"1"}, false)
        for i=0 to m.watch_episode_list.episode_progress_list.Count() - 1
            for h=0 to m.watch_episode_list.episode_progress_list[i].episode_list.Count() - 1
                m.over_episode_count++
                m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 1
            end for
        end for
        m.progress_text.text = "100% WATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
        for j = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(j)
            episode.update({"shortdescriptionline1":"1"}, false)
        end for
    end if
end sub

sub getseasons2()
    index = m.season_watch.itemSelected
    if index = 0
        m.watch_seasons.visible = true
        m.seasonlist2.setFocus(true)
    elseif index = 1
        arr = ParseJson(m.top.movieid)
        arr["type"] = "tv_over"
        arr["season"] = m.current_season
        if m.season_over = 1
            arr["over"] = 0
        else
            arr["over"] = 1
        end if
        m.markTask2 = createObject("RoSGNode","GetContentReader")
        m.markTask2.content = arr
        m.markTask2.observeField("content", "season_over")
        m.markTask2.control = "RUN"
    end if
end sub

sub switch_season()
    aa = m.seasonlist2.content.getChild(m.seasonlist2.itemSelected)
    key = aa.id
    content = watch_ConvertToContentNode2(m.watch_episode_list.episode_progress_list[key.ToInt()])
    m.watch_episodes.content = content
    num = m.watch_episode_list.episode_progress_list.Count()
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "SEASON "+aa.Description+"/"+num.ToStr()
    child.description = "season"
    child = contentRoot.createChild("ContentNode")
    child.title = "watch_btn"
    child.description = "season"
    if m.season_over = 1
        child.shortdescriptionline1 = "1"
    else
        child.shortdescriptionline1 = "0"
    end if
    m.season_watch.content = contentRoot
    m.watch_seasons.visible = false
    m.season_watch.setFocus(true)
end sub

sub season_over()
    aa = m.season_watch.content.getChild(1)
    if m.season_over = 1
        aa.Update({"shortdescriptionline1":"0"}, false)
        m.season_over = 0
        pp = 0
        for i = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(i)
            episode.update({"shortdescriptionline1":"0"}, false)
        end for
    else
        aa.Update({"shortdescriptionline1":"1"}, false)
        m.season_over = 1
        pp = 1
        for i = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(i)
            episode.update({"shortdescriptionline1":"1"}, false)
        end for
    end if
    m.over_episode_count = 0
    for i=0 to m.watch_episode_list.episode_progress_list.Count() - 1
        for h=0 to m.watch_episode_list.episode_progress_list[i].episode_list.Count() - 1
            if m.watch_episode_list.episode_progress_list[i].episode_list[h].season = m.current_season
                if pp = 1
                    m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 1
                else
                    m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 0
                end if
            end if
            if m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 1
                m.over_episode_count++
            end if
        end for
    end for
    progress = RoundToOneDecimalPlace((m.over_episode_count/m.episode_count)*100)
    m.progress_text.text = progress.ToStr()+"% WATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
end sub

sub episode_over()
    aa = m.watch_episodes.content.getChild(m.watch_episodes.itemSelected)
    bb = m.season_watch.content.getChild(1)
    arr = ParseJson(m.top.movieid)
    arr["type"] = "tv_over"
    arr["season"] = m.current_season
    arr["episode"] = aa.data.episode
    if aa.shortdescriptionline1 = "1"
        aa.Update({"shortdescriptionline1":"0"}, false)
        bb.Update({"shortdescriptionline1":"0"}, false)
        pp = 0
        arr["over"] = 0
    else
        aa.Update({"shortdescriptionline1":"1"}, false)
        pp = 1
        arr["over"] = 1
        over = 1
        for i = 0 to m.watch_episodes.content.getChildCount() - 1
            episode = m.watch_episodes.content.getChild(i)
            if episode.shortdescriptionline1 = "0"
                over = 0
            end if
        end for
        if over = 1
            bb.Update({"shortdescriptionline1":"1"}, false)
        end if
    end if

    m.markTask3 = createObject("RoSGNode","GetContentReader")
    m.markTask3.content = arr
    m.markTask3.control = "RUN"

    for i=0 to m.watch_episode_list.episode_progress_list.Count() - 1
        for h=0 to m.watch_episode_list.episode_progress_list[i].episode_list.Count() - 1
            if m.watch_episode_list.episode_progress_list[i].episode_list[h].season = m.current_season
                if m.watch_episode_list.episode_progress_list[i].episode_list[h].episode = aa.data.episode
                    if pp = 1
                        m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 1
                    else
                        m.watch_episode_list.episode_progress_list[i].episode_list[h].over = 0
                    end if
                end if
            end if
        end for
        if m.watch_episode_list.episode_progress_list[i].season = m.current_season
            exit for
        end if
    end for
    if pp = 1
        m.over_episode_count = m.over_episode_count+1
    else
        m.over_episode_count = m.over_episode_count-1
    end if
    progress = RoundToOneDecimalPlace((m.over_episode_count/m.episode_count)*100)
    m.progress_text.text = progress.ToStr()+"% WATCHED "+ m.over_episode_count.ToStr() +"/"+ m.episode_count.ToStr() + " EPISODES"
end sub

sub switchlang()
    item = m.title_list.content.getChild(m.title_list.itemSelected)
    lang = item.Description
    arr = ParseJson(m.top.movieid)
    arr["lang"] = lang
    m.lang = lang
    m.readerTask = createObject("RoSGNode","detailContentReader")
    m.readerTask.content = arr
    m.readerTask.observeField("content", "getdetail")
    m.readerTask.control = "RUN"
    m.langlist_bg.visible = false
end sub

sub detailoperates()
    if m.operates.itemSelected = 0
        m.top.e_list = {"list":m.detail.episode}
        playvideo()
    elseif m.operates.itemSelected = 1 and m.detail.box_type = 2
        m.seasons.visible = true
        m.seasonlist.setFocus(true)
    elseif m.operates.itemSelected = 1 and m.detail.box_type = 1
        addshow()
    elseif m.operates.itemSelected = 2 and m.detail.box_type = 1
        showComments()
    elseif m.operates.itemSelected = 2 and m.detail.box_type = 2
        addshow()
    elseif m.operates.itemSelected = 3 and m.detail.box_type = 2
        if m.watch_episodes.content <> invalid
            m.tag_watchbg.visible = true
            m.addwatch_btns.setFocus(true)
        else
            arr = ParseJson(m.top.movieid)
            arr["type"] = "watched_plan_episode"
            m.watchsTask = createObject("RoSGNode","GetContentReader")
            m.watchsTask.content = arr
            m.watchsTask.observeField("content", "watched_plan")
            m.watchsTask.control = "RUN"
            m.tag_watchbg.visible = true
            m.addwatch_btns.setFocus(true)
        end if
    elseif m.operates.itemSelected = 4 and m.detail.box_type = 2
        showComments()
    end if
end sub

sub showComments()
    arr = ParseJson(m.top.movieid)
    arr["type"] = "comment_list"
    arr["page"] = 1
    arr["sort"] = "update_time_desc"
    m.commentTask = createObject("RoSGNode", "GetContentReader")
    m.commentTask.content = arr
    m.commentTask.observeField("content", "onCommentList")
    m.commentTask.control = "RUN"
    m.comment_empty.visible = false
    m.comment_list.content = createObject("roSGNode", "ContentNode")
    m.comment_bg.visible = true
    m.comment_list.setFocus(true)
end sub

sub onCommentList()
    result = m.commentTask.content
    if result = invalid or result.type <> invalid
        return
    end if
    if result.code = invalid or result.code <> 1 or result.data = invalid or result.data.list = invalid
        m.comment_list.content = createObject("roSGNode", "ContentNode")
        m.comment_empty.visible = true
        m.comment_empty.text = "No comments yet"
        m.comment_list.setFocus(true)
        return
    end if
    list = result.data.list
    if list.Count() = 0
        m.comment_list.content = createObject("roSGNode", "ContentNode")
        m.comment_empty.visible = true
        m.comment_empty.text = "No comments yet"
        m.comment_list.setFocus(true)
        return
    end if
    m.comment_empty.visible = false
    m.comment_list.content = comment_ConvertToContentNode(list)
    m.comment_list.setFocus(true)
end sub

function comment_ConvertToContentNode(list as Object) as Object
    ContentNode = createObject("roSGNode", "ContentNode")
    moviearr = ParseJson(m.top.movieid)
    for each item in list
        replyTo = commentReplyToFromItem(item)
        appendCommentListItem(ContentNode, item, moviearr, 0, replyTo, "list", false)
    end for
    return ContentNode
end function

sub onCommentSelected()
    if m.comment_list.content = invalid
        return
    end if
    item = m.comment_list.content.getChild(m.comment_list.itemSelected)
    if item = invalid or item.data = invalid or item.data.comment_id = invalid
        return
    end if
    showCommentDetail(item.data)
end sub

sub onCommentDetailSelected()
    if m.comment_detail_list.content = invalid
        return
    end if
    item = m.comment_detail_list.content.getChild(m.comment_detail_list.itemSelected)
    if item = invalid or item.data = invalid or item.data.comment_id = invalid
        return
    end if
    if m.commentDetailState <> invalid and m.commentDetailState.comment_id <> invalid
        if item.data.comment_id = m.commentDetailState.comment_id
            return
        end if
    end if
    if item.hasField("isOwn") and item.isOwn = true
        return
    end if
    showCommentDetail(item.data)
end sub

sub showCommentDetail(data as Object)
    m.commentDetailState = {
        "mid": data.mid,
        "box_type": data.box_type,
        "comment_id": data.comment_id,
        "parentPage": 1,
        "childPage": 1,
        "parentHasMore": true,
        "childHasMore": true,
        "loadingParent": false,
        "loadingChild": false,
        "ownName": "",
        "ready": false
    }
    arr = CreateObject("roAssociativeArray")
    arr["type"] = "comment_detail"
    arr["mid"] = data.mid
    arr["box_type"] = data.box_type
    arr["comment_id"] = data.comment_id
    arr["sort"] = "update_time_desc"
    m.commentDetailTask = createObject("RoSGNode", "GetContentReader")
    m.commentDetailTask.content = arr
    m.commentDetailTask.observeField("content", "onCommentDetail")
    m.commentDetailTask.control = "RUN"
    m.comment_detail_empty.visible = false
    m.comment_detail_list.content = createObject("roSGNode", "ContentNode")
    m.comment_detail_bg.visible = true
    m.comment_detail_list.setFocus(true)
end sub

sub onCommentDetail()
    result = m.commentDetailTask.content
    if result = invalid or result.type <> invalid
        return
    end if
    if result.code = invalid or result.code <> 1 or result.data = invalid
        m.comment_detail_list.content = createObject("roSGNode", "ContentNode")
        m.comment_detail_empty.visible = true
        m.comment_detail_list.setFocus(true)
        return
    end if
    if m.commentDetailState <> invalid
        if result.data.parent_has_more <> invalid
            m.commentDetailState.parentHasMore = result.data.parent_has_more
        end if
        if result.data.child_has_more <> invalid
            m.commentDetailState.childHasMore = result.data.child_has_more
        end if
    end if
    ContentNode = commentDetail_ConvertToContentNode(result.data)
    if ContentNode.getChildCount() = 0
        m.comment_detail_empty.visible = true
    else
        m.comment_detail_empty.visible = false
    end if
    m.comment_detail_list.content = ContentNode
    if m.commentDetailState <> invalid
        m.commentDetailState.ready = true
    end if
    ownIndex = findOwnCommentIndex(ContentNode)
    if ownIndex >= 0
        m.comment_detail_list.jumpToItem = ownIndex
    end if
    m.comment_detail_list.setFocus(true)
end sub

function findOwnCommentIndex(ContentNode as Object) as Integer
    if ContentNode = invalid
        return -1
    end if
    count = ContentNode.getChildCount()
    i = 0
    while i < count
        child = ContentNode.getChild(i)
        if child <> invalid and child.hasField("isOwn") and child.isOwn = true
            return i
        end if
        i = i + 1
    end while
    return -1
end function

function commentDetail_ConvertToContentNode(data as Object) as Object
    ContentNode = createObject("roSGNode", "ContentNode")
    moviearr = ParseJson(m.top.movieid)
    ownName = ""
    ownReplyTo = ""

    if data.parent_list <> invalid
        for each item in data.parent_list
            replyTo = commentReplyToFromItem(item)
            appendCommentListItem(ContentNode, item, moviearr, 0, replyTo, "detail", false)
        end for
    end if

    if data.own_list <> invalid
        for each item in data.own_list
            if item.username <> invalid
                ownName = item.username
            end if
            ownReplyTo = commentReplyToFromItem(item)
            if ownReplyTo = "" and data.parent_list <> invalid and data.parent_list.Count() > 0
                lastParent = data.parent_list[data.parent_list.Count() - 1]
                if lastParent <> invalid and lastParent.username <> invalid
                    ownReplyTo = lastParent.username
                end if
            end if
            appendCommentListItem(ContentNode, item, moviearr, 0, ownReplyTo, "detail", true)
        end for
    end if

    if m.commentDetailState <> invalid
        m.commentDetailState.ownName = ownName
    end if

    if data.children_list <> invalid
        appendCommentChildren(ContentNode, data.children_list, moviearr, ownName)
    end if
    return ContentNode
end function

sub appendCommentChildren(ContentNode as Object, children_list as Object, moviearr as Object, ownName as String)
    for each item in children_list
        childName = ""
        if item.username <> invalid
            childName = item.username
        end if
        replyTo = commentReplyToFromItem(item)
        if replyTo = ""
            replyTo = ownName
        end if
        appendCommentListItem(ContentNode, item, moviearr, 1, replyTo, "detail", false)
        if item.son_reply <> invalid
            for each reply in item.son_reply
                replyToName = commentReplyToFromItem(reply)
                if replyToName = ""
                    replyToName = childName
                end if
                if replyToName = ""
                    replyToName = ownName
                end if
                appendCommentListItem(ContentNode, reply, moviearr, 1, replyToName, "detail", false)
            end for
        end if
    end for
end sub

sub onCommentDetailFocused()
    if m.comment_detail_bg.visible = false
        return
    end if
    if m.commentDetailState = invalid or m.commentDetailState.ready <> true
        return
    end if
    content = m.comment_detail_list.content
    if content = invalid
        return
    end if
    focused = m.comment_detail_list.itemFocused
    count = content.getChildCount()
    if focused <= 1
        loadMoreCommentParents()
    end if
    if count > 0 and focused >= count - 2
        loadMoreCommentChildren()
    end if
end sub

sub loadMoreCommentParents()
    state = m.commentDetailState
    if state = invalid or state.loadingParent = true or state.parentHasMore <> true
        return
    end if
    state.loadingParent = true
    arr = CreateObject("roAssociativeArray")
    arr["type"] = "comment_detail_parent"
    arr["mid"] = state.mid
    arr["box_type"] = state.box_type
    arr["comment_id"] = state.comment_id
    arr["page"] = state.parentPage + 1
    arr["sort"] = "update_time_desc"
    m.commentParentTask = createObject("RoSGNode", "GetContentReader")
    m.commentParentTask.content = arr
    m.commentParentTask.observeField("content", "onCommentDetailParents")
    m.commentParentTask.control = "RUN"
end sub

sub loadMoreCommentChildren()
    state = m.commentDetailState
    if state = invalid or state.loadingChild = true or state.childHasMore <> true
        return
    end if
    state.loadingChild = true
    arr = CreateObject("roAssociativeArray")
    arr["type"] = "comment_detail_child"
    arr["mid"] = state.mid
    arr["box_type"] = state.box_type
    arr["comment_id"] = state.comment_id
    arr["page"] = state.childPage + 1
    arr["sort"] = "update_time_desc"
    m.commentChildTask = createObject("RoSGNode", "GetContentReader")
    m.commentChildTask.content = arr
    m.commentChildTask.observeField("content", "onCommentDetailChildren")
    m.commentChildTask.control = "RUN"
end sub

sub onCommentDetailParents()
    result = m.commentParentTask.content
    if m.commentDetailState <> invalid
        m.commentDetailState.loadingParent = false
    end if
    if result = invalid or result.type <> invalid
        return
    end if
    if result.code = invalid or result.code <> 1 or result.data = invalid
        if m.commentDetailState <> invalid
            m.commentDetailState.parentHasMore = false
        end if
        return
    end if
    if result.data.has_more <> invalid
        m.commentDetailState.parentHasMore = result.data.has_more
    else
        m.commentDetailState.parentHasMore = false
    end if
    list = result.data.list
    if list = invalid or list.Count() = 0
        m.commentDetailState.parentHasMore = false
        return
    end if
    m.commentDetailState.parentPage = m.commentDetailState.parentPage + 1

    content = m.comment_detail_list.content
    if content = invalid
        return
    end if
    moviearr = ParseJson(m.top.movieid)
    temp = createObject("roSGNode", "ContentNode")
    for each item in list
        replyTo = commentReplyToFromItem(item)
        appendCommentListItem(temp, item, moviearr, 0, replyTo, "detail", false)
    end for
    added = temp.getChildCount()
    if added = 0
        return
    end if
    oldFocus = m.comment_detail_list.itemFocused
    while temp.getChildCount() > 0
        content.insertChild(temp.getChild(temp.getChildCount() - 1), 0)
    end while
    m.comment_detail_list.jumpToItem = oldFocus + added
end sub

sub onCommentDetailChildren()
    result = m.commentChildTask.content
    if m.commentDetailState <> invalid
        m.commentDetailState.loadingChild = false
    end if
    if result = invalid or result.type <> invalid
        return
    end if
    if result.code = invalid or result.code <> 1 or result.data = invalid
        if m.commentDetailState <> invalid
            m.commentDetailState.childHasMore = false
        end if
        return
    end if
    if result.data.has_more <> invalid
        m.commentDetailState.childHasMore = result.data.has_more
    else
        m.commentDetailState.childHasMore = false
    end if
    list = result.data.list
    if list = invalid or list.Count() = 0
        m.commentDetailState.childHasMore = false
        return
    end if
    m.commentDetailState.childPage = m.commentDetailState.childPage + 1

    content = m.comment_detail_list.content
    if content = invalid
        return
    end if
    moviearr = ParseJson(m.top.movieid)
    ownName = ""
    if m.commentDetailState <> invalid and m.commentDetailState.ownName <> invalid
        ownName = m.commentDetailState.ownName
    end if
    appendCommentChildren(content, list, moviearr, ownName)
end sub

sub appendCommentListItem(ContentNode as Object, item as Object, moviearr as Object, level as Integer, replyTo as String, viewMode as String, isOwn as Boolean)
    child = ContentNode.createChild("ContentNode")
    name = "User"
    if item.username <> invalid
        name = item.username
    end if
    child.title = name
    child.description = commentTextFromItem(item)
    if item.avatar <> invalid
        child.hdposterurl = item.avatar
    else
        child.hdposterurl = "pkg:/images/avatar_default.png"
    end if
    child.shortdescriptionline1 = commentTimeTextFull(item.dateline)
    support = 0
    reply = 0
    if item.support <> invalid
        support = item.support
    end if
    if item.reply <> invalid
        reply = item.reply
    end if
    child.shortdescriptionline2 = support.ToStr() + "|" + reply.ToStr()

    child.addField("level", "integer", false)
    child.level = level
    child.addField("replyTo", "string", false)
    child.replyTo = replyTo
    child.addField("viewMode", "string", false)
    child.viewMode = viewMode
    child.addField("isOwn", "boolean", false)
    child.isOwn = isOwn

    data = CreateObject("roAssociativeArray")
    if item.mid <> invalid
        data["mid"] = item.mid
    else
        data["mid"] = moviearr.mid
    end if
    if item.box_type <> invalid
        data["box_type"] = item.box_type
    else
        data["box_type"] = moviearr.box_type
    end if
    if item.comment_id <> invalid
        data["comment_id"] = item.comment_id
    end if
    if item.uid <> invalid
        data["uid"] = item.uid
    end if
    child.addField("data", "assocarray", false)
    child.data = data
end sub

function commentReplyToFromItem(item as Object) as String
    if item = invalid
        return ""
    end if
    if item.reply_username <> invalid and item.reply_username <> ""
        return item.reply_username
    end if
    if item.to_username <> invalid and item.to_username <> ""
        return item.to_username
    end if
    if item.parent_username <> invalid and item.parent_username <> ""
        return item.parent_username
    end if
    if item.reply_user <> invalid and item.reply_user.username <> invalid and item.reply_user.username <> ""
        return item.reply_user.username
    end if
    if item.to_user <> invalid and item.to_user.username <> invalid and item.to_user.username <> ""
        return item.to_user.username
    end if
    if item.comment <> invalid
        for each part in item.comment
            if part.uid <> invalid and part.username <> invalid and part.username <> ""
                return part.username
            end if
        end for
    end if
    return ""
end function

function commentTextFromItem(item as Object) as String
    if item.is_delete <> invalid and item.is_delete
        return "This comment has been deleted"
    end if
    replyTo = commentReplyToFromItem(item)
    text = ""
    skippedReplyMention = false
    if item.comment <> invalid
        for each part in item.comment
            if part.text <> invalid
                text = text + part.text
            end if
            if part.uid <> invalid and part.username <> invalid
                if skippedReplyMention = false and replyTo <> "" and part.username = replyTo
                    skippedReplyMention = true
                else
                    text = text + " @" + part.username
                end if
            end if
        end for
    end if
    if text = ""
        return ""
    end if
    text = text.Replace(Chr(13) + Chr(10), " ")
    text = text.Replace(Chr(13), " ")
    text = text.Replace(Chr(10), " ")
    return text.Trim()
end function

function commentTimeText(dateline as Dynamic) as String
    return commentTimeTextFull(dateline)
end function

function commentTimeTextFull(dateline as Dynamic) as String
    if dateline = invalid
        return ""
    end if
    ts = dateline
    if Type(ts) = "roString" or Type(ts) = "String"
        ts = ts.ToInt()
    end if
    date = CreateObject("roDateTime")
    date.FromSeconds(ts)
    date.ToLocalTime()
    return date.GetYear().ToStr() + "-" + PadZero(date.GetMonth()) + "-" + PadZero(date.GetDayOfMonth()) + " " + PadZero(date.GetHours()) + ":" + PadZero(date.GetMinutes())
end function

sub playvideo()
    showPlayLoading(m, false)
    m.playtrailer = 0
    if m.detail <> invalid and m.detail.box_type = 2
        arr = ParseJson(m.top.movieid)
        if arr <> invalid
            if m.detail.season <> invalid
                arr["season_list"] = m.detail.season
            end if
            if m.detail.max_season <> invalid
                arr["max_season"] = m.detail.max_season
            end if
            m.top.movieid = FormatJson(arr)
        end if
    end if
    startVideoContentReader(m, m.top.movieid)
end sub

sub setplaydata()
    if isStaleVideoPlayRequest(m)
        return
    end if
    finishVideoContentRequest(m)
    if m.loading = invalid and m.video_play = invalid
        return
    end if
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
    m.videoinfo = m.readVideoContentTask.videoinfo
    if m.videoinfo = invalid
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.operates.setFocus(true)
        m.error_msg.text = "Playback failed, please try again"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if m.videoinfo.code <> invalid and m.videoinfo.code <= 0
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.operates.setFocus(true)
        m.error_msg.text = m.videoinfo.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    m.videoinfo["content"] = m.readVideoContentTask.videocontent
    if m.video_play <> invalid
        m.video.control = "stop"
        m.videoinfo["moviedata"] = ParseJson(m.top.movieid)
        applyResumeSeconds(m.videoinfo)
        m.video_play.content = m.videoinfo
        m.video_play.visible = true
        if m.video <> invalid
            m.video.visible = true
        end if
    else
        m.videoinfo["moviedata"] = ParseJson(m.top.movieid)
        applyResumeSeconds(m.videoinfo)
        video_play = createObject("roSGNode", "videoPlay")
        video_play.content = m.videoinfo
        video_play.id = "video_play"
        m.top.appendChild(video_play)
        m.video_play = m.top.findNode("video_play")
        m.video_play.observeField("next_episode", "autonext")
        m.video_play.observeField("play_episode", "onPlayEpisodeSelected")
        m.video = m.video_play.findNode("my_video")
        m.video.observeField("state", "controlvideoplay")
        m.video_play.setFocus(true)
    end if

    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 300
    m.timer.repeat = true
    m.timer.control = "start"
    m.timer.ObserveField("fire","progressSave")
end sub

sub playvideo2()
    if m.list2.rowItemSelected[0] = 0
        if m.e_list2 <> Invalid
            m.top.e_list = {"list":m.e_list2}
        end if

        showPlayLoading(m, false)
        aa = m.list2.content.getChild(0).getChild(m.list2.rowItemSelected[1])
        ba = CreateObject("roByteArray")
        ba.FromBase64String(aa.drmParams.appData)
        m.moviedata = ba.ToAsciiString()
        startVideoContentReader(m, m.moviedata)
        m.top.movieid = m.moviedata
    else
        aa = m.list2.content.getChild(1).getChild(m.list2.rowItemSelected[1])
        data = {"id":aa.data.lid}
        m.list_detail = createObject("roSGNode", "PlayList2")
        m.list_detail.arr = data
        m.top.appendChild(m.list_detail)
    end if
end sub

sub addshow()
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "FAVORITES"
    if m.detail.is_collect = 1
        child.HDPosterUrl = "pkg:/images/faved.png"
    else
        child.HDPosterUrl = "pkg:/images/fav.png"
    end if
    ' child = contentRoot.createChild("ContentNode")
    ' child.title = "add"
    ' child.HDPosterUrl = "pkg:/images/watched.png"
    m.adds.content = contentRoot
    m.adds.observeField("itemSelected","addoperate")
    
    m.readerTask2 = createObject("RoSGNode","GetContentReader")
    m.readerTask2.content = {"type":"mylist"}
    m.readerTask2.observeField("content", "mylist")
    m.readerTask2.control = "RUN"

    m.addlist.visible = true
    m.adds.setFocus(true)
end sub

sub progressSave()
    runtime = m.video.duration
    seconds = m.video.position
    video = m.videoinfo.list[0]
    
    arr = ParseJson(m.top.movieid)
    
    if arr.box_type = 2
        arr["mp4_id"] = video.tmfid
    else
        arr["mp4_id"] = video.mmfid
    end if
    arr["seconds"] = Int(seconds)
    if runtime - seconds < 300
        arr["over"] = 1
    else
        arr["over"] = 0
    end if
    persistPlayProgress(m, arr.seconds, arr.over)
    arr["type"] = "progress_save"
    
    if arr.box_type = 2
        minutes = Int(seconds / 60)
        remainingSeconds = Int(seconds) - (minutes * 60)
        if remainingSeconds < 10
            remainingSeconds = "0" + remainingSeconds.ToStr()
        end if
        playtext = "CONTINUE S"+arr.season.ToStr()+":E"+arr.episode.ToStr()+" "+minutes.ToStr()+":"+remainingSeconds.ToStr()
    else
        minutes = Int(seconds / 60)
        remainingSeconds = Int(seconds) - (minutes * 60)
        if remainingSeconds < 10
            remainingSeconds = "0" + remainingSeconds.ToStr()
        end if
        playtext = "CONTINUE "+minutes.ToStr()+":"+remainingSeconds.ToStr()
    end if
    play_btn = m.operates.content.getChild(0)
    play_btn.Update({"Description":playtext}, false)

    if arr.box_type = 2
        time = ConvertSecondsToHMS(Int(seconds))
        for i = 0 to m.list2.content.getChild(0).getChildCount() - 1
            episode2 = m.list2.content.getChild(0).getChild(i)
            if episode2.data.episode = arr.episode and arr.season = episode2.data.season
                episode2.update({"data":{"episode":arr.episode,"time":time,"over":arr.over}}, false)
                episode2.update({"shortdescriptionline1":episode2.shortdescriptionline1}, false)
            end if
        end for
    end if

    m.saveContentTask = createObject("RoSGNode","GetContentReader")
    m.saveContentTask.content = arr
    ' m.saveContentTask.observeField("content", "refresh_home")
    m.saveContentTask.control = "RUN"
end sub

sub controlvideoplay()
    if m.video.state = "error"
        m.error = 1
    end if
    if m.video.state = "playing"
        m.error = 0
    end if
    if m.video.state = "finished" and m.error = 0 and isNaturalPlaybackFinish(m.video)
        m.timer.control = "stop"
        progressSave()
        arr = ParseJson(m.top.movieid)
        if arr.box_type = 2
            e_list = m.top.e_list
            next2 = 0
            for each item in e_list.list
                if item.episode > arr.episode
                    arr.imdb_id = item.imdb_id
                    arr.episode = item.episode
                    if item.play_progress.over = 1
                        arr.seconds = 0
                    else
                        arr.seconds = item.play_progress.seconds
                    end if
                    next2 = 1
                    exit for
                end if
            end for
            if next2 = 1
                m.top.movieid = FormatJson(arr)
                startVideoContentReader(m, m.top.movieid)
            else
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.operates.setFocus(true)
            end if
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.operates.setFocus(true)
        end if
    end if
end sub

sub controlvideoplay2()
    if m.video2.state = "finished"
        m.video2.control = "stop"
        m.video2.visible = false
        m.list.setFocus(true)
    end if
end sub

sub autonext()
    m.timer.control = "stop"
    progressSave()
    arr = ParseJson(m.top.movieid)
    if arr.box_type = 2
        e_list = m.top.e_list
        next2 = 0
        for each item in e_list.list
            if item.episode > arr.episode
                arr.imdb_id = item.imdb_id
                arr.episode = item.episode
                if item.play_progress.over = 1
                    arr.seconds = 0
                else
                    arr.seconds = item.play_progress.seconds
                end if
                next2 = 1
                exit for
            end if
        end for
        if next2 = 1
            m.top.movieid = FormatJson(arr)
            startVideoContentReader(m, m.top.movieid)
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.operates.setFocus(true)
        end if
    end if
end sub

sub mylist()
    content = m.readerTask2.content
    node = ConvertToContentNode3(content.data)
    m.movielist.content = node
end sub

sub addoperate()
    m.btn = m.adds.content.getChild(m.adds.itemSelected)
    if m.btn.title = "FAVORITES"
        arr = ParseJson(m.top.movieid)
        if m.detail.is_collect = 1
            arr["type2"] = "del"
        else
            arr["type2"] = "add"
        end if
        arr["type"] = "fav"
        m.readerTask3 = createObject("RoSGNode","GetContentReader")
        m.readerTask3.content = arr
        m.readerTask3.observeField("content", "getfav")
        m.readerTask3.control = "RUN"
        
    end if
end sub

sub addmovielist()
    aa = m.movielist.content.getChild(m.movielist.itemSelected)
    arr = {"type":"add_playlist","lid":aa.data.lid,"mid":m.detail.id,"box_type":m.detail.box_type}
    m.addmovielistTask = createObject("RoSGNode","GetContentReader")
    m.addmovielistTask.content = arr
    m.addmovielistTask.observeField("content", "add_result")
    m.addmovielistTask.control = "RUN"
end sub

function add_result()
    con = m.addmovielistTask.content
    if con.type <> invalid
        return false
    end if
    if con = invalid or con.code = invalid
        m.error_msg.text = "Add failed"
        m.error_tip.visible = true
        return false
    end if
    m.error_msg.text = con.msg
    m.error_tip.visible = true
    m.msgtimer = CreateObject("roSGNode", "Timer")
    m.msgtimer.duration = 3
    m.msgtimer.control = "start"
    m.msgtimer.ObserveField("fire","hidemsg")
end function

sub hidemsg()
    m.error_tip.visible = false
end sub

sub getfav()
    result = m.readerTask3.content
    if result.code = 1
        if m.detail.is_collect = 1
            m.detail.is_collect = 0
            m.btn.Update({"hdposterurl":"pkg:/images/fav.png"}, false)
        else
            m.detail.is_collect = 1
            m.btn.Update({"hdposterurl":"pkg:/images/faved.png"}, false)
        end if
    end if
end sub

sub getseason()
    m.season = m.seasonlist.content.getChild(m.seasonlist.itemSelected)
    arr = ParseJson(m.top.movieid)
    arr["type"] = "season"
    arr["season"] = m.season.id
    m.seasonTask = createObject("RoSGNode","GetContentReader")
    m.seasonTask.content = arr
    m.seasonTask.observeField("content", "seasonlist")
    m.seasonTask.control = "RUN"
end sub

sub seasonlist()
    slist = m.seasonTask.content
    if slist.type <> invalid
        return
    end if
    if slist = invalid and slist.code <= 0
        if slist <> invalid
            m.error_msg.text = slist.msg
            m.error_tip.visible = true
            m.msgtimer = CreateObject("roSGNode", "Timer")
            m.msgtimer.duration = 3
            m.msgtimer.control = "start"
            m.msgtimer.ObserveField("fire","hidemsg")
        end if
        return
    end if
    ContentNode = episode_ConvertToContentNode(slist.data)
    ' m.list2.content = ContentNode
    m.list2.content.replaceChild(ContentNode,0)

    m.e_list2 = slist.data

    arr2 = m.detail
    season_btn = m.operates.content.getChild(1)
    season_name = m.list2.content.getChild(0)
    if m.season.id.ToInt() > 1500
        season_btn.Update({"Description":"Season "+(m.seasonlist.itemSelected+1).ToStr()+"/"+arr2.max_season.ToStr()}, false)
        ' m.name.text = "Year "+m.season.id + " ( " +  slist.data.Count().ToStr() + " episode )"
        season_name.Update({"title":"Year "+m.season.id + " ( " +  slist.data.Count().ToStr() + " episode )"}, false)
    else
        season_btn.Update({"Description":"Season "+m.season.id+"/"+arr2.max_season.ToStr()}, false)
        ' m.name.text = "Season "+m.season.id+"/"+arr2.max_season.ToStr() + " ( " +  slist.data.Count().ToStr() + " episode )"
        season_name.Update({"title":"Season "+m.season.id+"/"+arr2.max_season.ToStr() + " ( " +  slist.data.Count().ToStr() + " episode )"}, false)
    end if

    m.seasons.visible = false
    m.operates.setFocus(true)
end sub 

function ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "Related"
    for each subItem in Content
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = subItem.title
        subItemContent.hdposterurl = subItem.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = subItem.mid
        data["box_type"] = 1
        json = FormatJson(data)
        ba = CreateObject("roByteArray")
        ba.FromAsciiString(json)
        aa = ba.ToBase64String()
        subItemContent.drmParams = {appData:aa}
    end for
    return ContentNode
end function

function trailer_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "Trailers"
    for each key in Content.trailer_url_arr
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = ""
        subItemContent.hdposterurl = key.img
        charPosition = Instr(1, key.url, "watch?v=")
        vid = mid(key.url, charPosition + len("watch?v="))
        data = CreateObject("roAssociativeArray")
        data["vid"] = vid
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "Related"
    for each subItem in Content.recommend
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = subItem.title
        subItemContent.hdposterurl = subItem.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = subItem.mid
        data["box_type"] = 1
        json = FormatJson(data)
        ba = CreateObject("roByteArray")
        ba.FromAsciiString(json)
        aa = ba.ToBase64String()
        subItemContent.drmParams = {appData:aa}
    end for
    return ContentNode
end function

function related_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    if Content.trailer_url_arr.Count() > 0
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = "Trailers"
        for each key in Content.trailer_url_arr
            subItemContent = itemContent.createChild("ContentNode")
            subItemContent.title = ""
            subItemContent.hdposterurl = key.img
            charPosition = Instr(1, key.url, "watch?v=")
            vid = mid(key.url, charPosition + len("watch?v="))
            data = CreateObject("roAssociativeArray")
            data["vid"] = vid
            subItemContent.addField("data", "assocarray", false)
            subItemContent.data = data
        end for
    end if
    if Content.recommend.Count() > 0
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = "Related"
        for each subItem in Content.recommend
            subItemContent = itemContent.createChild("ContentNode")
            subItemContent.title = subItem.title
            subItemContent.hdposterurl = subItem.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = subItem.mid
            data["box_type"] = 1
            subItemContent.addField("data", "assocarray", false)
            subItemContent.data = data
        end for
    end if
    if Content.playlists.Count() > 0
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = "Related Movielists"
        for each subItem in Content.playlists
            subItemContent = itemContent.createChild("ContentNode")
            subItemContent.title = subItem.name
            subItemContent.hdposterurl = subItem.imgArr[0]
            subItemContent.Description = "playlist"
            data = CreateObject("roAssociativeArray")
            data["lid"] = subItem.lid
            data["count"] = subItem.count
            subItemContent.addField("data", "assocarray", false)
            subItemContent.data = data
        end for
    end if
    return ContentNode
end function

function ConvertToContentNode2(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "Season "+Content.episode[0]["season"].ToStr()+"/"+Content.season.Count().ToStr() + " ( " +  Content.episode.Count().ToStr() + " episode )"
    for each key in Content.episode
        if key.season > 10
            episode = "S"+key.season.ToStr()
        else
            episode = "S0"+key.season.ToStr()
        end if
        if key.episode > 10
            episode = episode+"E"+key.episode.ToStr()
        else
            episode = episode+"E0"+key.episode.ToStr()
        end if
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = key.title
        subItemContent.Description = episode
        if key.runtime <> Invalid
            subItemContent.shortdescriptionline1 = ConvertMinutesToTime(key.runtime)
        else
            subItemContent.shortdescriptionline1 = "00:00"
        end if
        subItemContent.hdposterurl = key.thumbs
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.tid
        data["box_type"] = 2
        data["season"] = key.season
        data["episode"] = key.episode
        data["imdb_id"] = key.imdb_id
        data["seconds"] = key.play_progress.seconds
        data2 = CreateObject("roAssociativeArray")
        data2["season"] = key.season
        data2["episode"] = key.episode
        if key.play_progress <> Invalid and key.play_progress.seconds > 0
            data2["time"] = ConvertSecondsToHMS(key.play_progress.seconds)
        end if
        if key.play_progress <> Invalid
            data2["over"] = key.play_progress.over
        end if
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data2
        json = FormatJson(data)
        ba = CreateObject("roByteArray")
        ba.FromAsciiString(json)
        aa = ba.ToBase64String()
        subItemContent.drmParams = {appData:aa}
    end for
    if Content.playlist <> Invalid and Content.playlist.Count() > 0
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = "Related Movielists"
        for each subItem in Content.playlist
            subItemContent = itemContent.createChild("ContentNode")
            subItemContent.title = subItem.name
            subItemContent.hdposterurl = subItem.imgArr[0]
            subItemContent.Description = "playlist"
            data = CreateObject("roAssociativeArray")
            data["lid"] = subItem.lid
            data["count"] = subItem.count
            subItemContent.addField("data", "assocarray", false)
            subItemContent.data = data
        end for
    end if
    return ContentNode
end function

function episode_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        if key.season > 10
            episode = "S"+key.season.ToStr()
        else
            episode = "S0"+key.season.ToStr()
        end if
        if key.episode > 10
            episode = episode+"E"+key.episode.ToStr()
        else
            episode = episode+"E0"+key.episode.ToStr()
        end if
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = key.title
        itemContent.Description = episode
        if key.runtime <> Invalid
            itemContent.shortdescriptionline1 = ConvertMinutesToTime(key.runtime)
        else
            itemContent.shortdescriptionline1 = "00:00"
        end if
        itemContent.hdposterurl = key.thumbs
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.tid
        data["box_type"] = 2
        data["season"] = key.season
        data["episode"] = key.episode
        data["seconds"] = key.play_progress.seconds
        data2 = CreateObject("roAssociativeArray")
        data2["season"] = key.season
        data2["episode"] = key.episode
        if key.play_progress <> Invalid and key.play_progress.seconds > 0
            data2["time"] = ConvertSecondsToHMS(key.play_progress.seconds)
        end if
        if key.play_progress <> Invalid
            data2["over"] = key.play_progress.over
        end if
        itemContent.addField("data", "assocarray", false)
        itemContent.data = data2
        json = FormatJson(data)
        ba = CreateObject("roByteArray")
        ba.FromAsciiString(json)
        aa = ba.ToBase64String()
        itemContent.drmParams = {appData:aa}
    end for
    return ContentNode
end function

function lang_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        if subItem.lang <> ""
            ItemContent = ContentNode.createChild("ContentNode")
            ItemContent.title = subItem.title
            ItemContent.Description = subItem.lang
        end if
    end for
    return ContentNode
end function

function ConvertToContentNode3(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = subItem.name
        ItemContent.hdposterurl = subItem.imgArr[0]
        ItemContent.Description = subItem.count.ToStr()
        data = CreateObject("roAssociativeArray")
        data["lid"] = subItem.lid
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

function watch_ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    m.over_episode_count = 0
    m.episode_count = 0
    m.season_over = 1
    m.season_episode_count = 0
    m.current_season = Content[0].season
    for each key in Content
        subItems = key.episode_list
        for each subItem in subItems
            m.episode_count++
            if subItem.over = 1
                m.over_episode_count++
            end if
            if key.season = m.current_season
                m.season_episode_count++
                ItemContent = ContentNode.createChild("ContentNode")
                if subItem.over < 1
                    m.season_over = 0
                end if
                if subItem.season > 9
                    name = "S"+subItem.season.ToStr()
                else
                    name = "S0"+subItem.season.ToStr()
                end if
                if subItem.episode > 9
                    name = name+"E"+subItem.episode.ToStr()
                else
                    name = name+"E0"+subItem.episode.ToStr()
                end if
                if subItem.title <> invalid
                    ItemContent.title = name+" - "+subItem.title
                else
                    ItemContent.title = name
                end if
                if subItem.thumbs <> invalid
                    ItemContent.hdposterurl = subItem.thumbs
                else
                    ItemContent.hdposterurl = "pkg:/images/tv_chapter.png"
                end if
                if subItem.runtime <> Invalid
                    itemContent.description = ConvertMinutesToTime(subItem.runtime)
                else
                    itemContent.description = "00:00"
                end if
                itemContent.ShortDescriptionLine1 = subItem.over.ToStr()
                data = CreateObject("roAssociativeArray")
                data["season"] = subItem.season
                data["episode"] = subItem.episode
                data["over"] = subItem.over
                data["runtime"] = subItem.runtime
                data["seconds"] = subItem.seconds
                if subItem.seconds > 0
                    progress = RoundToOneDecimalPlace(subItem.seconds/(subItem.runtime*60))
                    data["progress"] = progress
                end if
                ItemContent.addField("data", "assocarray", false)
                ItemContent.data = data
            end if
        end for
    end for
    return ContentNode
end function

function watch_ConvertToContentNode2(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    m.season_over = 1
    m.season_episode_count = 0
    m.current_season = Content.season
    for each subItem in Content.episode_list
        m.season_episode_count++
        ItemContent = ContentNode.createChild("ContentNode")
        if subItem.over < 1
            m.season_over = 0
        end if
        if subItem.season > 9
            name = "S"+subItem.season.ToStr()
        else
            name = "S0"+subItem.season.ToStr()
        end if
        if subItem.episode > 9
            name = name+"E"+subItem.episode.ToStr()
        else
            name = name+"E0"+subItem.episode.ToStr()
        end if
        ItemContent.title = name+" - "+subItem.title
        ItemContent.hdposterurl = subItem.thumbs
        if subItem.runtime <> Invalid
            itemContent.description = ConvertMinutesToTime(subItem.runtime)
        else
            itemContent.description = "00:00"
        end if
        itemContent.ShortDescriptionLine1 = subItem.over.ToStr()
        data = CreateObject("roAssociativeArray")
        data["season"] = subItem.season
        data["episode"] = subItem.episode
        data["over"] = subItem.over
        data["runtime"] = subItem.runtime
        data["seconds"] = subItem.seconds
        if subItem.seconds > 0
            progress = RoundToOneDecimalPlace(subItem.seconds/(subItem.runtime*60))
            data["progress"] = progress
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

sub ConvertMinutesToTime(minutes as Integer) as String
    ' 计算小时、分钟和秒数
    hours = Int(minutes / 60)
    remainingMinutes = minutes - (hours * 60)
    
    ' 格式化为时分秒格式
    if hours >= 1
        timeString = hours.ToStr() + ":" + PadZero(remainingMinutes) + ":00"
    else
        timeString = PadZero(remainingMinutes) + ":00"
    end if
    
    return timeString
end sub

function ConvertSecondsToHMS(seconds as Integer) as Object
    hours = Int(seconds \ 3600)
    minutes = Int((seconds - (hours * 3600)) / 60)
    seconds = seconds - (hours * 3600) - (minutes * 60)
    
    if hours >= 1
        timeString = hours.ToStr() + ":" + PadZero(minutes) + ":" + PadZero(seconds)
    elseif minutes >= 1
        timeString = PadZero(minutes) + ":" + PadZero(seconds)
    else
        timeString = "00:" + PadZero(seconds)
    end if
    
    return timeString
end function

' 辅助函数：将单个数字转换为两位字符，不足两位补零
function PadZero(number as Integer) as String
    if number < 10 then
        return "0"+number.ToStr()
    else
        return number.ToStr()
    end if
end function

function RoundToOneDecimalPlace(num)
    n_str = Str(num)
    decimalPointPosition = InStr(1, n_str, ".")

    ' 如果找到小数点
    if decimalPointPosition > 0
        ' 截取字符串，保留1位小数
        formattedString = Left(n_str, decimalPointPosition + 1) + Mid(n_str, decimalPointPosition + 2, 1)
    else
        ' 如果没有小数点，直接使用原始字符串
        formattedString = n_str
    end if

    return formattedString.ToFloat()
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "back"
            if m.loading <> invalid
                m.top.removeChild(m.loading)
                m.loading = invalid
                if m.playtrailer = 1
                    m.list.setFocus(true)
                else
                    m.operates.setFocus(true)
                end if
                return true
            end if
            if m.video2.visible = true
                m.video2.control = "stop"
                m.video2.visible = false
                m.list.setFocus(true)
                return true
            end if
            if m.video_play <> invalid and m.video_play.visible = true
                m.timer.control = "stop"
                progressSave()
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.operates.setFocus(true)
                return true
            end if
            if m.detail2 <> invalid and m.detail2.visible = true
                m.top.removeChild(m.detail2)
                m.detail2 = invalid
                if m.detail_from_actor = true and m.actorDetail <> invalid
                    m.detail_from_actor = false
                    m.actorDetail.visible = true
                    actorMovies = m.actorDetail.findNode("movies_list")
                    if actorMovies <> invalid and actorMovies.visible = true
                        actorMovies.setFocus(true)
                    else
                        actorTvs = m.actorDetail.findNode("tv_list")
                        if actorTvs <> invalid
                            actorTvs.setFocus(true)
                        end if
                    end if
                    return true
                end if
                if m.detail.box_type = 2
                    m.list2.setFocus(true)
                else
                    m.list.setFocus(true)
                end if
                return true
            end if
            if m.actorDetail <> invalid
                m.top.removeChild(m.actorDetail)
                m.actorDetail = invalid
                if m.actor_all_bg.visible = true
                    m.actor_all_list.setFocus(true)
                else if m.actor_list.visible = true
                    m.actor_list.setFocus(true)
                else
                    m.operates.setFocus(true)
                end if
                return true
            end if
            if m.list_detail <> invalid and m.list_detail.visible = true
                m.top.removeChild(m.list_detail)
                m.list_detail = invalid
                if m.detail.box_type = 2
                    m.list2.setFocus(true)
                else
                    m.list.setFocus(true)
                end if
                return true
            end if
            if m.seasons.visible = true
                m.seasons.visible = false
                m.operates.setFocus(true)
                result = true
            end if
            if m.watch_seasons.visible = true
                m.watch_seasons.visible = false
                m.season_watch.setFocus(true)
                return true
            end if
            if m.desc_bg2.visible = true
                m.desc_bg2.visible = false
                result = true
            end if
            if m.langlist_bg.visible = true
                m.langlist_bg.visible = false
                m.titlebg.setFocus(true)
                result = true
            end if
            if m.addlist.visible = true
                m.addlist.visible = false
                m.operates.setFocus(true)
                result = true
            end if
            if m.tag_watchbg.visible = true
                m.tag_watchbg.visible = false
                m.operates.setFocus(true)
                result = true
            end if
            if m.actor_all_bg.visible = true
                m.actor_all_bg.visible = false
                m.actor_list.setFocus(true)
                return true
            end if
            if m.comment_detail_bg.visible = true
                m.comment_detail_bg.visible = false
                m.comment_detail_empty.visible = false
                m.comment_list.setFocus(true)
                return true
            end if
            if m.comment_bg.visible = true
                m.comment_bg.visible = false
                m.comment_empty.visible = false
                m.operates.setFocus(true)
                return true
            end if
        else if key = "up" then
            if m.video_play <> invalid and m.video_play.visible = true
                return true
            end if
            if m.addlist.visible = true
                m.adds.setFocus(true)
                return true
            end if
            if m.watch_seasons.visible = true
                return true
            end if
            if m.langlist_bg.visible = true
                return true
            end if
            if m.actor_all_bg.visible = true
                return true
            end if
            if m.comment_detail_bg.visible = true
                return true
            end if
            if m.comment_bg.visible = true
                return true
            end if
            if m.tag_watchbg.visible = true
                if m.season_watch.hasFocus() = true
                    m.addwatch_btns.setFocus(true)
                    return true
                end if
                if m.watch_episodes.hasFocus() = true
                    if m.season_episode_count > 4 and m.season_episode_count <= 6
                        m.myInterp3.keyValue = [ [0.0, -140.0], [0.0, 0.0] ]
                        m.transAnimation2.control = "start"
                    elseif m.season_episode_count > 6 and m.season_episode_count <= 8
                        m.myInterp3.keyValue = [ [0.0, -280.0], [0.0, 0.0] ]
                        m.transAnimation2.control = "start"
                    elseif m.season_episode_count > 8
                        m.myInterp3.keyValue = [ [0.0, -420.0], [0.0, 0.0] ]
                        m.transAnimation2.control = "start"
                    end if
                    m.season_watch.setFocus(true)
                    return true
                end if
                return true
            end if
            if m.operates.hasFocus() = true
                m.description.setFocus(true)
                m.description.color = "#333333FF"
                m.desc_bg.color = "0xdfdfdfff"
                m.border.visible = true
            elseif m.description.hasFocus() = true and m.lang_bg.visible = true
                m.description.color = "0xA3A3C2FF"
                m.desc_bg.color = "0xffffff33"
                m.border.visible = false
                m.titlebg.setFocus(true)
                m.title.color = "#000000FF"
                m.titlebg.color = "0xdfdfdfff"
            else
                if m.actor_list.hasFocus() = true
                    m.operates.setFocus(true)
                    return true
                end if
                if m.description.hasFocus() = false and m.titlebg.hasFocus() = false
                    if m.list.hasFocus() = true or m.list2.hasFocus() = true
                        if m.has_actors = true
                            scrollDetailPageTo(0.0)
                            m.ordindex = invalid
                            m.actor_list.setFocus(true)
                            return true
                        end if
                    end if
                    if m.detail_page.translation[1] <> 0.0
                        scrollDetailPageTo(0.0)
                    end if
                    m.operates.setFocus(true)
                end if
            end if
            result = true
        else if key = "down" then
            if m.addlist.visible = true
                m.movielist.setFocus(true)
                return true
            end if
            if m.seasons.visible = true
                return true
            end if
            if m.watch_seasons.visible = true
                return true
            end if
            if m.langlist_bg.visible = true
                return true
            end if
            if m.actor_all_bg.visible = true
                return true
            end if
            if m.comment_detail_bg.visible = true
                return true
            end if
            if m.comment_bg.visible = true
                return true
            end if
            if m.tag_watchbg.visible = true
                if m.addwatch_btns.hasFocus() = true
                    m.season_watch.setFocus(true)
                    return true
                end if
                if m.season_watch.hasFocus() = true
                    if m.season_episode_count > 4 and m.season_episode_count <= 6
                        m.myInterp3.keyValue = [ [0.0, 0.0], [0.0, -140.0] ]
                        m.transAnimation2.control = "start"
                    elseif m.season_episode_count > 6 and m.season_episode_count <= 8
                        m.myInterp3.keyValue = [ [0.0, 0.0], [0.0, -280.0] ]
                        m.transAnimation2.control = "start"
                    elseif m.season_episode_count > 8
                        m.myInterp3.keyValue = [ [0.0, 0.0], [0.0, -420.0] ]
                        m.transAnimation2.control = "start"
                    end if
                    m.watch_episodes.setFocus(true)
                    return true
                end if
                return true
            end if
            if m.description.hasFocus() = true
                m.operates.setFocus(true)
                m.description.color = "0xA3A3C2FF"
                m.desc_bg.color = "0xffffff33"
                m.border.visible = false
                return true
            end if
            if m.titlebg.hasFocus() = true
                m.title.color = "0xdfdfdfff"
                m.titlebg.color = "0xffffff33"
                m.description.setFocus(true)
                m.description.color = "#333333FF"
                m.desc_bg.color = "0xdfdfdfff"
                m.border.visible = true
                return true
            end if
            if m.operates.hasFocus() = true
                if m.has_actors = true
                    m.actor_list.setFocus(true)
                    return true
                end if
            end if
            if m.actor_list.hasFocus() = true
                extra = getActorScrollExtra()
                if extra > 0
                    scrollDetailPageTo(-198.0 - extra)
                    m.ordindex = 0
                end if
                if m.list.visible = true and m.related = true and m.list.content <> invalid and m.detail2 = invalid
                    m.list.setFocus(true)
                    return true
                end if
                if m.list2.visible = true and m.list2.content <> invalid and m.detail2 = invalid
                    m.list2.setFocus(true)
                    return true
                end if
            end if
            if m.list.visible = true and m.related = true and m.list.content <> invalid and m.detail2 = invalid
                m.list.setFocus(true)
                result = true
            end if
            if m.list2.visible = true and m.list2.content <> invalid and m.detail2 = invalid
                m.list2.setFocus(true)
                result = true
            end if
        else if key = "OK" then
            if m.actor_list.hasFocus() = true
                itemIndex = m.actor_list.rowItemFocused[1]
                aa = m.actor_list.content.getChild(0).getChild(itemIndex)
                if aa <> invalid and aa.description = "see_all"
                    showAllActors()
                    return true
                else if aa <> invalid
                    actorId = getActorIdFromContent(aa)
                    if actorId <> ""
                        openActorDetail(actorId)
                        return true
                    end if
                end if
            end if
            if m.title_list.hasFocus() = true
                m.titlebg.setFocus(true)
                return true
            end if
            if m.description.hasFocus() = true
                desc_show()
            end if
            if m.titlebg.hasFocus() = true and m.lang_bg.visible = true
                titles_show()
            end if
        end if
    end if
    return result
end function