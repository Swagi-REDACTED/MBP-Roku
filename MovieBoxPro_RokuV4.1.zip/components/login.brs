'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.code = m.top.findNode("code")
    m.message = m.top.findNode("loginMessage")
    m.expire = m.top.findNode("expire_bg")
    m.refresh = m.top.findNode("Refresh")
    m.refresh.setFocus(true)
    m.refresh.observeField("itemSelected","refreshCode")

    arr = {"type":"code"}
    m.codeContentTask = createObject("RoSGNode","GetContentReader")
    m.codeContentTask.content = arr
    m.codeContentTask.observeField("content", "setCode")
    m.codeContentTask.control = "RUN"
end function

sub setCode()
    content = m.codeContentTask.content

    ' skip request payload only: {type:"code"}
    if content = invalid or content.type = "code"
        return
    end if
    if content.login_error <> invalid and content.login_error <> ""
        m.code.text = ""
        m.message.text = content.login_error
        m.expire.visible = true
        m.refresh.setFocus(true)
        return
    end if
    codeStr = captchaCodeToString(content.code)
    if codeStr = ""
        return
    end if
    m.expire.visible = false
    m.code.text = codeStr

    m.timer2 = CreateObject("roSGNode", "Timer")
    m.timer2.duration = 300
    m.timer2.repeat = false
    m.timer2.control = "start"
    m.timer2.ObserveField("fire","expire")

    ' m.timer = CreateObject("roSGNode", "Timer")
    ' m.timer.duration = 3
    ' m.timer.repeat = true
    ' m.timer.control = "start"
    ' m.timer.ObserveField("fire","changeLogin")
end sub

sub expire()
    m.code.text = ""
    m.message.text = "Code Expired"
    m.expire.visible = true
    m.refresh.setFocus(true)
end sub

sub refreshCode()
    arr = {"type":"code"}
    m.codeContentTask = createObject("RoSGNode","GetContentReader")
    m.codeContentTask.content = arr
    m.codeContentTask.observeField("content", "setCode2")
    m.codeContentTask.control = "RUN"
end sub

sub setCode2()
    content = m.codeContentTask.content

    if content = invalid or content.type = "code"
        return
    end if
    if content.login_error <> invalid and content.login_error <> ""
        m.code.text = ""
        m.message.text = content.login_error
        m.expire.visible = true
        m.refresh.setFocus(true)
        return
    end if
    codeStr = captchaCodeToString(content.code)
    if codeStr = ""
        return
    end if
    m.expire.visible = false
    m.code.text = codeStr

    if m.timer2 <> invalid
        m.timer2.control = "stop"
    end if
    m.timer2 = CreateObject("roSGNode", "Timer")
    m.timer2.duration = 300
    m.timer2.repeat = false
    m.timer2.control = "start"
    m.timer2.ObserveField("fire","expire")
end sub

sub changeLogin()
    if m.code.text = invalid or m.code.text = ""
        return
    end if
    arr = {"type":"logincode","code":m.code.text}
    m.loginContentTask = createObject("RoSGNode","GetContentReader")
    m.loginContentTask.content = arr
    m.loginContentTask.observeField("content", "loginInfo")
    m.loginContentTask.control = "RUN"
end sub

sub loginInfo()
    content = m.loginContentTask.content
    if isLoginApiResponse(content) = false
        return
    end if
    m.timer.control = "stop"
        user = CreateObject("roRegistrySection", "User")
        user.Write("uid",content.data.uid.Tostr())
        user.Write("uid_v2",content.data.uid_v2)
        user.Write("appid",content.data.appid)
        user.Write("avatar",content.data.avatar)
        user.Write("bind_gmail",content.data.avatar)
        user.Write("email",content.data.email)
        user.Write("family",content.data.family.Tostr())
        user.Write("isvip",content.data.isvip.Tostr())
        user.Write("nickname",content.data.nickname)
        user.Write("username",content.data.username)

        arr = {"type":"device"}
        m.deviceTask = createObject("RoSGNode","GetContentReader")
        m.deviceTask.content = arr
        m.deviceTask.control = "RUN"
end sub