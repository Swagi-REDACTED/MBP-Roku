sub Init()
    m.modalBg = m.top.findNode("modalBg")
    m.tabList = m.top.findNode("tabList")
    m.thumbList = m.top.findNode("thumbList")
    m.timeList = m.top.findNode("timeList")
    m.moreBtn = m.top.findNode("moreBtn")
    m.thumbArea = m.top.findNode("thumbArea")
    m.timeArea = m.top.findNode("timeArea")
    m.rulerLeft = m.top.findNode("rulerLeft")
    m.rulerRight = m.top.findNode("rulerRight")
    m.loadingText = m.top.findNode("loadingText")
    m.optionList = m.top.findNode("optionList")
    m.okBtn = m.top.findNode("okBtn")
    m.okBtnBorder = m.top.findNode("okBtnBorder")
    m.focusOnOk = false

    tabContent = createObject("roSGNode", "ContentNode")
    child = tabContent.createChild("ContentNode")
    child.title = "SKIP OPENING"
    child = tabContent.createChild("ContentNode")
    child.title = "SKIP ENDING"
    m.tabList.content = tabContent
    m.tabList.ObserveField("itemFocused", "onTabChanged")
    m.tabList.ObserveField("itemSelected", "onTabSelected")

    m.thumbList.ObserveField("itemFocused", "onThumbFocused")
    m.thumbList.ObserveField("itemSelected", "onThumbSelected")
    m.timeList.ObserveField("itemFocused", "onTimeFocused")
    m.timeList.ObserveField("itemSelected", "onTimeSelected")

    m.skipType = "start"
    m.selectedTime = 0
    m.selectedIndex = 0
    m.thumbData = []
    m.applyAll = false
    m.skipEnabled = true
    m.duration = 0
    m.thumbRange = 1
    m.fid = 0
    m.saving = false
    m.syncing = false
    m.appendMode = false
    m.cellWidth = 182
    m.visibleCount = 5
    m.centerSlot = 2
    m.viewportWidth = 918
    m.itemWidth = 168
    m.itemGap = 14
    m.pageStartIndex = 0
    m.rulerNormalColor = "0x333333FF"
    m.rulerFocusColor = "0x0066CCFF"
    m.okBtnNormalColor = "0x0066CCFF"
    m.okBtnFocusColor = "0x00AAFFFF"
    updateRulerStyle()
    updateOkBtnStyle()
end sub

sub setOkFocus(active as Boolean)
    m.focusOnOk = active
    updateOkBtnStyle()
end sub

sub OnContentChange()
    data = m.top.content
    if data = invalid
        return
    end if

    m.moviedata = data.moviedata
    m.skips = data.skips
    if data.fid <> invalid
        m.fid = data.fid
    else if m.moviedata.fid <> invalid
        m.fid = m.moviedata.fid
    end if
    if m.skips = invalid
        m.skips = {"start": 0, "end": 0}
    end if
    if data.duration <> invalid
        m.duration = data.duration
    else
        m.duration = 0
    end if

    setupOptions()
    if m.skipType = "start"
        m.selectedTime = m.skips.start
        m.tabList.jumpToItem = 0
    else
        m.selectedTime = m.skips.end
        m.tabList.jumpToItem = 1
    end if

    loadThumbs(false)
    m.tabList.SetFocus(true)
end sub

sub setupOptions()
    season = m.moviedata.season
    if season = invalid
        season = 1
    end if
    applyTitle = "Apply to All Episodes of Season " + season.ToStr()
    if m.applyAll = true
        applyTitle = "[x] " + applyTitle
    else
        applyTitle = "[ ] " + applyTitle
    end if
    enabledTitle = "Skip Enabled"
    if m.skipEnabled = true
        enabledTitle = "[x] Skip Enabled"
    else
        enabledTitle = "[ ] Skip Enabled"
    end if

    optContent = createObject("roSGNode", "ContentNode")
    child = optContent.createChild("ContentNode")
    child.title = applyTitle
    child = optContent.createChild("ContentNode")
    child.title = enabledTitle
    m.optionList.content = optContent
end sub

sub onTabChanged()
    index = m.tabList.itemFocused
    if index = 0
        newType = "start"
    else
        newType = "end"
    end if
    if newType <> m.skipType
        m.skipType = newType
        m.thumbRange = 1
        loadThumbs(false)
    end if
end sub

sub onTabSelected()
    onTabChanged()
end sub

sub loadThumbs(isMore as Boolean)
    if isMore = true
        m.thumbRange = 2
        m.appendMode = true
    else
        m.thumbRange = 1
        m.appendMode = false
    end if

    m.loadingText.visible = true
    m.thumbArea.visible = false
    m.timeArea.visible = false

    req = CreateObject("roAssociativeArray")
    req["type"] = "tv_video_thumbs"
    req["mid"] = m.moviedata.mid
    req["season"] = m.moviedata.season
    req["episode"] = m.moviedata.episode
    req["fid"] = m.fid
    req["box_type"] = 2
    req["thumb_type"] = m.skipType
    req["range"] = m.thumbRange
    req["skips"] = m.skips

    if m.thumbsTask <> invalid and m.thumbsTask.state = "run"
        m.thumbsTask.control = "stop"
    end if
    m.thumbsTask = createObject("RoSGNode", "GetContentReader")
    m.thumbsTask.content = req
    m.thumbsTask.observeField("content", "onThumbsLoaded")
    m.thumbsTask.control = "RUN"
end sub

sub onThumbsLoaded()
    result = m.thumbsTask.content
    if result.type <> invalid
        return
    end if
    m.loadingText.visible = false

    if result = invalid or result.code <> 1
        msg = "Failed to load thumbnails"
        if result <> invalid and result.msg <> invalid
            msg = result.msg
        end if
        m.loadingText.text = msg
        m.loadingText.visible = true
        return
    end if

    list = result.data.thumbs
    if list = invalid
        list = []
    end if

    selectIdx = 0
    if result.data.select_index <> invalid
        selectIdx = result.data.select_index
    end if
    if result.data.select_skip <> invalid and result.data.select_skip > 0
        m.selectedTime = result.data.select_skip
    end if

    if m.appendMode = true and m.thumbData.Count() > 0
        appendThumbs(list)
        if m.skipType = "start" and m.skips.start > 180
            selectIdx = selectIdx - 90
            if selectIdx < 0
                selectIdx = 0
            end if
        end if
    else
        m.thumbData = list
    end if

    m.selectedIndex = selectIdx
    m.pageStartIndex = 0
    updatePageStartForIndex(m.selectedIndex, getThumbCount())
    refreshPage(true)

    m.thumbArea.visible = true
    m.timeArea.visible = true

    if m.skipType = "start" and m.thumbRange = 1 and m.skips.start > 180
        loadThumbs(true)
    end if
end sub

function getThumbCount() as Integer
    if m.thumbData = invalid
        return 0
    end if
    return m.thumbData.Count()
end function

function makeThumbNode(item as Object) as Object
    node = createObject("roSGNode", "ContentNode")
    thumbUrl = item.url
    if thumbUrl = invalid
        thumbUrl = item.thumb
    end if
    if thumbUrl = invalid
        thumbUrl = item.image
    end if
    node.hdposterurl = thumbUrl

    timeVal = item.seconds
    if timeVal = invalid
        timeVal = 0
    end if

    displayTime = timeVal
    if m.skipType = "end" and m.duration > 0
        displayTime = m.duration - timeVal
        if displayTime < 0
            displayTime = 0
        end if
    end if

    node.title = formatTime(displayTime)
    node.id = timeVal.ToStr()
    node.addField("data", "assocarray", false)
    node.data = item
    node.addField("isSelected", "string", true)
    node.isSelected = "false"
    return node
end function

function makeTimeNode(item as Object) as Object
    node = createObject("roSGNode", "ContentNode")
    timeVal = item.seconds
    if timeVal = invalid
        timeVal = 0
    end if
    node.title = timeVal.ToStr()
    node.id = timeVal.ToStr()
    node.addField("data", "assocarray", false)
    node.data = item
    node.SecondaryTitle = "false"
    return node
end function

sub appendThumbs(list as Object)
    for each item in list
        m.thumbData.Push(item)
    end for
end sub

sub updatePageStartForIndex(index as Integer, count as Integer)
    if count <= m.visibleCount
        m.pageStartIndex = 0
        return
    end if

    m.pageStartIndex = index - m.centerSlot
    maxStart = count - m.visibleCount
    if maxStart < 0
        maxStart = 0
    end if
    if m.pageStartIndex < 0
        m.pageStartIndex = 0
    end if
    if m.pageStartIndex > maxStart
        m.pageStartIndex = maxStart
    end if
end sub

sub applyListOffset()
    count = getThumbCount()
    if m.thumbList.content = invalid
        return
    end if

    pageSize = m.thumbList.content.getChildCount()
    if pageSize <= 0
        m.thumbList.translation = [0, 0]
        m.timeList.translation = [0, 0]
        return
    end if

    if count <= m.visibleCount
        totalWidth = pageSize * m.itemWidth + (pageSize - 1) * m.itemGap
        offsetX = Int((m.viewportWidth - totalWidth) / 2)
    else
        offsetX = 0
    end if

    m.thumbList.translation = [offsetX, 0]
    m.timeList.translation = [offsetX, 0]
end sub

sub refreshPage(setFocus as Boolean)
    count = getThumbCount()
    if count = 0
        m.thumbList.content = invalid
        m.timeList.content = invalid
        return
    end if

    updatePageStartForIndex(m.selectedIndex, count)

    pageEnd = m.pageStartIndex + m.visibleCount - 1
    if pageEnd >= count
        pageEnd = count - 1
    end if
    pageSize = pageEnd - m.pageStartIndex + 1

    thumbContent = createObject("roSGNode", "ContentNode")
    timeContent = createObject("roSGNode", "ContentNode")

    for i = m.pageStartIndex to pageEnd
        item = m.thumbData[i]
        thumbNode = makeThumbNode(item)
        timeNode = makeTimeNode(item)
        if i = m.selectedIndex
            thumbNode.isSelected = "true"
            timeNode.SecondaryTitle = "true"
            m.selectedTime = thumbNode.id.ToInt()
        end if
        thumbContent.appendChild(thumbNode)
        timeContent.appendChild(timeNode)
    end for

    m.syncing = true
    m.thumbList.numColumns = pageSize
    m.timeList.numColumns = pageSize
    m.thumbList.content = thumbContent
    m.timeList.content = timeContent

    localIdx = m.selectedIndex - m.pageStartIndex
    if localIdx < 0
        localIdx = 0
    end if
    if localIdx >= pageSize
        localIdx = pageSize - 1
    end if
    m.thumbList.jumpToItem = localIdx
    m.timeList.jumpToItem = localIdx
    if setFocus = true
        m.thumbList.SetFocus(true)
    end if
    applyListOffset()
    m.syncing = false
end sub

sub updateVisibleSelection()
    if m.thumbList.content = invalid or m.timeList.content = invalid
        return
    end if

    pageSize = m.thumbList.content.getChildCount()
    for localIdx = 0 to pageSize - 1
        globalIdx = m.pageStartIndex + localIdx
        thumbNode = m.thumbList.content.getChild(localIdx)
        timeNode = m.timeList.content.getChild(localIdx)
        if globalIdx = m.selectedIndex
            thumbNode.update({"isSelected": "true"}, true)
            timeNode.update({"SecondaryTitle": "true"}, true)
            m.selectedTime = thumbNode.id.ToInt()
        else
            thumbNode.update({"isSelected": "false"}, true)
            timeNode.update({"SecondaryTitle": "false"}, true)
        end if
    end for
end sub

sub syncSelection(index as Integer, setFocus as Boolean)
    if m.syncing = true
        return
    end if

    count = getThumbCount()
    if count = 0
        return
    end if

    if index < 0
        index = 0
    end if
    if index >= count
        index = count - 1
    end if

    oldPageStart = m.pageStartIndex
    m.selectedIndex = index
    updatePageStartForIndex(index, count)

    if m.pageStartIndex <> oldPageStart
        refreshPage(setFocus)
    else
        updateVisibleSelection()
        localIdx = index - m.pageStartIndex
        m.syncing = true
        m.thumbList.jumpToItem = localIdx
        m.timeList.jumpToItem = localIdx
        if setFocus = true
            m.thumbList.SetFocus(true)
        end if
        applyListOffset()
        m.syncing = false
    end if
end sub

sub turnPage(pageDelta as Integer)
    count = getThumbCount()
    if count = 0 or count <= m.visibleCount
        return
    end if

    newIdx = m.selectedIndex + pageDelta * m.visibleCount
    if newIdx < 0
        newIdx = 0
    end if
    if newIdx >= count
        newIdx = count - 1
    end if
    if newIdx = m.selectedIndex
        return
    end if

    keepRight = m.rulerRight.hasFocus()
    syncSelection(newIdx, false)
    if keepRight = true
        m.rulerRight.SetFocus(true)
    else
        m.rulerLeft.SetFocus(true)
    end if
    updateRulerStyle()
end sub

sub updateOkBtnStyle()
    if m.okBtn = invalid
        return
    end if
    if m.focusOnOk = true
        m.okBtn.color = m.okBtnFocusColor
        m.okBtnBorder.visible = true
    else
        m.okBtn.color = m.okBtnNormalColor
        m.okBtnBorder.visible = false
    end if
end sub

sub updateRulerStyle()
    if m.rulerLeft.hasFocus() = true
        m.rulerLeft.color = m.rulerFocusColor
    else
        m.rulerLeft.color = m.rulerNormalColor
    end if
    if m.rulerRight.hasFocus() = true
        m.rulerRight.color = m.rulerFocusColor
    else
        m.rulerRight.color = m.rulerNormalColor
    end if
end sub

function pageEndIndex(count as Integer) as Integer
    endIdx = m.pageStartIndex + m.visibleCount - 1
    if endIdx >= count
        endIdx = count - 1
    end if
    return endIdx
end function

function localPageLastIndex() as Integer
    if m.thumbList.content = invalid
        return 0
    end if
    lastIdx = m.thumbList.content.getChildCount() - 1
    if lastIdx < 0
        lastIdx = 0
    end if
    return lastIdx
end function

sub onThumbFocused()
    if m.syncing = true
        return
    end if
    globalIdx = m.pageStartIndex + m.thumbList.itemFocused
    if globalIdx <> m.selectedIndex
        syncSelection(globalIdx, false)
    end if
end sub

sub onThumbSelected()
    onThumbFocused()
end sub

sub onTimeFocused()
    if m.syncing = true
        return
    end if
    globalIdx = m.pageStartIndex + m.timeList.itemFocused
    if globalIdx <> m.selectedIndex
        syncSelection(globalIdx, false)
    end if
end sub

sub onTimeSelected()
    onTimeFocused()
end sub

function formatTime(seconds as Integer) as String
    if seconds < 0
        seconds = 0
    end if
    mins = Int(seconds / 60)
    secs = seconds mod 60
    return mins.ToStr().Trim() + ":" + rightZero(secs)
end function

function rightZero(val as Integer) as String
    if val < 10
        return "0" + val.ToStr()
    end if
    return val.ToStr()
end function

sub toggleOption()
    index = m.optionList.itemSelected
    if index = 0
        if m.applyAll = true
            m.applyAll = false
        else
            m.applyAll = true
        end if
    else if index = 1
        if m.skipEnabled = true
            m.skipEnabled = false
        else
            m.skipEnabled = true
        end if
    end if
    setupOptions()
    m.optionList.jumpToItem = index
end sub

sub saveSkipSetting()
    if m.saving = true
        return
    end if
    m.saving = true
    m.loadingText.text = "Saving..."
    m.loadingText.visible = true

    req = CreateObject("roAssociativeArray")
    req["type"] = "tv_episode_skip_vote"
    req["mid"] = m.moviedata.mid
    req["season"] = m.moviedata.season
    req["episode"] = m.moviedata.episode
    if m.applyAll = true
        req["episode"] = 0
    end if

    if m.skipEnabled = true and m.thumbData.Count() > m.selectedIndex
        item = m.thumbData[m.selectedIndex]
        if item <> invalid and item.seconds <> invalid
            m.selectedTime = item.seconds
        end if
    end if

    startVal = -1
    endVal = -1

    if m.skipType = "start"
        if m.skipEnabled = true
            startVal = m.selectedTime
        else
            startVal = 0
        end if
        endVal = -1
    else
        if m.skipEnabled = true
            endVal = m.selectedTime
        else
            endVal = 0
        end if
        startVal = -1
    end if

    req["start"] = startVal
    req["end"] = endVal

    m.voteTask = createObject("RoSGNode", "GetContentReader")
    m.voteTask.content = req
    m.voteTask.observeField("content", "onVoteSaved")
    m.voteTask.control = "RUN"
end sub

sub onVoteSaved()
    m.saving = false
    m.loadingText.visible = false
    result = m.voteTask.content
    if result = invalid or result.code <= 0
        msg = "Save failed"
        if result <> invalid and result.msg <> invalid
            msg = result.msg
        end if
        m.loadingText.text = msg
        m.loadingText.visible = true
        return
    end if

    if m.skipType = "start"
        if m.skipEnabled = true
            finalStart = m.selectedTime
        else
            finalStart = 0
        end if
        if m.skips.end <> invalid
            finalEnd = m.skips.end
        else
            finalEnd = 0
        end if
    else
        if m.skipEnabled = true
            finalEnd = m.selectedTime
        else
            finalEnd = 0
        end if
        if m.skips.start <> invalid
            finalStart = m.skips.start
        else
            finalStart = 0
        end if
    end if

    m.skips.start = finalStart
    m.skips.end = finalEnd

    seekTime = 0
    if m.skipEnabled = true
        if m.skipType = "start"
            seekTime = finalStart
        else
            seekTime = finalEnd
        end if
    end if

    saved = {
        "skips": m.skips,
        "skipEnabled": m.skipEnabled,
        "skipType": m.skipType,
        "seekTime": seekTime
    }
    m.top.saved = saved
    setOkFocus(false)
    parent = m.top.getParent()
    if parent <> invalid
        parent.setFocus(true)
    end if
    m.top.visible = false
end sub

function getGlobalIndex(list as Object) as Integer
    if list = invalid
        return 0
    end if
    return m.pageStartIndex + list.itemFocused
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    if press = false
        return false
    end if

    if m.top.visible = false
        return false
    end if

    if key = "back"
        parent = m.top.getParent()
        if parent <> invalid
            parent.setFocus(true)
        end if
        m.top.visible = false
        return true
    end if

    thumbCount = getThumbCount()

    if key = "OK"
        if m.focusOnOk = true
            saveSkipSetting()
            return true
        end if
        if m.moreBtn.hasFocus() = true
            loadThumbs(true)
            return true
        end if
        if m.rulerLeft.hasFocus() = true
            turnPage(-1)
            return true
        end if
        if m.rulerRight.hasFocus() = true
            turnPage(1)
            return true
        end if
        if m.optionList.hasFocus() = true
            toggleOption()
            return true
        end if
    end if

    if key = "left"
        if m.moreBtn.hasFocus() = true
            syncSelection(thumbCount - 1, true)
            updateRulerStyle()
            return true
        end if
        if m.rulerRight.hasFocus() = true
            m.rulerLeft.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.rulerLeft.hasFocus() = true
            m.timeList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.timeList.hasFocus() = true
            globalIdx = getGlobalIndex(m.timeList)
            if m.timeList.itemFocused = 0 and globalIdx > 0
                syncSelection(globalIdx - 1, true)
                return true
            end if
            return false
        end if
        if m.thumbList.hasFocus() = true
            globalIdx = getGlobalIndex(m.thumbList)
            if m.thumbList.itemFocused = 0
                if globalIdx > 0
                    syncSelection(globalIdx - 1, true)
                    return true
                else
                    m.tabList.SetFocus(true)
                    updateRulerStyle()
                    return true
                end if
            end if
            return false
        end if
        if m.okBtn.hasFocus() = true or m.focusOnOk = true
            m.optionList.SetFocus(true)
            setOkFocus(false)
            updateRulerStyle()
            return true
        end if
    end if

    if key = "right"
        if m.thumbList.hasFocus() = true
            globalIdx = getGlobalIndex(m.thumbList)
            if globalIdx < thumbCount - 1 and m.thumbList.itemFocused >= localPageLastIndex()
                syncSelection(globalIdx + 1, true)
                return true
            end if
            if globalIdx >= thumbCount - 1
                m.moreBtn.SetFocus(true)
                updateRulerStyle()
                return true
            end if
            return false
        end if
        if m.rulerLeft.hasFocus() = true
            m.rulerRight.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.rulerRight.hasFocus() = true
            m.timeList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.timeList.hasFocus() = true
            globalIdx = getGlobalIndex(m.timeList)
            if globalIdx < thumbCount - 1 and m.timeList.itemFocused >= localPageLastIndex()
                syncSelection(globalIdx + 1, true)
                return true
            end if
            return false
        end if
        if m.optionList.hasFocus() = true
            m.okBtn.SetFocus(true)
            setOkFocus(true)
            updateRulerStyle()
            return true
        end if
    end if

    if key = "up"
        if m.thumbList.hasFocus() = true or m.timeList.hasFocus() = true or m.moreBtn.hasFocus() = true
            m.tabList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.rulerLeft.hasFocus() = true or m.rulerRight.hasFocus() = true
            m.timeList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.optionList.hasFocus() = true
            m.thumbList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.okBtn.hasFocus() = true or m.focusOnOk = true
            m.optionList.SetFocus(true)
            setOkFocus(false)
            updateRulerStyle()
            return true
        end if
    end if

    if key = "down"
        if m.tabList.hasFocus() = true
            if getThumbCount() > 0
                m.thumbList.SetFocus(true)
            end if
            updateRulerStyle()
            return true
        end if
        if m.thumbList.hasFocus() = true or m.moreBtn.hasFocus() = true
            m.timeList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.timeList.hasFocus() = true
            m.rulerLeft.SetFocus(true)
            updateRulerStyle()
            return true
        end if
        if m.rulerLeft.hasFocus() = true or m.rulerRight.hasFocus() = true
            m.optionList.SetFocus(true)
            updateRulerStyle()
            return true
        end if
    end if

    updateRulerStyle()
    updateOkBtnStyle()
    return false
end function
