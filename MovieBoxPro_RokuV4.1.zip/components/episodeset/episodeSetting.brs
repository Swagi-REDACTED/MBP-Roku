sub Init()
    m.overlay = m.top.findNode("overlay")
    m.episodeSheet = m.top.findNode("episodeSheet")
    m.seasonsPop = m.top.findNode("seasonsPop")
    m.seasonBtn = m.top.findNode("seasonBtn")
    m.seasonLabel = m.top.findNode("seasonLabel")
    m.seasonChevron = m.top.findNode("seasonChevron")
    m.loadingText = m.top.findNode("loadingText")
    m.episodeList = m.top.findNode("episodeList")
    m.seasonBackBtn = m.top.findNode("seasonBackBtn")
    m.seasonList = m.top.findNode("seasonList")

    m.episodeList.ObserveField("rowItemSelected", "onEpisodeSelected")
    m.episodeList.ObserveField("rowItemFocused", "onEpisodeRowFocused")
    m.seasonList.ObserveField("itemSelected", "onSeasonSelected")

    m.seasons = []
    m.episodes = []
    m.currentSeason = 1
    m.playSeason = 1
    m.playEpisode = 1
    m.mid = 0
    m.loading = false
    m.maxSeason = 0
    m.seasonBtnFocused = false
end sub

sub OnContentChange()
    data = m.top.content
    if data = invalid
        return
    end if

    oldMid = m.mid
    m.mid = 0
    if data.mid <> invalid
        m.mid = data.mid
    end if
    m.playSeason = 1
    if data.play_season <> invalid
        m.playSeason = data.play_season
    else if data.season <> invalid
        m.playSeason = data.season
    end if
    m.playEpisode = 1
    if data.play_episode <> invalid
        m.playEpisode = data.play_episode
    end if
    incoming = asSeasonArray(data.seasons)
    if incoming.Count() > 0
        m.seasons = incoming
    else if oldMid <> invalid and m.mid <> invalid and oldMid <> 0 and oldMid <> m.mid
        m.seasons = []
    end if
    m.maxSeason = 0
    if data.max_season <> invalid
        m.maxSeason = toEpisodeInt(data.max_season)
    end if

    season = m.playSeason
    if data.season <> invalid
        season = data.season
    end if
    closeSeasonsPop()
    if m.epTask <> invalid
        m.epTask.unobserveField("content")
        m.epTask.control = "STOP"
        m.epTask = invalid
    end if
    m.loading = false
    loadSeason(season, true)
end sub

sub loadSeason(season as Dynamic, needSeasons as Boolean)
    if m.loading = true
        return
    end if
    if season = invalid
        season = m.playSeason
    end if
    m.loading = true
    m.currentSeason = season
    m.seasonLabel.text = seasonTitle(season)
    layoutSeasonButton()
    m.loadingText.text = "Loading..."
    m.loadingText.visible = true
    m.episodeList.visible = false

    req = {
        "type": "tv_player_episodes",
        "mid": m.mid,
        "season": season,
        "need_seasons": 1
    }
    if m.seasons <> invalid and m.seasons.Count() > 0
        req["seasons"] = m.seasons
        if needSeasons <> true
            req["need_seasons"] = 0
        end if
    end if
    if m.maxSeason <> invalid and m.maxSeason > 0
        req["max_season"] = m.maxSeason
    end if

    m.epTask = createObject("RoSGNode", "GetContentReader")
    m.epTask.content = req
    m.epTask.observeField("content", "onEpisodesLoaded")
    m.epTask.control = "RUN"
end sub

sub onEpisodesLoaded()
    result = m.epTask.content
    if result = invalid
        return
    end if
    if result.type <> invalid
        return
    end if
    m.loading = false
    if result.code <> invalid and result.code <= 0
        msg = "Failed to load episodes"
        if result.msg <> invalid and result.msg <> ""
            msg = result.msg
        end if
        m.loadingText.text = msg
        m.loadingText.visible = true
        m.loading = false
        return
    end if

    data = result.data
    if data = invalid
        m.loadingText.text = "Failed to load episodes"
        m.loadingText.visible = true
        return
    end if

    if data.seasons <> invalid
        incoming = asSeasonArray(data.seasons)
        if incoming.Count() > 1 or m.seasons = invalid or m.seasons.Count() <= 1
            if incoming.Count() > 0
                m.seasons = incoming
            end if
        end if
    end if
    if data.episodes <> invalid
        m.episodes = data.episodes
    else
        m.episodes = []
    end if
    if GetInterface(m.episodes, "ifArray") = invalid
        m.episodes = []
    end if
    if GetInterface(m.seasons, "ifArray") = invalid
        incoming = asSeasonArray(m.seasons)
        if incoming.Count() > 0
            m.seasons = incoming
        else if m.seasons = invalid
            m.seasons = []
        end if
    end if
    if data.season <> invalid
        m.currentSeason = data.season
    end if
    m.seasonLabel.text = seasonTitle(m.currentSeason)
    layoutSeasonButton()
    renderSeasons()
    renderEpisodes()
end sub

sub renderSeasons()
    content = createObject("roSGNode", "ContentNode")
    jumpIndex = 0
    i = 0
    for each item in m.seasons
        seasonNum = seasonValue(item)
        child = content.createChild("ContentNode")
        child.title = seasonTitle(seasonNum)
        child.Description = "S" + seasonNum.ToStr()
        child.addField("season", "integer", false)
        child.season = seasonNum
        child.addField("isActive", "string", false)
        if seasonNum = m.currentSeason
            child.isActive = "true"
            jumpIndex = i
        else
            child.isActive = "false"
        end if
        i = i + 1
    end for
    m.seasonList.content = content
    if content.getChildCount() > 0
        m.seasonList.jumpToItem = jumpIndex
    end if
end sub

sub renderEpisodes()
    root = createObject("roSGNode", "ContentNode")
    row = root.createChild("ContentNode")
    playIndex = 0
    i = 0
    for each ep in m.episodes
        child = row.createChild("ContentNode")
        epSeason = 1
        epNum = 1
        if ep.season <> invalid
            epSeason = ep.season
        end if
        if ep.episode <> invalid
            epNum = ep.episode
        end if

        title = "Episode " + epNum.ToStr()
        if ep.title <> invalid and ep.title <> ""
            title = ep.title
        end if
        child.title = title

        playing = false
        if epSeason = m.playSeason and epNum = m.playEpisode
            playing = true
            playIndex = i
        end if

        badge = "S" + epSeason.ToStr() + "E" + epNum.ToStr()
        if playing = true
            badge = badge + " · Now Playing"
        end if
        child.Description = badge

        if ep.thumbs <> invalid
            child.hdposterurl = ep.thumbs
        end if
        if ep.synopsis <> invalid
            child.shortdescriptionline1 = ep.synopsis
        else
            child.shortdescriptionline1 = ""
        end if

        hasVideo = 1
        if ep.has_video <> invalid
            hasVideo = ep.has_video
        end if

        seconds = episodeResumeSeconds(ep)

        data = {
            "season": epSeason,
            "episode": epNum,
            "imdb_id": ep.imdb_id,
            "seconds": seconds,
            "playing": 0,
            "has_video": hasVideo
        }
        if playing = true
            data.playing = 1
        end if
        child.addField("data", "assocarray", false)
        child.data = data
        child.addField("resumeSeconds", "integer", false)
        child.resumeSeconds = seconds
        i = i + 1
    end for

    ' RowList consumes Down internally. A second logical row lets Roku perform its
    ' normal navigation; the focus observer immediately closes the episode panel.
    closeRow = root.createChild("ContentNode")
    closeItem = closeRow.createChild("ContentNode")
    closeItem.title = "Close Episodes"
    closeItem.Description = "Down to close"
    closeItem.shortdescriptionline1 = ""
    closeData = {"season":m.playSeason, "episode":m.playEpisode, "seconds":0, "playing":0, "has_video":0}
    closeItem.addField("data", "assocarray", false)
    closeItem.data = closeData

    m.episodeList.content = root
    m.loadingText.visible = false
    if row.getChildCount() > 0
        m.episodeList.visible = true
        m.episodeList.jumpToRowItem = [0, playIndex]
        m.episodeList.SetFocus(true)
        m.seasonBtnFocused = false
        updateSeasonBtnStyle()
    else
        m.loadingText.text = "No episodes"
        m.loadingText.visible = true
        m.seasonBtn.SetFocus(true)
        m.seasonBtnFocused = true
        updateSeasonBtnStyle()
    end if
end sub

sub onEpisodeRowFocused()
    focused = m.episodeList.rowItemFocused
    if focused = invalid or focused.Count() < 2
        return
    end if
    if m.episodeList.hasFocus() <> true
        return
    end if
    if focused[0] > 0
        closePanel()
    end if
end sub

sub onEpisodeSelected()
    if m.episodeList.rowItemSelected = invalid
        return
    end if
    row = m.episodeList.rowItemSelected[0]
    col = m.episodeList.rowItemSelected[1]
    if row > 0
        closePanel()
        return
    end if
    rowNode = m.episodeList.content.getChild(row)
    if rowNode = invalid
        return
    end if
    item = rowNode.getChild(col)
    if item = invalid or item.data = invalid
        return
    end if
    if item.data.has_video = 0
        return
    end if
    if item.data.playing = 1
        closePanel()
        return
    end if

    seconds = 0
    if item.resumeSeconds <> invalid
        seconds = item.resumeSeconds
    else if item.data.seconds <> invalid
        seconds = toEpisodeInt(item.data.seconds)
    end if

    m.top.play_episode = {
        "season": item.data.season,
        "episode": item.data.episode,
        "imdb_id": item.data.imdb_id,
        "seconds": seconds,
        "episodes": m.episodes
    }
    closePanel()
end sub

sub onSeasonSelected()
    item = m.seasonList.content.getChild(m.seasonList.itemSelected)
    if item = invalid
        return
    end if
    seasonNum = m.currentSeason
    if item.season <> invalid
        seasonNum = item.season
    end if
    closeSeasonsPop()
    if seasonNum = m.currentSeason
        m.episodeList.SetFocus(true)
        return
    end if
    loadSeason(seasonNum, false)
end sub

sub openSeasonsPop()
    if m.seasons = invalid or m.seasons.Count() = 0
        return
    end if
    m.episodeSheet.visible = false
    m.seasonsPop.visible = true
    m.seasonList.SetFocus(true)
end sub

sub closeSeasonsPop()
    m.seasonsPop.visible = false
    m.episodeSheet.visible = true
    m.seasonBtnFocused = false
    updateSeasonBtnStyle()
end sub

sub closePanel()
    closeSeasonsPop()
    m.top.visible = false
    parent = m.top.getParent()
    if parent <> invalid
        parent.setFocus(true)
    end if
end sub

sub layoutSeasonButton()
    text = "Season 1"
    if m.seasonLabel <> invalid and m.seasonLabel.text <> invalid
        text = m.seasonLabel.text
    end if
    textW = Len(text) * 12
    if textW < 80
        textW = 80
    end if
    m.seasonLabel.width = textW
    m.seasonChevron.translation = [textW + 6, 11]
    m.seasonBtn.width = textW + 28
end sub

sub updateSeasonBtnStyle()
    if m.seasonBtnFocused = true
        m.seasonBtn.color = "0xFFFFFF26"
        m.seasonLabel.color = "0xFFFFFFFF"
    else
        m.seasonBtn.color = "0xFFFFFF00"
        m.seasonLabel.color = "0xFFFFFFFF"
    end if
end sub

function toEpisodeInt(v as Dynamic) as Integer
    if v = invalid
        return 0
    end if
    t = Type(v)
    if t = "roString" or t = "String"
        if v = ""
            return 0
        end if
        return v.ToInt()
    end if
    return Int(v)
end function

function asSeasonArray(raw as Dynamic) as Object
    seasons = []
    seen = {}
    if raw = invalid
        return seasons
    end if
    if GetInterface(raw, "ifArray") <> invalid
        for each item in raw
            n = seasonValue(item)
            key = n.ToStr()
            if n > 0 and seen[key] = invalid
                seasons.Push(n)
                seen[key] = 1
            end if
        end for
        return seasons
    end if
    if GetInterface(raw, "ifAssociativeArray") <> invalid
        for each key in raw
            n = seasonValue(raw[key])
            if n <= 0
                n = toEpisodeInt(key)
            end if
            skey = n.ToStr()
            if n > 0 and seen[skey] = invalid
                seasons.Push(n)
                seen[skey] = 1
            end if
        end for
    end if
    return seasons
end function

function episodeResumeSeconds(ep as Dynamic) as Integer
    if ep = invalid
        return 0
    end if
    progress = invalid
    if ep.play_progress <> invalid
        progress = ep.play_progress
    end if
    overVal = 0
    seconds = 0
    if progress <> invalid
        if GetInterface(progress, "ifAssociativeArray") <> invalid
            if progress.over <> invalid
                overVal = toEpisodeInt(progress.over)
            end if
            if progress.seconds <> invalid
                seconds = toEpisodeInt(progress.seconds)
            end if
        else
            seconds = toEpisodeInt(progress)
        end if
    else if ep.seconds <> invalid
        seconds = toEpisodeInt(ep.seconds)
    end if
    if overVal = 1
        return 0
    end if
    return seconds
end function

function seasonValue(item as Dynamic) as Integer
    if item = invalid
        return 1
    end if
    if GetInterface(item, "ifAssociativeArray") <> invalid
        if item.season <> invalid
            return toEpisodeInt(item.season)
        end if
    end if
    return toEpisodeInt(item)
end function

function seasonTitle(season as Dynamic) as String
    num = seasonValue(season)
    if num > 1500
        return "Year " + num.ToStr()
    end if
    return "Season " + num.ToStr()
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    if press = false
        return false
    end if
    if m.top.visible = false
        return false
    end if

    if key = "back"
        if m.seasonsPop.visible = true
            closeSeasonsPop()
            m.seasonBtn.SetFocus(true)
            m.seasonBtnFocused = true
            updateSeasonBtnStyle()
            return true
        end if
        closePanel()
        return true
    end if

    if m.seasonsPop.visible = true
        if key = "OK"
            if m.seasonBackBtn.hasFocus() = true
                closeSeasonsPop()
                m.seasonBtn.SetFocus(true)
                m.seasonBtnFocused = true
                updateSeasonBtnStyle()
                return true
            end if
        else if key = "up"
            if m.seasonList.hasFocus() = true
                m.seasonBackBtn.SetFocus(true)
                return true
            end if
        else if key = "down"
            if m.seasonBackBtn.hasFocus() = true
                m.seasonList.SetFocus(true)
                return true
            end if
        else if key = "left"
            if m.seasonList.hasFocus() = true
                m.seasonBackBtn.SetFocus(true)
                return true
            end if
        end if
        return true
    end if

    if key = "OK"
        if m.seasonBtn.hasFocus() = true
            openSeasonsPop()
            return true
        end if
    else if key = "up"
        if m.episodeList.hasFocus() = true
            m.seasonBtn.SetFocus(true)
            m.seasonBtnFocused = true
            updateSeasonBtnStyle()
            return true
        end if
    else if key = "down"
        if m.seasonBtn.hasFocus() = true
            m.seasonBtnFocused = false
            updateSeasonBtnStyle()
            if m.episodeList.visible = true
                m.episodeList.SetFocus(true)
            end if
            return true
        end if
    else if key = "left" or key = "right"
        if m.seasonBtn.hasFocus() = true
            return true
        end if
    end if

    return false
end function
