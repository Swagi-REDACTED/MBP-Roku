'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.search = m.top.findNode("search")
    m.searchbtn = m.top.findNode("searchbtn")
    m.hotlist = m.top.findNode("hotlist")
    m.keyboard = m.top.findNode("searchKeyboard")
    m.searchbg = m.top.findNode("searchbg")
    m.searchtitle = m.top.findNode("searchTitle")
    m.search_type = m.top.findNode("search_type")
    m.error_txt = m.top.findNode("error_txt")
    m.searchlist = m.top.findNode("searchList")
    m.searchlist2 = m.top.findNode("searchList2")
    m.searchlist3 = m.top.findNode("searchList3")
    m.searchlist4 = m.top.findNode("searchList4")
    m.searchlist.observeField("itemSelected","searchMovieDetail")
    m.searchlist2.observeField("itemSelected","searchMovieDetail2")
    m.searchlist3.observeField("itemSelected","searchMovieDetail3")
    m.searchlist4.observeField("itemSelected","searchMovieDetail4")

    m.searchbtn.buttons = ["Search"]

    m.searchPage = 1
    m.searchbtn.ObserveField("buttonSelected", "search")

    m.hotlist.ObserveField("itemSelected", "hotSearch")

    m.keyboard.textEditBox.hintText = "Search"
    m.keyboard.ObserveField("text", "changetext")

    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "All"
    child = contentRoot.createChild("ContentNode")
    child.title = "Movies"
    child = contentRoot.createChild("ContentNode")
    child.title = "TV Shows"
    child = contentRoot.createChild("ContentNode")
    child.title = "Playlists"
    m.search_type.content = contentRoot
    m.search_type.ObserveField("itemFocused", "search_type")
    m.search_type.ObserveField("itemSelected", "search_type2")
    
    m.hotlist.setFocus(true)

    arr = {"type":"searchhot"}
    m.hotTask = createObject("RoSGNode","GetContentReader")
    m.hotTask.content = arr
    m.hotTask.observeField("content", "sethotlist")
    m.hotTask.control = "RUN"
end function

sub changetext()
    ' print m.keyboard.text
    m.search.text = m.keyboard.text

    if m.search.text = ""
        if m.hotTask.content = invalid
            aa = {}
            m.hotlist.content = keyToContentNode(aa)
        else
            m.hotlist.content = keyToContentNode(m.hotTask.content.data)
        end if
    end if

    if m.timer <> invalid
        m.timer.control = "stop"
    end if
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 0.5
    m.timer.repeat = false
    m.timer.control = "start"
    m.timer.ObserveField("fire","autocomplete")
end sub

sub autocomplete()
    arr = {"type":"autocomplete","key":m.search.text}
    m.autocompleteTask = createObject("RoSGNode","GetContentReader")
    m.autocompleteTask.content = arr
    m.autocompleteTask.observeField("content", "setAutocomplete")
    m.autocompleteTask.control = "RUN"
end sub

sub setAutocomplete()
    if m.autocompleteTask.content <> invalid
        content = m.autocompleteTask.content
        if m.search.text <> ""
            m.hotlist.content = keyToContentNode(content.data)
        end if
    end if
end sub

sub sethotlist()
    if m.hotTask.content <> invalid
        content = m.hotTask.content
        m.hotlist.content = keyToContentNode(content.data)
    end if
end sub

sub hotSearch()
    text = m.hotlist.content.getChild(m.hotlist.itemSelected)
    m.search.text = text.title
    search()
end sub

sub search()
    m.type = "all"
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
    key = m.search.text
    arr = {"key":key,"page":1,"type2":"all","type":"search"}
    m.searchlist.visible = true
    m.searchTask = createObject("RoSGNode","GetContentReader")
    m.searchTask.content = arr
    m.searchTask.observeField("content", "setSearchList")
    m.searchTask.control = "RUN"
end sub

sub search_type()
    index = m.search_type.itemFocused
    if index = 0 and m.type <> "all"
        m.type = "all"
        search2()
    elseif index = 1 and m.type <> "movie"
        m.type = "movie"
        search2()
    elseif index = 2 and m.type <> "tv"
        m.type = "tv"
        search2()
    elseif index = 3 and m.type <> "playlists"
        m.type = "playlists"
        search2()
    end if
end sub

sub search_type2()
    index = m.search_type.itemSelected
    m.searchreload = 1
    if index = 0 and m.type <> "all"
        m.type = "all"
        search2()
    elseif index = 1 and m.type <> "movie"
        m.type = "movie"
        search2()
    elseif index = 2 and m.type <> "tv"
        m.type = "tv"
        search2()
    elseif index = 3 and m.type <> "playlists"
        m.type = "playlists"
        search2()
    end if
end sub

sub searchMovieDetail()
    aa = m.searchlist.content.getChild(m.searchlist.itemSelected)
    arr3 = aa.data
    arr3["title"] = aa.title
    arr3["cover"] = aa.hdposterurl
    m.moviedata = FormatJson(arr3)
    movie_detail(m.moviedata)
end sub

sub searchMovieDetail2()
    aa = m.searchlist2.content.getChild(m.searchlist2.itemSelected)
    arr3 = aa.data
    arr3["title"] = aa.title
    arr3["cover"] = aa.hdposterurl
    m.moviedata = FormatJson(arr3)
    movie_detail(m.moviedata)
end sub

sub searchMovieDetail3()
    aa = m.searchlist3.content.getChild(m.searchlist3.itemSelected)
    arr3 = aa.data
    arr3["title"] = aa.title
    arr3["cover"] = aa.hdposterurl
    m.moviedata = FormatJson(arr3)
    movie_detail(m.moviedata)
end sub

sub searchMovieDetail4()
    aa = m.searchlist4.content.getChild(m.searchlist4.itemSelected)
    data = {"id":aa.data.lid}
    list_detail = createObject("roSGNode", "PlayList2")
    list_detail.arr = data
    list_detail.id = "list_detail"
    m.top.appendChild(list_detail)
    m.list_detail_status = 1
    m.list_detail = m.top.findNode("list_detail")
end sub

sub movie_detail(data)
    detail = createObject("roSGNode", "DetailScreen")
    detail.movieid = data
    detail.id = "moviedetail"
    m.top.appendChild(detail)
    m.detail = m.top.findNode("moviedetail")
    m.operates = m.detail.findNode("operates")
    m.operates.setFocus(true)
end sub

sub search2()
    key = m.search.text
    arr = {"key":key,"page":1,"type2":m.type,"type":"search"}
    if m.type = "all"
        m.searchlist2.visible = false
        m.searchlist3.visible = false
        m.searchlist4.visible = false
        m.searchlist.visible = true
        if m.searchlist.content = invalid or m.searchreload <> invalid
            m.searchreload = invalid
            m.searchPage = 1
            m.searchTask = createObject("RoSGNode","GetContentReader")
            m.searchTask.content = arr
            m.searchTask.observeField("content", "setSearchList")
            m.searchTask.control = "RUN"
        end if
    elseif m.type = "movie"
        m.searchlist.visible = false
        m.searchlist3.visible = false
        m.searchlist4.visible = false
        m.searchlist2.visible = true
        if m.searchlist2.content = invalid or m.searchreload <> invalid
            m.searchreload = invalid
            m.searchPage2 = 1    
            m.searchTask2 = createObject("RoSGNode","GetContentReader")
            m.searchTask2.content = arr
            m.searchTask2.observeField("content", "setSearchList2")
            m.searchTask2.control = "RUN"
        end if
    elseif m.type = "tv"
        m.searchlist.visible = false
        m.searchlist2.visible = false
        m.searchlist4.visible = false
        m.searchlist3.visible = true
        if m.searchlist3.content = invalid or m.searchreload <> invalid
            m.searchreload = invalid
            m.searchPage3 = 1
            m.searchTask3 = createObject("RoSGNode","GetContentReader")
            m.searchTask3.content = arr
            m.searchTask3.observeField("content", "setSearchList3")
            m.searchTask3.control = "RUN"
        end if
    elseif m.type = "playlists"
        m.searchlist.visible = false
        m.searchlist2.visible = false
        m.searchlist3.visible = false
        m.searchlist4.visible = true
        if m.searchlist4.content = invalid or m.searchreload <> invalid
            m.searchreload = invalid
            m.searchPage4 = 1
            m.searchTask4 = createObject("RoSGNode","GetContentReader")
            m.searchTask4.content = arr
            m.searchTask4.observeField("content", "setSearchList4")
            m.searchTask4.control = "RUN"
        end if
    end if
end sub

sub setSearchList()
    if m.loading <> invalid
        m.top.removeChild(m.loading)
    end if
    if m.searchTask.content.type <> invalid
        return
    end if
    if m.searchTask.content = invalid or m.searchTask.content.code = invalid
        m.error_txt.text = "Search failed"
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        return
    end if
    if m.searchTask.content.code <= 0
        m.error_txt.text = m.searchTask.content.msg
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
    else
        m.error_txt.visible = false
        content = m.searchTask.content
        m.searchlist.content = searchToContentNode(content.data, "")
        m.searchtitle.text = content.total.Tostr()+" results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        if m.search_type.hasFocus() = false
            m.searchlist.setFocus(true)
        end if
    end if
end sub

sub setSearchList2()
    if m.searchTask2.content.type <> invalid
        return
    end if
    if m.searchTask2.content = invalid or m.searchTask2.content.code = invalid
        m.error_txt.text = "Search failed"
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        return
    end if
    if m.searchTask2.content.code <= 0
        m.error_txt.text = m.searchTask2.content.msg
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
    else
        m.error_txt.visible = false
        content = m.searchTask2.content
        m.searchlist2.content = searchToContentNode(content.data, "")
        m.searchtitle.text = content.total.Tostr()+" results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        if m.search_type.hasFocus() = false
            m.searchlist2.setFocus(true)
        end if
    end if
end sub

sub setSearchList3()
    if m.searchTask3.content.type <> invalid
        return
    end if
    if m.searchTask3.content = invalid or m.searchTask3.content.code = invalid
        m.error_txt.text = "Search failed"
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        return
    end if
    if m.searchTask3.content.code <= 0
        m.error_txt.text = m.searchTask3.content.msg
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
    else
        m.error_txt.visible = false
        content = m.searchTask3.content
        m.searchlist3.content = searchToContentNode(content.data, "")
        m.searchtitle.text = content.total.Tostr()+" results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        if m.search_type.hasFocus() = false
            m.searchlist3.setFocus(true)
        end if
    end if
end sub

sub setSearchList4()
    if m.searchTask4.content.type <> invalid
        return
    end if
    if m.searchTask4.content = invalid or m.searchTask4.content.code = invalid
        m.error_txt.text = "Search failed"
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        return
    end if
    if m.searchTask4.content.code <= 0
        m.error_txt.text = m.searchTask4.content.msg
        m.error_txt.visible = true
        m.searchtitle.text = "0 results found for “"+m.search.text+"”"
        m.searchbg.visible = true
    else
        m.error_txt.visible = false
        content = m.searchTask4.content
        m.searchlist4.content = searchToContentNode(content.data, "playlists")
        m.searchtitle.text = content.total.Tostr()+" results found for “"+m.search.text+"”"
        m.searchbg.visible = true
        if m.search_type.hasFocus() = false
            m.searchlist4.setFocus(true)
        end if
    end if
end sub

sub searchScroll()
    if m.searchPageStatus = invalid
        m.searchPageStatus = false
    end if
    if m.searchPageStatus = false
        m.searchPageStatus = true
        if m.type = "all"
            m.searchPage = m.searchPage + 1
            page2 = m.searchPage
        elseif m.type = "movie"
            m.searchPage2 = m.searchPage2 + 1
            page2 = m.searchPage2
        elseif m.type = "tv"
            m.searchPage3 = m.searchPage3 + 1
            page2 = m.searchPage3
        elseif m.type = "playlists"
            m.searchPage4 = m.searchPage4 + 1
            page2 = m.searchPage4
        end if
        key = m.search.text
        arr = {"key":key,"page":page2,"type2":m.type,"type":"search"}
        m.search2Task = createObject("RoSGNode","GetContentReader")
        m.search2Task.content = arr
        m.search2Task.observeField("content", "addSearchList")
        m.search2Task.control = "RUN"
    end if
end sub

sub addSearchList()
    m.searchPageStatus = false
    if m.search2Task.content.type <> invalid
        return
    end if
    if m.search2Task.content = invalid or m.search2Task.content.data = invalid or m.search2Task.content.code <= 0
        if m.type = "all"
            m.searchPage = m.searchPage - 1
        elseif m.type = "movie"
            m.searchPage2 = m.searchPage2 - 1
        elseif m.type = "tv"
            m.searchPage3 = m.searchPage3 - 1
        elseif m.type = "playlists"
            m.searchPage4 = m.searchPage4 - 1
        end if
        return
    end if
    if m.search2Task.content.data.Count() > 0
        arr = searchToContentNode2(m.search2Task.content.data)
        if m.type = "all"
            m.searchlist.content.appendChildren(arr)
            m.searchlist.jumpToItem = m.searchlist.itemFocused + 6
        elseif m.type = "movie"
            m.searchlist2.content.appendChildren(arr)
            m.searchlist2.jumpToItem = m.searchlist2.itemFocused + 6
        elseif m.type = "tv"
            m.searchlist3.content.appendChildren(arr)
            m.searchlist3.jumpToItem = m.searchlist3.itemFocused + 6
        elseif m.type = "playlists"
            m.searchlist4.content.appendChildren(arr)
            m.searchlist4.jumpToItem = m.searchlist4.itemFocused + 3
        end if
    else
        if m.type = "all"
            m.searchPage = m.searchPage - 1
        elseif m.type = "movie"
            m.searchPage2 = m.searchPage2 - 1
        elseif m.type = "tv"
            m.searchPage3 = m.searchPage3 - 1
        elseif m.type = "playlists"
            m.searchPage4 = m.searchPage4 - 1
        end if
    end if
end sub

function keyToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key
    end for
    return ContentNode
end function

function searchToContentNode(Content as Object, type3 as String) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    if type3 = "playlists"
        for each key in Content
            ItemContent = ContentNode.createChild("ContentNode")
            ItemContent.title = key.name
            ItemContent.hdposterurl = key.imgArr[0]
            data = CreateObject("roAssociativeArray")
            data["lid"] = key.lid
            data["count"] = key.count
            data["box_type"] = 3
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
        end for
    else
        for each key in Content
            ItemContent = ContentNode.createChild("ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if data["box_type"] = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag <> invalid
                    data["quality_tag_new"] = key.quality_tag
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
        end for
    end if
    return ContentNode
end function

function searchToContentNode2(Content as Object) as Object
    arr = []
    if m.type = "playlists"
        for each key in Content
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.name
            ItemContent.hdposterurl = key.imgArr[0]
            data = CreateObject("roAssociativeArray")
            data["lid"] = key.lid
            data["count"] = key.count
            data["box_type"] = 3
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
    else
        for each key in Content
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.box_type = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag <> invalid
                    data["quality_tag_new"] = key.quality_tag
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
    end if
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "left"
            if m.searchbg.visible = false
                m.hotlist.setFocus(true)
                result = true
            end if
        else if key = "right" then
            if m.searchbg.visible = false
                m.keyboard.setFocus(true)
                result = true
            end if
        else if key = "up" then
            if m.searchbg.visible = false and m.hotlist.hasFocus() = false
                m.keyboard.setFocus(true)
                result = true
            end if
            if m.searchbg.visible = true
                m.search_type.setFocus(true)
                result = true
            end if
        else if key = "back" then
            if m.detail <> invalid and m.detail.visible = true
                m.top.removeChild(m.detail)
                m.detail = invalid
                if m.searchlist.visible = true
                    m.searchlist.setFocus(true)
                end if
                if m.searchlist2.visible = true
                    m.searchlist2.setFocus(true)
                end if
                if m.searchlist3.visible = true
                    m.searchlist3.setFocus(true)
                end if
                return true
            end if
            if m.list_detail <> invalid and m.list_detail.visible = true
                m.top.removeChild(m.list_detail)
                m.list_detail = invalid
                m.searchlist4.setFocus(true)
                return true
            end if
            if m.searchbg.visible = true
                m.searchPage = 1
                m.searchbg.visible = false
                m.search_type.jumpToItem = 0
                m.searchlist.content = invalid
                m.searchlist2.content = invalid
                m.searchlist3.content = invalid
                m.searchlist4.content = invalid
                m.hotlist.setFocus(true)
                result = true
            end if
        else if key = "down" then
            if m.searchbg.visible = false and m.hotlist.hasFocus() = false
                m.searchbtn.setFocus(true)
                result = true
            end if
            if m.searchbg.visible = true and (m.searchlist.hasFocus() = true or m.searchlist2.hasFocus() = true or m.searchlist3.hasFocus() = true or m.searchlist4.hasFocus() = true)
                searchScroll()
                result = true
            end if
            if m.searchbg.visible = true and m.search_type.hasFocus() = true
                if m.searchlist.visible = true
                    m.searchlist.setFocus(true)
                end if
                if m.searchlist2.visible = true
                    m.searchlist2.setFocus(true)
                end if
                if m.searchlist3.visible = true
                    m.searchlist3.setFocus(true)
                end if
                if m.searchlist4.visible = true
                    m.searchlist4.setFocus(true)
                end if
                result = true
            end if
        end if
    end if
    return result
end function