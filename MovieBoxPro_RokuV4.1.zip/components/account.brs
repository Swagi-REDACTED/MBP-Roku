'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.avatar = m.top.findNode("avatar")
    m.username = m.top.findNode("username")
    m.vip = m.top.findNode("vip")
    m.expire = m.top.findNode("expire")
    m.log_out = m.top.findNode("log_out")

    m.greenPalette = createObject("roSGNode", "RSGPalette")

    m.greenPalette.colors = { DialogBackgroundColor: "0x202020FF" }
    m.log_out.palette = m.greenPalette
    m.log_out.observeField("buttonSelected","is_define")
    
    user = CreateObject("roRegistrySection", "User")
    m.avatar.uri = user.Read("avatar")
    m.username.text = user.Read("username")
    isvip = user.Read("isvip").ToInt()
    family = user.Read("family").ToInt()
    if isvip = 1 or family > 0
        dead_time = user.Read("dead_time").ToInt()
        date = CreateObject("roDateTime")
        date.FromSeconds(dead_time)
        time = date.asDateStringLoc("dd-MM-y")
        m.vip.visible = true
        m.expire.text = "expire date: "+time
    else
        m.vip.visible = false
        m.expire.text = "Free"
    end if

    m.btns = m.top.findNode("btns")
    btns = m.btns
    
    focusedTargetSet1 = createObject("roSGNode", "TargetSet")
    focusedTargetSet2 = createObject("roSGNode", "TargetSet")
    focusedTargetSet3 = createObject("roSGNode", "TargetSet")
    btns.focusedTargetSet = [ focusedTargetSet1, focusedTargetSet2, focusedTargetSet3 ]

    focusedTargetSet1.targetRects = [
        { x:0, y:0, height:70, width:80 },
        { x:100, y:0, height:70, width:80 },
        { x:200, y:0, height:70, width:155 }
    ]
    focusedTargetSet1.color = "0x00202020AA"
    focusedTargetSet1.focusIndex = 0

    focusedTargetSet2.targetRects = [
        { x:0, y:0, height:70, width:80 },
        { x:100, y:0, height:70, width:80 },
        { x:200, y:0, height:70, width:155 }
    ]
    focusedTargetSet2.color = "0x00202020AA"
    focusedTargetSet2.focusIndex = 1

    focusedTargetSet3.targetRects = [
        { x:0, y:0, height:70, width:80 },
        { x:100, y:0, height:70, width:80 },
        { x:200, y:0, height:70, width:155 }
    ]
    focusedTargetSet3.color = "0x00202020AA"
    focusedTargetSet3.focusIndex = 2

    m.btns.targetSet = btns.focusedTargetSet[0]

    m.btns.duration = 0
    m.btns.itemComponentName = "accountBtns"

    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "history"
    child = contentRoot.createChild("ContentNode")
    child.title = "setting"
    child = contentRoot.createChild("ContentNode")
    child.title = "sign out"
    m.btns.content = contentRoot
    m.btns.observeField("itemSelected","btnoperates")
end function

sub btnoperates()
    if m.btns.itemSelected = 0
        historys = createObject("roSGNode", "Historys")
        historys.id = "movie_historys"
        m.top.appendChild(historys)
        m.historys = m.top.findNode("movie_historys")
    elseif m.btns.itemSelected = 1
        setting = createObject("roSGNode", "setting")
        setting.id = "setting"
        m.top.appendChild(setting)
        m.setting = m.top.findNode("setting")
        m.userlist = m.setting.findNode("userlist")
        m.userlist.observeField("itemSelected","switch_account")
    elseif m.btns.itemSelected = 2
        m.log_out.visible = true
        m.log_out.setFocus(true)
    end if
end sub

sub switch_account()
    aa = m.userlist.content.getChild(m.userlist.itemSelected)
    if aa.shortdescriptionline1 <> "true"
        if aa.Description = "add"
            login2 = createObject("roSGNode", "login2")
            login2.id = "login2"
            m.top.appendChild(login2)
            m.login2 = m.top.findNode("login2")
            m.login2.observeField("new_uid","setlogin")
        else
            uid = aa.data.uid
            accounts = CreateObject("roRegistrySection", "accounts")
            list = accounts.Read("list")
            list = ParseJson(list)
            for each item in list
                if item.uid = uid
                    user = CreateObject("roRegistrySection", "User")
                    user.Write("uid",item.uid.Tostr())
                    user.Write("uid_v2",item.uid_v2)
                    ' user.Write("uid_token",item.uid_token)
                    user.Write("appid",item.appid)
                    user.Write("avatar",item.avatar)
                    user.Write("bind_gmail",item.bind_gmail)
                    user.Write("email",item.email)
                    user.Write("family",item.family.Tostr())
                    user.Write("isvip",item.isvip.Tostr())
                    user.Write("nickname",item.nickname)
                    user.Write("username",item.username)
                    user.Write("dead_time",item.dead_time.Tostr())
                    m.top.new_uid = item.uid
                end if
            end for
        end if
    end if
end sub

sub setlogin()
    m.top.new_uid = m.login2.new_uid
end sub

sub is_define()
    if m.log_out.buttonSelected = 0
        user = CreateObject("roRegistrySection", "User")
        sessionStore = CreateObject("roRegistrySection", "ApiSessionV2")
        sessionStore.Delete(user.Read("uid"))
        sessionStore.Flush()
        accounts = CreateObject("roRegistrySection", "accounts")
        if accounts.Exists("list") = true
            list = accounts.Read("list")
            list = ParseJson(list)
            userlist = []
            status = 0
            new_uid = 0
            for each item in list
                if item.uid <> user.Read("uid").ToInt()
                    if status = 0
                        user.Write("uid",item.uid.Tostr())
                        user.Write("uid_v2",item.uid_v2)
                        ' user.Write("uid_token",item.uid_token)
                        user.Write("appid",item.appid)
                        user.Write("avatar",item.avatar)
                        user.Write("bind_gmail",item.bind_gmail)
                        user.Write("email",item.email)
                        user.Write("family",item.family.Tostr())
                        user.Write("isvip",item.isvip.Tostr())
                        user.Write("nickname",item.nickname)
                        user.Write("username",item.username)
                        user.Write("dead_time",item.dead_time.Tostr())
                        status = 1
                        new_uid = item.uid
                    end if
                    userlist.Push(item)
                end if
            end for
            if userlist.Count() > 0
                accounts.Write("list",FormatJson(userlist))
            else
                accounts.Delete("list")
            end if
            if status = 1
                m.top.new_uid = new_uid
            else
                user.Delete("uid")
                user.Delete("uid_v2")
                ' user.Delete("uid_token")
                user.Delete("appid")
                user.Delete("avatar")
                user.Delete("bind_gmail")
                user.Delete("email")
                user.Delete("family")
                user.Delete("isvip")
                user.Delete("nickname")
                user.Delete("username")
                user.Delete("dead_time")
                m.log_out.visible = false
            end if
        else
            user.Delete("uid")
            user.Delete("uid_v2")
            ' user.Delete("uid_token")
            user.Delete("appid")
            user.Delete("avatar")
            user.Delete("bind_gmail")
            user.Delete("email")
            user.Delete("family")
            user.Delete("isvip")
            user.Delete("nickname")
            user.Delete("username")
            user.Delete("dead_time")
            m.log_out.visible = false
        end if
    else
        m.log_out.visible = false
        m.btns.setFocus(true)
    end if
end sub

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "back"
            if m.historys <> invalid and m.historys.visible = true
                m.top.removeChild(m.historys)
                m.historys = invalid
                m.btns.setFocus(true)
                result = true
            end if
            if m.log_out.visible = true
                m.log_out.visible = false
                m.btns.setFocus(true)
                result = true
            end if
            if m.setting <> invalid and m.setting.visible = true
                if m.login2 <> invalid and m.login2.visible = true
                    m.top.removeChild(m.login2)
                    m.login2 = invalid
                    m.userlist.setFocus(true)
                    return true
                end if
                m.top.removeChild(m.setting)
                m.setting = invalid
                m.btns.setFocus(true)
                result = true
            end if
        end if
    end if
    return result
end function