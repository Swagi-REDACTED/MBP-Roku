'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

sub applyChildModeMenuRefresh()
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("child_mode_dirty") = false or user.Read("child_mode_dirty") <> "1"
        return
    end if
    user.Delete("child_mode_dirty")
    if m.rowlist <> invalid
        m.rowlist.content = invalid
    end if
    if m.movies <> invalid
        m.movies.content = invalid
    end if
    if m.movie_toplist <> invalid
        m.movie_toplist.content = invalid
    end if
    if m.tvs <> invalid
        m.tvs.content = invalid
    end if
    if m.tv_toplist <> invalid
        m.tv_toplist.content = invalid
    end if
    if m.movielist <> invalid
        m.movielist.content = invalid
    end if
    if m.collects <> invalid
        m.collects.content = invalid
    end if
    if m.moviemenu = invalid
        return
    end if
    contentRoot3 = createObject("roSGNode", "ContentNode")
    child3 = contentRoot3.createChild("ContentNode")
    child3.title = "Featured"
    child3.hdposterurl = "pkg:/images/home_icon2.png"
    if getSuperChildModeEnabled() = false
        child3 = contentRoot3.createChild("ContentNode")
        child3.title = "Movies"
        child3.hdposterurl = "pkg:/images/movies_icon.png"
        child3 = contentRoot3.createChild("ContentNode")
        child3.title = "TV Shows"
        child3.hdposterurl = "pkg:/images/tvs_icon.png"
    end if
    if getChildModeEnabled() = false
        child3 = contentRoot3.createChild("ContentNode")
        child3.title = "MovieLists"
        child3.hdposterurl = "pkg:/images/list_icon.png"
    end if
    if getSuperChildModeEnabled() = false
        child3 = contentRoot3.createChild("ContentNode")
        child3.title = "Favorites"
        child3.hdposterurl = "pkg:/images/fav_icon.png"
    end if
    m.moviemenu.content = contentRoot3
    m.moviemenu.jumpToItem = 0
end sub

sub onSidebarSelected()
    menuTitle = m.moviemenu.content.getChild(m.moviemenu.itemSelected).title
    if menuTitle = "Featured" then
        if m.ppp = 0
            m.ppp = 1
            m.readerTask = CreateObject("roSGNode", "ContentReader")
            m.readerTask.observeField("content", "gotContent")
            m.readerTask.observeField("error", "errorContent")
            m.readerTask.control = "RUN"
            m.rowlist.jumpToItem = 0
        end if
    else if menuTitle = "Movies" then
        if m.ppp = 0
            m.ppp = 1
            get_toplist(1)
            get_filters(1)
            m.topmovie = invalid
            m.filtermovie = invalid
            m.filters = invalid
            m.movieDataTask = CreateObject("roSGNode", "movieContentReader")
            m.movieDataTask.observeField("content", "getmovies")
            m.movieDataTask.control = "RUN"
            m.moviesPage = 1
        end if
    else if menuTitle = "TV Shows" then
        if m.ppp = 0
            m.ppp = 1
            get_toplist(2)
            get_filters(2)
            m.toptv = invalid
            m.filtertv = invalid
            m.filters_tv = invalid
            m.tvDataTask = CreateObject("roSGNode", "tvContentReader")
            m.tvDataTask.observeField("content", "gettvs")
            m.tvDataTask.control = "RUN"
            m.tvsPage = 1
        end if
    else if menuTitle = "MovieLists" then
        m.movielistDataTask = CreateObject("roSGNode", "GetContentReader")
        m.movielistDataTask.content = {"type":"playlist","type2":"all","page":1,"limit":12}
        m.movielistDataTask.observeField("content", "getMovielist")
        m.movielistDataTask.control = "RUN"
    else if menuTitle = "Favorites" then
        m.collectDataTask = CreateObject("roSGNode", "GetContentReader")
        m.collectDataTask.content = {"page":1,"type":"collect"}
        m.collectDataTask.observeField("content", "getFavourites")
        m.collectDataTask.control = "RUN"
        m.collectsPage = 1
    end if
end sub

sub iconbtnSelected()
    index = m.icon_btns.itemSelected
    if index = 0
        m.watch_plan_more = 0
        watch_plan = createObject("roSGNode", "WatchPlan")
        watch_plan.id = "watch_plans"
        m.home.visible = false
        m.top.appendChild(watch_plan)
        m.watch_plans = m.top.findNode("watch_plans")
    elseif index = 1
        m.home.visible = false
        if m.search = invalid
            m.search = CreateObject("roSGNode", "Search")
            m.top.appendChild(m.search)
            m.searchhot = m.search.findNode("hotlist")
            m.searchlist = m.search.findNode("searchList")
            m.searchlist.observeField("itemSelected","searchMovieDetail")
            m.searchlist2 = m.search.findNode("searchList2")
            m.searchlist2.observeField("itemSelected","searchMovieDetail2")
            m.searchlist3 = m.search.findNode("searchList3")
            m.searchlist3.observeField("itemSelected","searchMovieDetail3")
            m.searchlist4 = m.search.findNode("searchList4")
            m.searchlist4.observeField("itemSelected","searchMovieDetail4")
        end if
        m.searchhot.setFocus(true)
        m.search.visible = true
    end if
end sub

sub getFavourites()
    m.loading2.visible = false
    if m.collectDataTask.content.type <> invalid
        return
    end if
    if m.collectDataTask.content = invalid
        m.loadingIndicator.control = "stop"
        m.loadingIndicator.visible = false
        m.loading2.text = "Loading failed, please try again"
        m.loading2.visible = true
        return
    end if
    if m.collectDataTask.content.code <= 0
        m.loadingIndicator.control = "stop"
        m.loadingIndicator.visible = false
        m.loading2.text = m.collectDataTask.content.msg
        m.loading2.visible = true
        return
    end if
    Content = m.collectDataTask.content
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content.data
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if data["box_type"] = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    m.loading2.visible = false
    m.loadingIndicator.control = "stop"
    m.loadingIndicator.visible = false
    m.collects.content = ContentNode
end sub

sub getMovielist()
    if m.movielistDataTask.content.type <> invalid
        return
    end if
    if m.movielistDataTask.content = invalid or m.movielistDataTask.content.code = invalid
        m.loadingIndicator.control = "stop"
        m.loadingIndicator.visible = false
        m.loading2.text = "Loading failed, please try again"
        m.loading2.visible = true
        return
    end if
    if m.movielistDataTask.content.code <= 0
        m.loadingIndicator.control = "stop"
        m.loadingIndicator.visible = false
        m.loading2.text = m.movielistDataTask.content.msg
        m.loading2.visible = true
        return
    end if
    Content = m.movielistDataTask.content
    list2 = []
    for each key2 in Content.data
        if key2.type = "compilations"
            list2.Unshift(key2)
        else
            list2.Push(key2)
        end if
    end for
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in list2
        if key["list"].Count() > 0 and key["type"] <> "actor" and key["type"] <> "collection" and key["type"] <> "collection2" then
            itemContent = ContentNode.createChild("ContentNode")
            itemContent.title = key["name"]
            subItems = key["list"]
            for each subItem in subItems
                subItemContent = itemContent.createChild("ContentNode")
                subItemContent.title = subItem.name
                if key.type = "compilations"
                    subItemContent.id = subItem.id
                    subItemContent.hdposterurl = subItem.cover
                    subItemContent.Description = key.type
                else
                    subItemContent.hdposterurl = subItem.imgArr[0]
                    subItemContent.Description = key.type
                    data = CreateObject("roAssociativeArray")
                    data["lid"] = subItem.lid
                    data["count"] = subItem.count
                    subItemContent.addField("data", "assocarray", false)
                    subItemContent.data = data
                end if
            end for
            if key["ismore"] = 1
                subItemContent = itemContent.createChild("ContentNode")
                subItemContent.title = ""
                subItemContent.hdposterurl = "pkg:/images/more_list.png"
                subItemContent.Description = key.type
                if key.type = "compilations"
                    subItemContent.id = 0
                    subItemContent.title = key.name
                else
                    data = CreateObject("roAssociativeArray")
                    data["lid"] = 0
                    data["type"] = key.type
                    data["name"] = key.name
                    subItemContent.addField("data", "assocarray", false)
                    subItemContent.data = data
                end if
            end if
        end if
    end for
    m.loading2.visible = false
    m.loadingIndicator.control = "stop"
    m.loadingIndicator.visible = false
    m.movielist.jumpToItem = 0
    m.movielist.content = ContentNode
end sub

sub get_toplist(type2)
    if type2 = 2
        m.toplistDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.toplistDataTask2.content = {"type":"toplist","box_type":type2}
        m.toplistDataTask2.observeField("content", "set_toplist2")
        m.toplistDataTask2.control = "RUN"
    else
        m.toplistDataTask = CreateObject("roSGNode", "GetContentReader")
        m.toplistDataTask.content = {"type":"toplist","box_type":type2}
        m.toplistDataTask.observeField("content", "set_toplist")
        m.toplistDataTask.control = "RUN"
    end if
end sub

sub get_filters(type2)
    if type2 = 2
        m.filterlistDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.filterlistDataTask2.content = {"type":"country_list","box_type":type2}
        m.filterlistDataTask2.observeField("content", "filter_list2")
        m.filterlistDataTask2.control = "RUN"
    else
        m.filterlistDataTask = CreateObject("roSGNode", "GetContentReader")
        m.filterlistDataTask.content = {"type":"country_list","box_type":type2}
        m.filterlistDataTask.observeField("content", "filter_list")
        m.filterlistDataTask.control = "RUN"
    end if
end sub

sub filter_list()
    content = m.filterlistDataTask.content
    if content.type <> invalid
        return
    end if
    if content = invalid
        return
    end if

    list = CreateObject("roAssociativeArray")
    list["SORT BY"] = {"add":"Added","rating":"IMDB","tomato_meter":"RottenTomatoes","view":"View"}
    list["MOVIE RATINGS"] = {"G":"G","PG":"PG","PG-13":"PG-13","R":"R","NC-17":"NC-17"}
    list["RESOLUTION"] = {"TC":"TC","HDTV":"HDTV","DVD":"DVD","WEBDL":"WEBDL","BLU-RAY":"BLU-RAY","4K":"4K"}
    list["YEAR"] = {"2024":"2024","2023":"2023","2022":"2022","2021":"2021","2020":"2020","2019":"2019","2018":"2018","2017":"2017","2016":"2016","2010-2015":"2010-2015","2000-2009":"2000-2009","1990-1999":"1990-1999","1980-1989":"1980-1989","1970-1979":"1970-1979","1960-1969":"1960-1969","Before 1960":"Before 1960"}
    list["GENRE"] = {"1":"ACTION","2":"ADVENTURE","3":"ANIMATION","4":"BIOGRAPHY","5":"COMEDY","6":"CRIME","7":"DOCUMENTARY","8":"DRAMA","9":"FAMILY","10":"FANTASY","11":"FILM-NOIR","12":"HISTORY","13":"HORROR","14":"MUSIC","15":"MYSTERY","16":"ROMANCE","17":"SCI-FI","18":"SPORT","19":"THRILLER","20":"WAR","21":"WESTERN","22":"CHRISTMAS","24":"REALITY-TV","45":"NEWS","51":"GAME-SHOW","52":"TALK-SHOW","53":"SHORT"}
    list["COUNTRY"] = content.data.country_list

    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "SORT BY"
    for each key in list["SORT BY"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["SORT BY"][key]
        subItemContent.Description = "SORT BY"
        if key = "add"
            subItemContent.shortdescriptionline1 = "true"
        end if
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "MOVIE RATINGS"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "MOVIE RATINGS"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["MOVIE RATINGS"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["MOVIE RATINGS"][key]
        subItemContent.Description = "MOVIE RATINGS"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "RESOLUTION"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "RESOLUTION"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["RESOLUTION"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["RESOLUTION"][key]
        subItemContent.Description = "RESOLUTION"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "YEAR"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "YEAR"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["YEAR"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["YEAR"][key]
        subItemContent.Description = "YEAR"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "GENRE"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "GENRE"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["GENRE"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["GENRE"][key]
        subItemContent.Description = "GENRE"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "COUNTRY"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "COUNTRY"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["COUNTRY"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = key.country
        subItemContent.Description = "COUNTRY"
        data = CreateObject("roAssociativeArray")
        data["id"] = key.country
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for

    m.movie_filter.content = ContentNode
end sub

sub filter_list2()
    content = m.filterlistDataTask2.content
    if content.type <> invalid
        return
    end if
    if content = invalid
        return
    end if

    list = CreateObject("roAssociativeArray")
    list["SORT BY"] = {"add":"Added","rating":"IMDB","tomato_meter":"RottenTomatoes","view":"View"}
    list["TV RATINGS"] = {"TV-14":"TV-14","TV-MA":"TV-MA","TV-PG":"TV-PG","TV-G":"TV-G","TV-Y7":"TV-Y7","TV-Y":"TV-Y","TV-Y7-FV":"TV-Y7-FV","PG-13":"PG-13","16+":"16+","R":"R","PG":"PG","18+":"18+","G":"G","13+":"13+","Approved":"Approved","TV-13":"TV-13"}
    list["RESOLUTION"] = {"TC":"TC","HDTV":"HDTV","DVD":"DVD","WEBDL":"WEBDL","BLU-RAY":"BLU-RAY","4K":"4K"}
    list["YEAR"] = {"2024":"2024","2023":"2023","2022":"2022","2021":"2021","2020":"2020","2019":"2019","2018":"2018","2017":"2017","2016":"2016","2010-2015":"2010-2015","2000-2009":"2000-2009","1990-1999":"1990-1999","1980-1989":"1980-1989","1970-1979":"1970-1979","1960-1969":"1960-1969","Before 1960":"Before 1960"}
    list["GENRE"] = {"1":"ACTION","2":"ADVENTURE","3":"ANIMATION","4":"BIOGRAPHY","5":"COMEDY","6":"CRIME","7":"DOCUMENTARY","8":"DRAMA","9":"FAMILY","10":"FANTASY","11":"FILM-NOIR","12":"HISTORY","13":"HORROR","14":"MUSIC","15":"MYSTERY","16":"ROMANCE","17":"SCI-FI","18":"SPORT","19":"THRILLER","20":"WAR","21":"WESTERN","22":"CHRISTMAS","24":"REALITY-TV","45":"NEWS","51":"GAME-SHOW","52":"TALK-SHOW","53":"SHORT"}
    list["COUNTRY"] = content.data.country_list

    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "SORT BY"
    for each key in list["SORT BY"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["SORT BY"][key]
        subItemContent.Description = "SORT BY"
        if key = "add"
            subItemContent.shortdescriptionline1 = "true"
        end if
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "TV RATINGS"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "TV RATINGS"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["TV RATINGS"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["TV RATINGS"][key]
        subItemContent.Description = "TV RATINGS"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "RESOLUTION"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "RESOLUTION"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["RESOLUTION"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["RESOLUTION"][key]
        subItemContent.Description = "RESOLUTION"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "YEAR"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "YEAR"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["YEAR"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["YEAR"][key]
        subItemContent.Description = "YEAR"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "GENRE"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "GENRE"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["GENRE"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = list["GENRE"][key]
        subItemContent.Description = "GENRE"
        data = CreateObject("roAssociativeArray")
        data["id"] = key
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = "COUNTRY"
    subItemContent = itemContent.createChild("ContentNode")
    subItemContent.title = "All"
    subItemContent.Description = "COUNTRY"
    subItemContent.shortdescriptionline1 = "true"
    data = CreateObject("roAssociativeArray")
    data["id"] = "all"
    subItemContent.addField("data", "assocarray", false)
    subItemContent.data = data
    for each key in list["COUNTRY"]
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = key.country
        subItemContent.Description = "COUNTRY"
        data = CreateObject("roAssociativeArray")
        data["id"] = key.country
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
    end for

    m.tv_filter.content = ContentNode
end sub

sub show_filter()
    m.filter_bg.visible = true
    m.movie_filter.setFocus(true)
end sub

sub show_filter2()
    m.filter_bg2.visible = true
    m.tv_filter.setFocus(true)
end sub

sub set_filter()
    if m.filters = invalid
        m.filters = {}
    end if
    filter = m.movie_filter.content.getChild(m.movie_filter.rowItemFocused[0]).getChild(m.movie_filter.rowItemFocused[1])
    if filter.Description = "SORT BY"
        m.filters["sort"] = filter.data.id
    end if
    if filter.Description = "MOVIE RATINGS"
        if filter.data.id = "all"
            m.filters.Delete("rating")
        else
            m.filters["rating"] = filter.data.id
        end if
    end if
    if filter.Description = "RESOLUTION"
        if filter.data.id = "all"
            m.filters.Delete("quality")
        else
            m.filters["quality"] = filter.data.id
        end if
    end if
    if filter.Description = "YEAR"
        if filter.data.id = "all"
            m.filters.Delete("year")
        else
            m.filters["year"] = filter.data.id
        end if
    end if
    if filter.Description = "GENRE"
        if filter.data.id = "all"
            m.filters.Delete("genre")
        else
            m.filters["genre"] = filter.data.id
        end if
    end if
    if filter.Description = "COUNTRY"
        if filter.data.id = "all"
            m.filters.Delete("country")
        else
            m.filters["country"] = filter.data.id
        end if
    end if

    if m.filters["sort"] = invalid
        sort = "add"
    else
        sort = m.filters["sort"]
    end if
    if m.filters["rating"] = invalid
        rating = ""
    else
        rating = m.filters["rating"]
    end if
    if m.filters["quality"] = invalid
        quality = ""
    else
        quality = m.filters["quality"]
    end if
    if m.filters["year"] = invalid
        year = ""
    else
        year = m.filters["year"]
    end if
    if m.filters["genre"] = invalid
        genre = 0
    else
        genre = m.filters["genre"]
    end if
    if m.filters["country"] = invalid
        country = ""
    else
        country = m.filters["country"]
    end if

    m.filtermovie = 1
    m.moviefilterDataTask = CreateObject("roSGNode", "GetContentReader")
    m.moviefilterDataTask.content = {"type":"getmovies2","sort":sort,"rating":rating,"quality":quality,"year":year,"cid":genre,"country":country,"page":1}
    m.moviefilterDataTask.observeField("content", "movie_list2")
    m.moviefilterDataTask.control = "RUN"
    m.filtermoviepage = 1
    for i = 0 to m.movie_filter.content.getChild(m.movie_filter.rowItemFocused[0]).getChildCount() - 1
        filter2 = m.movie_filter.content.getChild(m.movie_filter.rowItemFocused[0]).getChild(i)
        if m.movie_filter.rowItemFocused[1] <> i
            filter2.update({"shortdescriptionline1":"false"}, false)
        end if
    end for
    filter.update({"shortdescriptionline1":"true"}, false)
    m.topmovie = invalid
    for i = 0 to m.movie_toplist.content.getChild(0).getChildCount() - 1
        top2 = m.movie_toplist.content.getChild(0).getChild(i)
        top2.update({"Description":""}, false)
    end for
end sub

sub set_filter2()
    if m.filters_tv = invalid
        m.filters_tv = {}
    end if
    filter = m.tv_filter.content.getChild(m.tv_filter.rowItemFocused[0]).getChild(m.tv_filter.rowItemFocused[1])
    if filter.Description = "SORT BY"
        m.filters_tv["sort"] = filter.data.id
    end if
    if filter.Description = "TV RATINGS"
        if filter.data.id = "all"
            m.filters_tv.Delete("rating")
        else
            m.filters_tv["rating"] = filter.data.id
        end if
    end if
    if filter.Description = "RESOLUTION"
        if filter.data.id = "all"
            m.filters_tv.Delete("quality")
        else
            m.filters_tv["quality"] = filter.data.id
        end if
    end if
    if filter.Description = "YEAR"
        if filter.data.id = "all"
            m.filters_tv.Delete("year")
        else
            m.filters_tv["year"] = filter.data.id
        end if
    end if
    if filter.Description = "GENRE"
        if filter.data.id = "all"
            m.filters_tv.Delete("genre")
        else
            m.filters_tv["genre"] = filter.data.id
        end if
    end if
    if filter.Description = "COUNTRY"
        if filter.data.id = "all"
            m.filters_tv.Delete("country")
        else
            m.filters_tv["country"] = filter.data.id
        end if
    end if

    if m.filters_tv["sort"] = invalid
        sort = "add"
    else
        sort = m.filters_tv["sort"]
    end if
    if m.filters_tv["rating"] = invalid
        rating = ""
    else
        rating = m.filters_tv["rating"]
    end if
    if m.filters_tv["quality"] = invalid
        quality = ""
    else
        quality = m.filters_tv["quality"]
    end if
    if m.filters_tv["year"] = invalid
        year = ""
    else
        year = m.filters_tv["year"]
    end if
    if m.filters_tv["genre"] = invalid
        genre = 0
    else
        genre = m.filters_tv["genre"]
    end if
    if m.filters_tv["country"] = invalid
        country = ""
    else
        country = m.filters_tv["country"]
    end if

    m.filtertv = 1
    m.tvfilterDataTask = CreateObject("roSGNode", "GetContentReader")
    m.tvfilterDataTask.content = {"type":"gettvs2","sort":sort,"rating":rating,"quality":quality,"year":year,"cid":genre,"country":country,"page":1}
    m.tvfilterDataTask.observeField("content", "tv_list2")
    m.tvfilterDataTask.control = "RUN"
    m.filtertvpage = 1
    for i = 0 to m.tv_filter.content.getChild(m.tv_filter.rowItemFocused[0]).getChildCount() - 1
        filter2 = m.tv_filter.content.getChild(m.tv_filter.rowItemFocused[0]).getChild(i)
        if m.tv_filter.rowItemFocused[1] <> i
            filter2.update({"shortdescriptionline1":"false"}, false)
        end if
    end for
    filter.update({"shortdescriptionline1":"true"}, false)
    m.toptv = invalid
    for i = 0 to m.tv_toplist.content.getChild(0).getChildCount() - 1
        top2 = m.tv_toplist.content.getChild(0).getChild(i)
        top2.update({"Description":""}, false)
    end for
end sub

function movie_list2()
    Content = m.moviefilterDataTask.content
    if Content.type <> invalid
        return false
    end if
    if Content = invalid or Content.code <= 0
        return false
    end if
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content.data
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.shortdescriptionline1 = key.name
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.quality_tag_new <> invalid
            data["quality_tag_new"] = key.quality_tag_new
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    m.movies.content = ContentNode
end function

function tv_list2()
    Content = m.tvfilterDataTask.content
    if Content.type <> invalid
        return false
    end if
    if Content = invalid or Content.code <= 0
        return false
    end if
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content.data
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.shortdescriptionline1 = key.name
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.season_episode <> invalid
            data["season_episode"] = key.season_episode
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    m.tvs.content = ContentNode
end function

sub filtermovieScroll()
    if m.filtermoviePageStatus = invalid
        m.filtermoviePageStatus = false
    end if
    if m.filtermoviePageStatus = false
        m.filtermoviePageStatus = true
        m.filtermoviepage = m.filtermoviepage + 1

        if m.filters["sort"] = invalid
            sort = "add"
        else
            sort = m.filters["sort"]
        end if
        if m.filters["rating"] = invalid
            rating = ""
        else
            rating = m.filters["rating"]
        end if
        if m.filters["quality"] = invalid
            quality = ""
        else
            quality = m.filters["quality"]
        end if
        if m.filters["year"] = invalid
            year = ""
        else
            year = m.filters["year"]
        end if
        if m.filters["genre"] = invalid
            genre = 0
        else
            genre = m.filters["genre"]
        end if
        if m.filters["country"] = invalid
            country = ""
        else
            country = m.filters["country"]
        end if

        m.filtermovieDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.filtermovieDataTask2.content = {"type":"getmovies2","sort":sort,"rating":rating,"quality":quality,"year":year,"cid":genre,"country":country,"page":m.filtermoviepage}
        m.filtermovieDataTask2.observeField("content", "add_filtermovie")
        m.filtermovieDataTask2.control = "RUN"
    end if
end sub

sub filtertvScroll()
    if m.filtertvPageStatus = invalid
        m.filtertvPageStatus = false
    end if
    if m.filtertvPageStatus = false
        m.filtertvPageStatus = true
        m.filtertvpage = m.filtertvpage + 1

        if m.filters_tv["sort"] = invalid
            sort = "add"
        else
            sort = m.filters_tv["sort"]
        end if
        if m.filters_tv["rating"] = invalid
            rating = ""
        else
            rating = m.filters_tv["rating"]
        end if
        if m.filters_tv["quality"] = invalid
            quality = ""
        else
            quality = m.filters_tv["quality"]
        end if
        if m.filters_tv["year"] = invalid
            year = ""
        else
            year = m.filters_tv["year"]
        end if
        if m.filters_tv["genre"] = invalid
            genre = 0
        else
            genre = m.filters_tv["genre"]
        end if
        if m.filters_tv["country"] = invalid
            country = ""
        else
            country = m.filters_tv["country"]
        end if
        
        m.filtertvDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.filtertvDataTask2.content = {"type":"gettvs2","sort":sort,"rating":rating,"quality":quality,"year":year,"cid":genre,"country":country,"page":m.filtertvpage}
        m.filtertvDataTask2.observeField("content", "add_filtertv")
        m.filtertvDataTask2.control = "RUN"
    end if
end sub

sub add_filtermovie()
    m.filtermoviePageStatus = false
    if m.filtermovieDataTask2.content = invalid or m.filtermovieDataTask2.content.data = invalid
        m.filtermoviepage = m.filtermoviepage - 1
        return
    end if
    if m.filtermovieDataTask2.content.data.Count() > 0
        arr = []
        for each key in m.filtermovieDataTask2.content.data
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
        m.movies.content.appendChildren(arr)
        m.movies.jumpToItem = m.movies.itemFocused + 6
    else
        m.filtermoviepage = m.filtermoviepage - 1
    end if
end sub

sub add_filtertv()
    m.filtertvPageStatus = false
    if m.filtertvDataTask2.content = invalid
        m.filtertvpage = m.filtertvpage - 1
        return
    end if
    if m.filtertvDataTask2.content.data.Count() > 0
        arr = []
        for each key in m.filtertvDataTask2.content.data
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
        m.tvs.content.appendChildren(arr)
        m.tvs.jumpToItem = m.tvs.itemFocused + 6
    else
        m.filtertvpage = m.filtertvpage - 1
    end if
end sub

sub set_toplist()
    content = m.toplistDataTask.content
    if content.type <> invalid
        return
    end if
    if content = invalid
        return
    end if

    color_list = [
        "#8e6dd7ff",
        "#499affff",
        "#7b1879ff",
        "#65d10dff",
        "#fa4f5eff",
        "#64f5e4ff",
        "#f7a003ff",
        "#033ff7ff",
        "#ed2bf7ff",
        "#cfe305ff",
        "#03dce6ff",
        "#2497a4ff",
        "#f75805ff",
        "#e12df7ff",
        "#0768a9ff",
    ]
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = ""
    h = 0
    for each key in content.data
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = key.display_name
        subItemContent.Description = ""
        data = CreateObject("roAssociativeArray")
        data["id"] = key.id
        color = color_list[h]
        data["color"] = color
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
        h = h+1
    end for
    m.movie_toplist.content = ContentNode
end sub

sub set_toplist2()
    content = m.toplistDataTask2.content
    if content.type <> invalid
        return
    end if
    if content = invalid
        return
    end if

    color_list = [
        "#8e6dd7ff",
        "#499affff",
        "#7b1879ff",
        "#65d10dff",
        "#fa4f5eff",
        "#64f5e4ff",
        "#f7a003ff",
        "#033ff7ff",
        "#ed2bf7ff",
        "#cfe305ff",
        "#03dce6ff",
        "#2497a4ff",
        "#f75805ff",
        "#e12df7ff",
        "#0768a9ff",
    ]
    ContentNode = createObject("RoSGNode","ContentNode")
    itemContent = ContentNode.createChild("ContentNode")
    itemContent.title = ""
    h = 0
    for each key in content.data
        subItemContent = itemContent.createChild("ContentNode")
        subItemContent.title = key.display_name
        subItemContent.Description = ""
        data = CreateObject("roAssociativeArray")
        data["id"] = key.id
        color = color_list[h]
        data["color"] = color
        subItemContent.addField("data", "assocarray", false)
        subItemContent.data = data
        h = h+1
    end for
    m.tv_toplist.content = ContentNode
end sub

sub toplist_movie()
    top = m.movie_toplist.content.getChild(0).getChild(m.movie_toplist.rowItemFocused[1])
    if top.Description = "1"
        m.topmovie = invalid
        m.movieDataTask = CreateObject("roSGNode", "movieContentReader")
        m.movieDataTask.observeField("content", "getmovies")
        m.movieDataTask.control = "RUN"
        m.moviesPage = 1
        for i = 0 to m.movie_toplist.content.getChild(0).getChildCount() - 1
            top2 = m.movie_toplist.content.getChild(0).getChild(i)
            top2.update({"Description":""}, false)
        end for
    else
        m.topmovie = top
        m.topmovieDataTask = CreateObject("roSGNode", "GetContentReader")
        m.topmovieDataTask.content = {"type":"toplist_movie","box_type":1,"id":top.data.id,"page":1}
        m.topmovieDataTask.observeField("content", "toplist_con")
        m.topmovieDataTask.control = "RUN"
        m.topmoviepage = 1
        for i = 0 to m.movie_toplist.content.getChild(0).getChildCount() - 1
            top2 = m.movie_toplist.content.getChild(0).getChild(i)
            if m.movie_toplist.rowItemFocused[1] <> i
                top2.update({"Description":"0"}, false)
            end if
        end for
        top.update({"Description":"1"}, false)
    end if
end sub

sub toplist_tv()
    top = m.tv_toplist.content.getChild(0).getChild(m.tv_toplist.rowItemFocused[1])
    if top.Description = "1"
        m.toptv = invalid
        m.tvDataTask = CreateObject("roSGNode", "tvContentReader")
        m.tvDataTask.observeField("content", "gettvs")
        m.tvDataTask.control = "RUN"
        m.tvsPage = 1
        for i = 0 to m.tv_toplist.content.getChild(0).getChildCount() - 1
            top2 = m.tv_toplist.content.getChild(0).getChild(i)
            top2.update({"Description":""}, false)
        end for
    else
        m.toptv = top
        m.toptvDataTask = CreateObject("roSGNode", "GetContentReader")
        m.toptvDataTask.content = {"type":"toplist_movie","box_type":2,"id":top.data.id,"page":1}
        m.toptvDataTask.observeField("content", "toplist_con2")
        m.toptvDataTask.control = "RUN"
        m.toptvpage = 1
        for i = 0 to m.tv_toplist.content.getChild(0).getChildCount() - 1
            top2 = m.tv_toplist.content.getChild(0).getChild(i)
            if m.tv_toplist.rowItemFocused[1] <> i
                top2.update({"Description":"0"}, false)
            end if
        end for
        top.update({"Description":"1"}, false)
    end if
end sub

sub topmovieScroll()
    if m.topmoviePageStatus = invalid
        m.topmoviePageStatus = false
    end if
    if m.topmoviePageStatus = false
        m.topmoviePageStatus = true
        m.topmoviepage = m.topmoviepage + 1
        m.topmovieDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.topmovieDataTask2.content = {"type":"toplist_movie","box_type":1,"id":m.topmovie.data.id,"page":m.topmoviepage}
        m.topmovieDataTask2.observeField("content", "add_topmovie")
        m.topmovieDataTask2.control = "RUN"
    end if
end sub

sub toptvScroll()
    if m.toptvPageStatus = invalid
        m.toptvPageStatus = false
    end if
    if m.toptvPageStatus = false
        m.toptvPageStatus = true
        m.toptvpage = m.toptvpage + 1
        m.toptvDataTask2 = CreateObject("roSGNode", "GetContentReader")
        m.toptvDataTask2.content = {"type":"toplist_movie","box_type":2,"id":m.toptv.data.id,"page":m.toptvpage}
        m.toptvDataTask2.observeField("content", "add_toptv")
        m.toptvDataTask2.control = "RUN"
    end if
end sub

function toplist_con()
    Content = m.topmovieDataTask.content
    if Content.type <> invalid
        return false
    end if
    if Content = invalid or Content.code <= 0
        return false
    end if
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content.data
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.shortdescriptionline1 = key.name
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.quality_tag_new <> invalid
            data["quality_tag_new"] = key.quality_tag_new
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    m.movies.content = ContentNode
end function

function toplist_con2()
    Content = m.toptvDataTask.content
    if Content.type <> invalid
        return false
    end if
    if Content = invalid or Content.code <= 0
        return false
    end if
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content.data
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.shortdescriptionline1 = key.name
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.season_episode <> invalid
            data["season_episode"] = key.season_episode
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    m.tvs.content = ContentNode
end function

sub add_topmovie()
    m.topmoviePageStatus = false
    if m.topmovieDataTask2.content = invalid
        m.topmoviepage = m.topmoviepage - 1
        return
    end if
    if m.topmovieDataTask2.content.data.Count() > 0
        arr = []
        for each key in m.topmovieDataTask2.content.data
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
        m.movies.content.appendChildren(arr)
        m.movies.jumpToItem = m.movies.itemFocused + 6
    else
        m.topmoviepage = m.topmoviepage - 1
    end if
end sub

sub add_toptv()
    m.toptvPageStatus = false
    if m.toptvDataTask2.content = invalid
        m.toptvpage = m.toptvpage - 1
        return
    end if
    if m.toptvDataTask2.content.data.Count() > 0
        arr = []
        for each key in m.toptvDataTask2.content.data
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
        m.tvs.content.appendChildren(arr)
        m.tvs.jumpToItem = m.tvs.itemFocused + 6
    else
        m.toptvpage = m.toptvpage - 1
    end if
end sub

' 获取并处理外挂字幕
function getSrt(srtText as string, index as integer)
    m.srtMap = []
    if srtText <> invalid
        srtItem = createSrtArr(srtText)
        m.srtMap[index] = srtItem
    end if
end function

'将 srt 文本转化为字幕数组
function createSrtArr(srt as string) as Object
    ' arr = srt.Split(chr(10)+chr(10))
    reg = CreateObject("roRegex", "\n\n|\r\r|\r\n\r\n", "")
    arr = reg.Split(srt)
    if arr.Count() < 2
        arr = srt.Split(chr(10)+chr(13)+chr(10))
        if arr.Count() < 2
            arr = {}
        end if
    end if
    result = []
    r = CreateObject("roRegex", "<font[^>]*>", "i")

    for each item in arr
        srtObj = {}
        item = item.Trim()
        containArr = item.Split(chr(10))

        if containArr[1] <> invalid
            containArr[1] = containArr[1].Trim()
            reg = CreateObject("roRegex", "^(\d{1,2}):(\d{2}):(\d{2})[\.,](\d{1,3}) --\> (\d{1,2}):(\d{2}):(\d{2})[\.,](\d{1,3})", "g")
            regResult = reg.Match(containArr[1])
            if regResult.Count() = 0
                regResult = reg.Match(containArr[2])
                containArr.shift()
            end if
            
            if regResult <> invalid and regResult.Count() > 0
                timeSplit = regResult[0].Split(" --> ")
                srtObj.from = GetSeconds(timeSplit[0])
                srtObj.to = GetSeconds(timeSplit[1])
                srtObj.Text = containArr.Slice(2).Join(chr(10))
                srtObj.Text = r.ReplaceAll(srtObj.Text, "")
                srtObj.Text = srtObj.Text.Replace("</font>", "")
                ' print srtObj
                result.Push(srtObj)
            end if
        end if
    end for

    return result
end function

' 将时间转化为秒数
function GetSeconds(val as string) as Float
    reg = CreateObject("roRegex", "\,|\.", "")
    arr = reg.Split(val)
    sec = 0
    a = arr[0].Split(":")
    sec = a[0].ToInt() * 60 * 60 + a[1].ToInt() * 60 + a[2].ToInt() + arr[1].ToFloat() / 1000
    return sec
end function

' 获取当前时间对应的字幕内容
function getSubtitle(currentTime as Float, arr as Object) as string
    if arr.Count() = 0 or arr.Count() = 1
        ' print arr
        htmlText = ""
        return htmlText
    end if
    low = 0
    high = arr.Count()
    mid = 0
    htmlText = ""

    while low <= high
        mid = Int((low + high) / 2)
        if arr[mid] <> invalid
            if arr[mid].from <= currentTime and arr[mid].to >= currentTime
                htmlText = arr[mid].Text
                exit while
            end if
            if arr[mid].from > currentTime
                high = mid - 1
            end if
            if arr[mid].to < currentTime
                low = mid + 1
            end if
        else
            exit while
        end if
    end while

    return htmlText
end function

function getsrtContent(url as string)
    m.readContentTask = createObject("RoSGNode","ReadsrtFile")
    m.readContentTask.content = url
    m.readContentTask.observeField("content", "getSrt2")
    m.readContentTask.control = "RUN"
end function

function getSrt2()
    srt = m.readContentTask.content
    getSrt(srt,1)
    m.subbg = m.top.FindNode("subbg")
    m.subtext = m.top.FindNode("subtext")
    m.textshadow = m.top.FindNode("textshadow")
end function

function srtSet()
    srt = m.videoset.srt_con
    getSrt(srt,1)
    m.srt_btn2.visible = true
    m.subbg = m.top.FindNode("subbg")
    m.subtext = m.top.FindNode("subtext")
    m.textshadow = m.top.FindNode("textshadow")
end function

function onPositionChanged(event as object)
    newPosition = event.getData()
    if m.video.duration > 0 and m.skip_end > 0 and m.close_skiptip = 0 and m.skiptip_end.visible = false
        if m.video.duration - newPosition <= m.skip_end
            m.skip_text2.text = "Skip Ending "+m.skip_end.ToStr()+"S,"
            m.skiptip_end.visible = true
        end if
    end if
    if m.srtMap <> invalid and m.srtMap.Count() > 0
        if m.srt_delay <> invalid and (Type(m.srt_delay) = "roInt" or Type(m.srt_delay) = "roInteger")
            newPosition = newPosition + m.srt_delay
        end if
        text = getSubtitle(newPosition+1,m.srtMap[1])
        ' print text
        text = text.Replace("<i>", "")
        text = text.Replace("</i>", "")
        if text = ""
            m.subbg.visible = false
        else
            m.subbg.visible = true
            m.subtext.text = text
            m.textshadow.text = text
        end if
    end if
end function

sub srtselected()
    for i = 0 to m.subtitles.content.getChildCount() - 1
        tt = m.subtitles.content.getChild(i)
        if tt.SecondaryTitle = "true"
            tt.update({"SecondaryTitle":"false"}, false)
        end if
    end for
    info = m.subtitles.content.getChild(m.subtitles.itemSelected)
    info.update({"SecondaryTitle":"true"}, false)
    sid = info.id
    if m.videoinfo.subtitle_list.select = invalid
      m.videoinfo.subtitle_list["select"] = {"sid":sid.ToInt()}
    else
      m.videoinfo.subtitle_list.select.sid = sid.ToInt()
    end if
    m.videoset.content = m.videoinfo
    ' srt = info.Description.Replace(" ", "%20")
    m.videoset.visible = false
    if m.video_play <> invalid
        m.video_play.setFocus(true)
    else
        m.top.setFocus(true)
    end if
    m.srt_delay = info.data["delay"]
    m.current_srt = sid
    getsrtContent(info.Description)
    m.srt_time.text = m.srt_delay.ToStr() + " S"
    m.srt_btn2.visible = true
    subtitle_select(sid)
end sub

sub subtitle_select(sid)
    if m.shuffle = 1
        arr = ParseJson(m.moviedata3)
    else
        if m.detail <> invalid
            arr = ParseJson(m.detail.movieid)
        else
            arr = ParseJson(m.moviedata3)
        end if
    end if
    arr["sid"] = sid
    arr["type"] = "sub_select"
    
    m.selectContentTask = createObject("RoSGNode","GetContentReader")
    m.selectContentTask.content = arr
    m.selectContentTask.control = "RUN"
end sub

sub close_subtitle()
    index = m.subtitle_btns.itemSelected
    if index = 3
        if m.subtitles.content <> invalid
            for i = 0 to m.subtitles.content.getChildCount() - 1
                tt = m.subtitles.content.getChild(i)
                if tt.SecondaryTitle = "true"
                    tt.update({"SecondaryTitle":"false"}, false)
                end if
            end for
        end if
        m.current_srt = invalid
        m.srt_btn2.visible = false
        m.subbg.visible = false
        m.srtMap = invalid
        m.sub_settingbg.visible = false
        m.videoset.visible = false
        m.settingbg.visible = true
        sid = m.videoinfo.subtitle_list.select.sid
        if m.videoinfo.subtitle_list.select.sid <> invalid
            m.videoinfo.subtitle_list.select.sid = 0
            m.videoset.content = m.videoinfo
        end if
        m.typelist.SetFocus(true)

        arr = m.videoinfo.moviedata
        arr["sid"] = sid
        arr["type"] = "sub_select_del"
        
        m.selectContentTask2 = createObject("RoSGNode","GetContentReader")
        m.selectContentTask2.content = arr
        m.selectContentTask2.control = "RUN"
    end if
end sub

sub srt_delay()
    index = m.subtitle_delay.itemSelected
    if m.srt_delay = invalid
        m.srt_delay = 0
    end if
    if index = 0
        m.srt_delay = m.srt_delay - 1
    else
        m.srt_delay = m.srt_delay + 1
    end if
    m.srt_time.text = m.srt_delay.ToStr() + " S"

    if m.srttimer <> invalid
        m.srttimer.control = "stop"
    end if
    m.srttimer = CreateObject("roSGNode", "Timer")
    m.srttimer.duration = 2
    m.srttimer.control = "start"
    m.srttimer.ObserveField("fire","subtitle_delay")
end sub

sub subtitle_delay()
    if m.shuffle = 1
        arr = ParseJson(m.moviedata3)
    else
        if m.detail <> invalid
            arr = ParseJson(m.detail.movieid)
        else
            arr = ParseJson(m.moviedata3)
        end if
    end if
    arr["sid"] = m.current_srt
    arr["delay"] = m.srt_delay
    arr["type"] = "subtitle_delay"
    
    m.delayContentTask = createObject("RoSGNode","GetContentReader")
    m.delayContentTask.content = arr
    m.delayContentTask.control = "RUN"
end sub

sub srt_size2()
    index = m.subtitle_size.itemSelected
    if m.srt_size = invalid
        m.srt_size = 28
    end if
    if index = 0
        m.srt_size = m.srt_size - 1
    else
        m.srt_size = m.srt_size + 1
    end if
    m.srt_sizetxt.text = m.srt_size.ToStr()
    m.fontshadow.size = m.srt_size
    m.subfont.size = m.srt_size
    user = CreateObject("roRegistrySection", "User")
    user.Write("srt_size", m.srt_size.ToStr())
end sub

sub srt_move()
    index = m.subtitle_move.itemSelected
    if m.srt_position = invalid
        m.srt_position = 570
    end if
    if index = 0
        m.srt_position = m.srt_position - 8
    else
        m.srt_position = m.srt_position + 8
    end if
    if m.srt_position < 690 and m.srt_position >= 0
        m.subbg.translation = [340,m.srt_position]
        user = CreateObject("roRegistrySection", "User")
        user.Write("srt_position", m.srt_position.ToStr())
    else
        if m.srt_position < 0
            m.srt_position = 0
        else
            m.srt_position = 690
        end if
    end if
end sub

sub home_play()
    arr = m.getdetailContentTask.content
    if arr = invalid
        return
    end if
    if arr.type <> invalid
        return
    end if
    if arr.code <= 0
        return
    end if
    if arr.data.box_type = 2
        m.elist = arr.data.episode
        data = ParseJson(m.moviedata)
        if arr.data.history <> invalid
            for each item in arr.data.episode
                if arr.data.history.episode = item.episode
                    data["imdb_id"] = item.imdb_id
                    exit for
                end if
            end for
            data["season"] = arr.data.history.season
            data["episode"] = arr.data.history.episode
            if arr.data.history.seconds <> invalid
                data["seconds"] = arr.data.history.seconds
            end if
        else
            data["imdb_id"] = arr.data.episode[0].imdb_id
            data["season"] = arr.data.episode[0].season
            data["episode"] = arr.data.episode[0].episode
        end if
        if arr.data.season <> invalid
            data["season_list"] = arr.data.season
        end if
        if arr.data.max_season <> invalid
            data["max_season"] = arr.data.max_season
        end if
        m.moviedata = FormatJson(data)
    else
        data = ParseJson(m.moviedata)
        data["imdb_id"] = arr.data.imdb_id
        if arr.data.plan_watched <> invalid
            data["plan_watched"] = arr.data.plan_watched
        end if
        if arr.data.seconds <> invalid
            data["seconds"] = arr.data.seconds
        end if
        m.moviedata = FormatJson(data)
    end if
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
    m.top.removeChild(m.preparation)
    m.preparation = invalid
    startVideoContentReader(m, m.moviedata)
end sub

sub setplaydata()
    if isStaleVideoPlayRequest(m)
        return
    end if
    finishVideoContentRequest(m)
    if m.loading = invalid and m.video_play = invalid
        return
    end if
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
    m.videoinfo = m.readVideoContentTask.videoinfo
    if m.videoinfo = invalid
        if m.video <> invalid
            m.video.control = "stop"
        end if
        if m.listbtn <> invalid
            m.listbtn.setFocus(true)
        end if
        if m.rowlist <> invalid
            m.rowlist.setFocus(true)
        end if
        m.error_msg.text = "Playback failed, please try again"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if m.videoinfo.code <> invalid and m.videoinfo.code <= 0
        if m.video <> invalid
            m.video.control = "stop"
        end if
        if m.listbtn <> invalid
            m.listbtn.setFocus(true)
        end if
        if m.rowlist <> invalid
            m.rowlist.setFocus(true)
        end if
        m.error_msg.text = m.videoinfo.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    m.videoinfo["content"] = m.readVideoContentTask.videocontent
    if m.video_play <> invalid
        m.video.control = "stop"
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        m.video_play.content = m.videoinfo
        m.video_play.visible = true
        if m.video <> invalid
            m.video.visible = true
        end if
    else
        m.videoinfo.replay = m.replay
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        video_play = createObject("roSGNode", "videoPlay")
        video_play.content = m.videoinfo
        video_play.id = "video_play"
        m.top.appendChild(video_play)
        m.video_play = m.top.findNode("video_play")
        m.video_play.observeField("next_episode", "autonext")
        m.video_play.observeField("play_episode", "onPlayEpisodeSelected")
        m.video = m.video_play.findNode("my_video")
        m.video.observeField("state", "controlvideoplay")
        m.video_play.setFocus(true)
    end if

    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 300
    m.timer.repeat = true
    m.timer.control = "start"
    m.timer.ObserveField("fire","progressSave")
end sub

sub progressSave()
    runtime = m.video.duration
    seconds = m.video.position
    video = m.videoinfo.list[0]
    arr = ParseJson(m.moviedata)
    
    if arr.box_type = 2
        arr["mp4_id"] = video.tmfid
    else
        arr["mp4_id"] = video.mmfid
    end if
    arr["seconds"] = Int(seconds)
    if runtime - seconds < 300
        arr["over"] = 1
    else
        arr["over"] = 0
    end if
    persistPlayProgress(m, arr.seconds, arr.over)
    arr["type"] = "progress_save"

    m.saveContentTask = createObject("RoSGNode","GetContentReader")
    m.saveContentTask.content = arr
    m.saveContentTask.observeField("content", "refresh_home")
    m.saveContentTask.control = "RUN"
end sub

sub refresh_home()
    ' m.readerTask = CreateObject("roSGNode", "ContentReader")
    ' m.readerTask.observeField("content", "gotContent")
    ' m.readerTask.control = "RUN"
    ' m.rowlist.jumpToItem = 0
end sub

sub controlvideoplay()
    if m.video.state = "error"
        m.error = 1
    end if
    if m.video.state = "playing"
        m.error = 0
    end if
    if m.video.state = "finished" and m.error = 0 and isNaturalPlaybackFinish(m.video)
        m.timer.control = "stop"
        progressSave()
        arr = ParseJson(m.moviedata)
        if arr.box_type = 2
            e_list = m.elist
            next2 = 0
            for each item in e_list
                if item.episode > arr.episode
                    arr.imdb_id = item.imdb_id
                    arr.episode = item.episode
                    if item.play_progress.over = 1
                        arr.seconds = 0
                    else
                        arr.seconds = item.play_progress.seconds
                    end if
                    next2 = 1
                    exit for
                end if
            end for
            if next2 = 1
                m.moviedata = FormatJson(arr)
                startVideoContentReader(m, m.moviedata)
            else
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.rowlist.setFocus(true)
            end if
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.rowlist.setFocus(true)
        end if
    end if
end sub

sub autonext()
    m.timer.control = "stop"
    progressSave()
    arr = ParseJson(m.moviedata)
    if arr.box_type = 2
        e_list = m.elist
        next2 = 0
        for each item in e_list
            if item.episode > arr.episode
                arr.imdb_id = item.imdb_id
                arr.episode = item.episode
                if item.play_progress.over = 1
                    arr.seconds = 0
                else
                    arr.seconds = item.play_progress.seconds
                end if
                next2 = 1
                exit for
            end if
        end for
        if next2 = 1
            m.moviedata = FormatJson(arr)
            startVideoContentReader(m, m.moviedata)
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.rowlist.setFocus(true)
        end if
    end if
end sub

sub prepareoperates()
    index = m.prepare_btns.itemSelected
    if index = 0 or index = 1
        aa = m.preparation.arr
        data = aa
        data["type"] = "movie_detail"
        if index = 0
            m.replay = 0
        else
            m.replay = 1
        end if
        m.getdetailContentTask = createObject("RoSGNode","GetContentReader")
        m.getdetailContentTask.content = data
        m.getdetailContentTask.observeField("content", "home_play")
        m.getdetailContentTask.control = "RUN"
    elseif index = 2
        aa = m.preparation.arr
        m.moviedata = FormatJson(aa)
        movie_detail(m.moviedata)
        m.top.removeChild(m.preparation)
        m.preparation = invalid
    elseif index = 3
        aa = m.preparation.arr
        data = aa
        data["type"] = "watch_plan_del"
        m.removeContentTask = createObject("RoSGNode","GetContentReader")
        m.removeContentTask.content = data
        m.removeContentTask.control = "RUN"
        m.rowlist.content.getChild(m.rowlist.rowItemFocused[0]).removeChildIndex(m.rowlist.rowItemFocused[1])
        m.rowlist.setFocus(true)
        m.top.removeChild(m.preparation)
        m.preparation = invalid
    end if
end sub

sub movie_detail(data)
    m.home.visible = false
    m.top.removeChild(m.detail)
    detail = createObject("roSGNode", "DetailScreen")
    detail.movieid = data
    detail.id = "moviedetail"
    m.top.appendChild(detail)
    m.detail = m.top.findNode("moviedetail")
    m.operates = m.detail.findNode("operates")
    m.operates.setFocus(true)
end sub

sub hidemsg()
    m.error_tip.visible = false
end sub

sub listdetail()
    if m.movielist.rowItemSelected[0] = 0
        list = m.movielist.content.getChild(m.movielist.rowItemSelected[0]).getChild(m.movielist.rowItemSelected[1])
        if list.id = "0"
            festival_list = createObject("roSGNode", "FestivalList")
            festival_list.arr = {"type":list.Description,"name":list.title}
            festival_list.id = "festival_list"
            m.home.visible = false
            m.top.appendChild(festival_list)
            m.festival_list = m.top.findNode("festival_list")
            return
        end if
        data = {"id":list.id,"name":list.title,"type":"film_festival"}
        movielists = createObject("roSGNode", "MovieList2")
        movielists.arr = data
        movielists.id = "movielists2"
        m.home.visible = false
        m.top.appendChild(movielists)
        m.movielists2 = m.top.findNode("movielists2")
    else
        list = m.movielist.content.getChild(m.movielist.rowItemSelected[0]).getChild(m.movielist.rowItemSelected[1])
        if list.data.lid = 0
            movielist_type = createObject("roSGNode", "HotLists")
            movielist_type.arr = list.data
            movielist_type.id = "movielist_type"
            m.home.visible = false
            m.top.appendChild(movielist_type)
            m.movielist_type = m.top.findNode("movielist_type")
            return
        end if
        data = {"id":list.data.lid}
        list_detail = createObject("roSGNode", "PlayList2")
        list_detail.arr = data
        list_detail.id = "list_detail"
        m.home.visible = false
        m.top.appendChild(list_detail)
        m.list_detail_status = 1
        m.list_detail = m.top.findNode("list_detail")
    end if
end sub

sub moviesScroll()
    if m.moviePageStatus = invalid
        m.moviePageStatus = false
    end if
    if m.moviePageStatus = false
        m.moviePageStatus = true
        m.moviesPage = m.moviesPage + 1
        m.movieDataTask = CreateObject("roSGNode", "movieContentReader")
        m.movieDataTask.page = m.moviesPage.ToStr()
        m.movieDataTask.observeField("content", "addmovies")
        m.movieDataTask.control = "RUN"
    end if
end sub

sub addmovies()
    ' print m.movies.itemFocused
    m.moviePageStatus = false
    if m.movieDataTask.content = invalid
        m.moviesPage = m.moviesPage - 1
        return
    end if
    if m.movieDataTask.content.getChildCount() > 0
        arr = []
        for i = 0 to m.movieDataTask.content.getChildCount() - 1
            arr.Push(m.movieDataTask.content.getChild(i))
        end for
        m.movies.content.appendChildren(arr)
        m.movies.jumpToItem = m.movies.itemFocused + 6
    else
        m.moviesPage = m.moviesPage - 1
    end if
end sub

sub tvsScroll()
    if m.tvPageStatus = invalid
        m.tvPageStatus = false
    end if
    if m.tvPageStatus = false
        m.tvPageStatus = true
        m.tvsPage = m.tvsPage + 1
        m.tvDataTask = CreateObject("roSGNode", "tvContentReader")
        m.tvDataTask.page = m.tvsPage.ToStr()
        m.tvDataTask.observeField("content", "addtvs")
        m.tvDataTask.control = "RUN"
    end if
end sub

sub addtvs()
    ' print m.tvs.itemFocused
    m.tvPageStatus = false
    if m.tvDataTask.content = invalid
        m.tvsPage = m.tvsPage - 1
        return
    end if
    if m.tvDataTask.content.getChildCount() > 0
        arr = []
        for i = 0 to m.tvDataTask.content.getChildCount() - 1
            arr.Push(m.tvDataTask.content.getChild(i))
        end for
        m.tvs.content.appendChildren(arr)
        m.tvs.jumpToItem = m.tvs.itemFocused + 6
    else
        m.tvsPage = m.tvsPage - 1
    end if
end sub

sub collectsScroll()
    if m.collectPageStatus = invalid
        m.collectPageStatus = false
    end if
    if m.collectPageStatus = false
        m.collectPageStatus = true
        m.collectsPage = m.collectsPage + 1
        m.collectDataTask = CreateObject("roSGNode", "GetContentReader")
        m.collectDataTask.content = {"page":m.collectsPage,"type":"collect"}
        m.collectDataTask.observeField("content", "addcollects")
        m.collectDataTask.control = "RUN"
    end if
end sub

sub addcollects()
    m.collectPageStatus = false
    if m.collectDataTask.content = invalid
        m.collectsPage = m.collectsPage - 1
        return
    end if
    if m.collectDataTask.content.data.Count() > 0
        arr = []
        for each key in m.collectDataTask.content.data
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if data["box_type"] = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag_new <> invalid
                    data["quality_tag_new"] = key.quality_tag_new
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
        m.collects.content.appendChildren(arr)
        m.collects.jumpToItem = m.collects.itemFocused + 6
    else
        m.collectsPage = m.collectsPage - 1
    end if
end sub

sub accountInfo()
    m.accountinfo = CreateObject("roSGNode", "Account")
    m.accountinfo.id = "accountInfo"
    m.home.visible = false
    m.top.appendChild(m.accountinfo)
    m.accountbtns = m.accountinfo.findNode("btns")
    ' m.accountbtns.observeField("itemSelected","gethistory")
    m.accountbtns.jumpToItem = 2
    m.accountbtns.setFocus(true)
    m.accountinfo.observeField("new_uid","switch_account")
end sub

function switch_account()
    m.top.removeChild(m.accountinfo)
    m.accountinfo = invalid
    m.home.visible = true
    m.rowlist.content = invalid
    m.movies.content = invalid
    m.movie_toplist.content = invalid
    m.tvs.content = invalid
    m.tv_toplist.content = invalid
    m.movielist.content = invalid
    m.collects.content = invalid

    user = CreateObject("roRegistrySection", "User")
    m.avatar2.uri = user.Read("avatar")
    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = user.Read("username")
    child2.hdposterurl = user.Read("avatar")
    m.account.content = contentRoot2
    
    m.account.drawFocusFeedback = false
    m.moviemenu.drawFocusFeedback = true
    m.moviemenu.setFocus(true)
end function

function ConvertSecondsToHMS(seconds as Integer) as Object
    hours = Int(seconds \ 3600)
    minutes = Int((seconds - (hours * 3600)) / 60)
    seconds = seconds - (hours * 3600) - (minutes * 60)
    
    if hours >= 1
        timeString = hours.ToStr() + ":" + PadZero(minutes) + ":" + PadZero(seconds)
    elseif minutes >= 1
        timeString = PadZero(minutes) + ":" + PadZero(seconds)
    else
        timeString = "00:" + PadZero(seconds)
    end if
    
    return timeString
end function

' 辅助函数：将单个数字转换为两位字符，不足两位补零
function PadZero(number as Integer) as String
    if number < 10 then
        return "0"+number.ToStr()
    else
        return number.ToStr()
    end if
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
    ' 按下键盘按键时触发该事件
    if press then
        if key = "left" then
            ' 如果按下左箭头键，则将焦点设置到侧边栏
            if m.video_play <> invalid
                return true
            end if
            if m.preparation <> invalid and m.preparation.visible = true
                return true
            end if
            if m.filter_bg.visible = true or m.filter_bg2.visible = true
                return true
            end if
            if m.home.visible = true
                m.sidebar_icon.visible = false
                m.sidebar.visible = true
                m.contents.translation = [260, 0]
                m.account.drawFocusFeedback = false
                m.moviemenu.drawFocusFeedback = true
                m.moviemenu.setFocus(true)
            end if
            return true
        else if key = "right" then
            ' 如果按下右箭头键，则将焦点设置到内容
            if m.video_play <> invalid
                return true
            end if
            if m.filter_bg.visible = true or m.filter_bg2.visible = true
                return true
            end if
            if m.preparation <> invalid and m.preparation.visible = true
                return true
            end if
            if m.home.visible = true
                m.sidebar.visible = false
                m.sidebar_icon.visible = true
                m.contents.translation = [120, 0]
                if m.rowlist.visible = true
                    m.rowlist.setFocus(true)
                end if
                if m.movies_con.visible = true
                    m.movies.setFocus(true)
                end if
                if m.tvs_con.visible = true
                    m.tvs.setFocus(true)
                end if
                if m.collects.visible = true
                    m.collects.setFocus(true)
                end if
                if m.movielist.visible = true
                    m.movielist.setFocus(true)
                end if
            end if
            return true
        else if key = "down" then
            if m.account.hasFocus() = true
                m.moviemenu.drawFocusFeedback = true
                m.account.drawFocusFeedback = false
                m.moviemenu.setFocus(true)
                return true
            end if
            if m.moviemenu.hasFocus() = true
                m.moviemenu.drawFocusFeedback = false
                m.icon_btns.setFocus(true)
                return true
            end if
            if m.filterbtn.hasFocus() = true
                m.movie_toplist.setFocus(true)
                return true
            end if
            if m.movie_toplist.hasFocus() = true
                m.movies.setFocus(true)
                return true
            end if
            if m.filterbtn2.hasFocus() = true
                m.tv_toplist.setFocus(true)
                return true
            end if
            if m.tv_toplist.hasFocus() = true
                m.tvs.setFocus(true)
                return true
            end if
            if m.movies_con.visible = true and m.movies.hasFocus() = true
                if m.topmovie <> invalid
                    topmovieScroll()
                elseif m.filtermovie <> invalid
                    filtermovieScroll()
                else
                    moviesScroll()
                end if
            end if
            if m.tvs_con.visible = true and m.tvs.hasFocus() = true
                if m.toptv <> invalid
                    toptvScroll()
                elseif m.filtertv <> invalid
                    filtertvScroll()
                else
                    tvsScroll()
                end if
            end if
            if m.collects.visible = true and m.collects.hasFocus() = true
                collectsScroll()
            end if
        else if key = "up" then
            if m.moviemenu.hasFocus() = true
                m.account.drawFocusFeedback = true
                m.moviemenu.drawFocusFeedback = false
                m.account.setFocus(true)
            end if
            if m.icon_btns.hasFocus() = true
                m.moviemenu.drawFocusFeedback = true
                m.moviemenu.setFocus(true)
            end if
            if m.movie_toplist.hasFocus() = true
                m.filterbtn.setFocus(true)
            end if
            if m.movies.hasFocus() = true
                m.movie_toplist.setFocus(true)
            end if
            if m.tv_toplist.hasFocus() = true
                m.filterbtn2.setFocus(true)
            end if
            if m.tvs.hasFocus() = true
                m.tv_toplist.setFocus(true)
            end if
            return true
        end if
        
        if key = "back"
            if m.accountinfo <> invalid and m.accountinfo.visible = true
                m.home.visible = true
                m.top.removeChild(m.accountinfo)
                m.accountinfo = invalid
                applyChildModeMenuRefresh()
                m.account.setFocus(true)
                return true
            end if
            if m.search <> invalid and m.search.visible = true
                m.search.visible = false
                m.home.visible = true
                m.icon_btns.setFocus(true)
                return true
            end if
            if m.preparation <> invalid and m.preparation.visible = true
                m.top.removeChild(m.preparation)
                m.preparation = invalid
                m.rowlist.setFocus(true)
                return true
            end if
            if m.video_play <> invalid and m.video_play.visible = true
                m.timer.control = "stop"
                progressSave()
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.rowlist.setFocus(true)
                return true
            end if
            if m.detail <> invalid and m.detail.visible = true
                m.top.removeChild(m.detail)
                m.detail = invalid
                m.home.visible = true
                if m.rowlist.visible = true
                    m.rowlist.setFocus(true)
                elseif m.movies_con.visible = true
                    m.movies.setFocus(true)
                elseif m.tvs_con.visible = true
                    m.tvs.setFocus(true)
                elseif m.collects.visible = true
                    m.collects.setFocus(true)
                else
                    m.moviemenu.setFocus(true)
                end if
                return true
            end if
            if m.loading <> invalid
                m.loading.visible = false
                m.top.removeChild(m.loading)
                m.loading = invalid
                return true
            end if
            if m.list_detail <> invalid and m.list_detail.visible = true
                m.top.removeChild(m.list_detail)
                m.list_detail = invalid
                m.home.visible = true
                m.movielist.setFocus(true)
                return true
            end if
            if m.filter_bg.visible = true
                m.filter_bg.visible = false
                m.filterbtn.setFocus(true)
                return true
            end if
            if m.filter_bg2.visible = true
                m.filter_bg2.visible = false
                m.filterbtn2.setFocus(true)
                return true
            end if
            if m.home_type <> invalid and m.home_type.visible = true
                m.top.removeChild(m.home_type)
                m.home_type = invalid
                m.home.visible = true
                m.rowlist.setFocus(true)
                return true
            end if
            if m.watch_plans <> invalid and m.watch_plans.visible = true
                m.top.removeChild(m.watch_plans)
                m.watch_plans = invalid
                m.home.visible = true
                if m.watch_plan_more = 1
                    m.rowlist.setFocus(true)
                else
                    m.icon_btns.setFocus(true)
                end if
                return true
            end if
            if m.movielists2 <> invalid and m.movielists2.visible = true
                m.top.removeChild(m.movielists2)
                m.movielists2 = invalid
                m.home.visible = true
                m.movielist.setFocus(true)
                return true
            end if
            if m.movielist_type <> invalid and m.movielist_type.visible = true
                m.top.removeChild(m.movielist_type)
                m.movielist_type = invalid
                m.home.visible = true
                m.movielist.setFocus(true)
                return true
            end if
            if m.festival_list <> invalid and m.festival_list.visible = true
                m.top.removeChild(m.festival_list)
                m.festival_list = invalid
                m.home.visible = true
                m.movielist.setFocus(true)
                return true
            end if
        end if
    end if
    return false
end function