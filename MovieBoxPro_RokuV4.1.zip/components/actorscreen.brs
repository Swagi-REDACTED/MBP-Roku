sub init()
    m.actor_page = m.top.findNode("actor_page")
    m.actor_name = m.top.findNode("actor_name")
    m.actor_job = m.top.findNode("actor_job")
    m.avatar = m.top.findNode("avatar")
    m.avatar_initials = m.top.findNode("avatar_initials")
    m.movies_title = m.top.findNode("movies_title")
    m.movies_list = m.top.findNode("movies_list")
    m.tv_title = m.top.findNode("tv_title")
    m.tv_list = m.top.findNode("tv_list")
    m.actor_error = m.top.findNode("actor_error")
    m.actor_error_msg = m.top.findNode("actor_error_msg")
    m.actorScrollAnimation = m.top.findNode("actorScrollAnimation")
    m.actorScrollInterp = m.top.findNode("actorScrollInterp")

    m.movies_list.observeField("rowItemSelected", "onWorkSelected")
    m.tv_list.observeField("rowItemSelected", "onWorkSelected")
    m.movies_list.observeField("itemFocused", "onMoviesFocused")
    m.tv_list.observeField("itemFocused", "onTvFocused")

    m.section_title_y = 170
    m.section_title_h = 34
    m.title_list_gap = 16
    m.section_gap = 24
    m.list_row_h = 260
    m.page_scroll_y = 0

    m.greenPalette = createObject("roSGNode", "RSGPalette")
    m.greenPalette.colors = { DialogBackgroundColor: "0x202020FF" }
    m.actor_error.palette = m.greenPalette
end sub

sub loadActor()
    if m.top.actorId = invalid or m.top.actorId = ""
        return
    end if
    m.readerTask = createObject("roSGNode", "actorDetailReader")
    m.readerTask.content = {"actor_id": m.top.actorId, "lang": m.top.lang}
    m.readerTask.observeField("content", "onActorLoaded")
    m.readerTask.control = "RUN"
end sub

sub layoutActorSections(hasMovies as Boolean, hasTv as Boolean)
    listY = m.section_title_y + m.section_title_h + m.title_list_gap

    if hasMovies = true
        m.movies_title.translation = [60, m.section_title_y]
        m.movies_list.translation = [40, listY]
    end if

    if hasTv = true
        if hasMovies = true
            tvTitleY = listY + m.list_row_h + m.section_gap
            m.tv_title.translation = [60, tvTitleY]
            m.tv_list.translation = [40, tvTitleY + m.section_title_h + m.title_list_gap]
            tvBottom = tvTitleY + m.section_title_h + m.title_list_gap + m.list_row_h
            scrollY = tvBottom - 720 + 24
            if scrollY < 0
                scrollY = 0
            end if
            m.page_scroll_y = scrollY
        else
            m.tv_title.translation = [60, m.section_title_y]
            m.tv_list.translation = [40, listY]
            m.page_scroll_y = 0
        end if
    else
        m.page_scroll_y = 0
    end if
end sub

sub scrollActorPage(targetY as Float)
    currentY = m.actor_page.translation[1]
    if currentY = targetY
        return
    end if
    m.actorScrollInterp.keyValue = [ [0.0, currentY], [0.0, targetY] ]
    m.actorScrollAnimation.control = "start"
end sub

sub onMoviesFocused()
    scrollActorPage(0.0)
end sub

sub onTvFocused()
    if m.page_scroll_y > 0
        scrollActorPage(-m.page_scroll_y)
    end if
end sub

sub onActorLoaded()
    result = m.readerTask.content
    if result = invalid or result.code = invalid or result.code <= 0 or result.data = invalid
        m.actor_error_msg.text = "Loading failed."
        m.actor_error.visible = true
        return
    end if

    data = result.data
    actor = data.actor
    if actor = invalid
        m.actor_error_msg.text = "Actor not found."
        m.actor_error.visible = true
        return
    end if

    m.actor_page.translation = [0, 0]

    if actor.name <> invalid
        m.actor_name.text = actor.name
    end if
    if actor.job <> invalid
        m.actor_job.text = actor.job
    end if

    if actor.avatar <> invalid and actor.avatar <> ""
        m.avatar.uri = actor.avatar
        m.avatar.visible = true
        m.avatar_initials.visible = false
    else
        m.avatar.visible = false
        m.avatar_initials.visible = true
        if actor.new_name <> invalid
            m.avatar_initials.text = actor.new_name
        else
            m.avatar_initials.text = "?"
        end if
    end if

    hasMovies = false
    hasTv = false
    if data.movie <> invalid and data.movie.Count() > 0
        hasMovies = true
        m.movies_list.content = actorWorksToContentNode(data.movie, 1)
        m.movies_title.visible = true
        m.movies_list.visible = true
    else
        m.movies_title.visible = false
        m.movies_list.visible = false
    end if

    if data.tv <> invalid and data.tv.Count() > 0
        hasTv = true
        m.tv_list.content = actorWorksToContentNode(data.tv, 2)
        m.tv_title.visible = true
        m.tv_list.visible = true
    else
        m.tv_title.visible = false
        m.tv_list.visible = false
    end if

    layoutActorSections(hasMovies, hasTv)

    if hasMovies = true
        m.movies_list.setFocus(true)
    else if hasTv = true
        m.tv_list.setFocus(true)
    end if
end sub

function actorWorksToContentNode(items, boxType as Integer) as Object
    ContentNode = createObject("roSGNode", "ContentNode")
    row = ContentNode.createChild("ContentNode")
    for i = 0 to items.Count() - 1
        item = items[i]
        if item <> invalid
            child = row.createChild("ContentNode")
            if item.title <> invalid
                child.title = item.title
            end if
            if item.poster <> invalid
                child.hdposterurl = item.poster
            end if
            data = CreateObject("roAssociativeArray")
            if item.id <> invalid
                data["mid"] = item.id
            end if
            data["box_type"] = boxType
            if item.imdb_rating <> invalid
                data["imdb_rating"] = item.imdb_rating
            end if
            if item.tomato_meter <> invalid
                data["tomato_meter"] = item.tomato_meter
            end if
            if item.tomato_meter_state <> invalid
                data["tomato_meter_state"] = item.tomato_meter_state
            end if
            if boxType = 1 and item.quality_tag <> invalid
                data["quality_tag_new"] = item.quality_tag
            end if
            if boxType = 2 and item.season_episode <> invalid
                data["season_episode"] = item.season_episode
            end if
            child.addField("data", "assocarray", false)
            child.data = data
        end if
    end for
    return ContentNode
end function

sub onWorkSelected()
    list = invalid
    if m.movies_list.hasFocus() = true
        list = m.movies_list
    else if m.tv_list.hasFocus() = true
        list = m.tv_list
    end if
    if list = invalid
        return
    end if
    aa = list.content.getChild(list.rowItemSelected[0]).getChild(list.rowItemSelected[1])
    if aa = invalid or aa.data = invalid
        return
    end if
    arr3 = aa.data
    arr3["title"] = aa.title
    arr3["cover"] = aa.hdposterurl
    m.top.workSelected = FormatJson(arr3)
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    if press = false
        return false
    end if
    if key = "down"
        if m.movies_list.hasFocus() = true and m.tv_list.visible = true
            if m.page_scroll_y > 0
                scrollActorPage(-m.page_scroll_y)
            end if
            m.tv_list.setFocus(true)
            return true
        end if
    else if key = "up"
        if m.tv_list.hasFocus() = true and m.movies_list.visible = true
            scrollActorPage(0.0)
            m.movies_list.setFocus(true)
            return true
        end if
    end if
    return false
end function
