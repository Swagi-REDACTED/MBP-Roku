' MovieBoxPro Enhanced custom player core.
' Owns transport input, OSD, seeking, buffering presentation and player focus.
' Roku's Video node is deliberately used only as the platform decode/render primitive.

sub cp_init()
    if m.video = invalid
        return
    end if

    ' Completely suppress Roku's built-in playback UI.  The containing videoPlay
    ' component retains key focus so transport keys never fall through to Video.
    m.video.enableUI = false
    m.video.enableTrickPlay = false
    m.video.notificationInterval = 0.1
    m.video.seekMode = "default"

    m.cpUi = m.top.findNode("customPlayerUi")
    m.cpTitle = m.top.findNode("cpTitle")
    m.cpState = m.top.findNode("cpState")
    m.cpCurrent = m.top.findNode("cpCurrent")
    m.cpDuration = m.top.findNode("cpDuration")
    m.cpProgressFill = m.top.findNode("cpProgressFill")
    m.cpBufferUi = m.top.findNode("customBufferUi")
    m.cpBufferText = m.top.findNode("cpBufferText")
    m.cpBufferFill = m.top.findNode("cpBufferFill")
    m.cpToast = m.top.findNode("customToast")
    m.cpToastText = m.top.findNode("cpToastText")

    m.cpProgressWidth = 1120
    m.cpBufferWidth = 300
    m.cpLastPosition = 0.0
    m.cpLastDuration = 0.0
    ' User intent is authoritative. Roku Video.state can transiently change during
    ' source/quality rebuilds, so do not use it as the sole pause-state truth.
    m.cpUserPaused = false

    m.cpUiTimer = CreateObject("roSGNode", "Timer")
    m.cpUiTimer.duration = 4.5
    m.cpUiTimer.repeat = false
    m.cpUiTimer.ObserveField("fire", "cp_onUiTimeout")

    m.cpToastTimer = CreateObject("roSGNode", "Timer")
    m.cpToastTimer.duration = 1.1
    m.cpToastTimer.repeat = false
    m.cpToastTimer.ObserveField("fire", "cp_onToastTimeout")

    ' Accumulate rapid seek presses and commit once after the user stops tapping.
    m.cpSeekTimer = CreateObject("roSGNode", "Timer")
    m.cpSeekTimer.duration = 0.65
    m.cpSeekTimer.repeat = false
    m.cpSeekTimer.ObserveField("fire", "cp_commitPendingSeek")
    m.cpSeekPending = false
    m.cpSeekBase = 0.0
    m.cpSeekTarget = 0.0

    cp_takeFocus()
end sub

sub cp_resetForContent()
    m.cpUserPaused = false
    if m.cpSeekTimer <> invalid
        m.cpSeekTimer.control = "stop"
    end if
    m.cpSeekPending = false
    m.cpSeekBase = 0.0
    m.cpSeekTarget = 0.0
    m.cpLastPosition = 0.0
    m.cpLastDuration = 0.0
    if m.cpProgressFill <> invalid
        m.cpProgressFill.width = 1
    end if
    if m.cpBufferFill <> invalid
        m.cpBufferFill.width = 1
    end if
    if m.cpCurrent <> invalid
        m.cpCurrent.text = "0:00"
    end if
    if m.cpDuration <> invalid
        m.cpDuration.text = "--:--"
    end if
    if m.cpTitle <> invalid
        m.cpTitle.text = cp_resolveTitle()
    end if
    if m.cpBufferUi <> invalid
        m.cpBufferUi.visible = false
    end if
    cp_showUi("LOADING")
    cp_takeFocus()
end sub

sub cp_takeFocus()
    if m.top <> invalid
        m.top.setFocus(true)
    end if
end sub

function cp_resolveTitle() as String
    if m.video <> invalid and m.video.content <> invalid
        if m.video.content.title <> invalid and m.video.content.title <> ""
            return m.video.content.title
        end if
    end if
    if m.videoinfo <> invalid and m.videoinfo.moviedata <> invalid
        data = m.videoinfo.moviedata
        if data.title <> invalid and data.title <> ""
            return data.title
        end if
        if data.name <> invalid and data.name <> ""
            return data.name
        end if
    end if
    return "MovieBoxPro Enhanced"
end function

function cp_formatTime(value as Dynamic) as String
    if value = invalid or value < 0
        value = 0
    end if
    total = Int(value)
    hours = Int(total / 3600)
    minutes = Int((total mod 3600) / 60)
    seconds = total mod 60

    secText = seconds.ToStr()
    if seconds < 10
        secText = "0" + secText
    end if

    if hours > 0
        minText = minutes.ToStr()
        if minutes < 10
            minText = "0" + minText
        end if
        return hours.ToStr() + ":" + minText + ":" + secText
    end if
    return minutes.ToStr() + ":" + secText
end function

function cp_stateText() as String
    if m.video = invalid
        return "PLAYER"
    end if
    state = m.video.state
    if state = "paused"
        return "PAUSED"
    else if state = "buffering"
        return "BUFFERING"
    else if state = "playing"
        return "PLAYING"
    else if state = "error"
        return "PLAYBACK ERROR"
    else if state = "finished"
        return "FINISHED"
    else if state = "stopped"
        return "STOPPED"
    end if
    return UCase(state)
end function

sub cp_showUi(stateText as Dynamic)
    if m.cpUi = invalid
        return
    end if
    m.cpUi.visible = true
    if m.cpTitle <> invalid
        m.cpTitle.text = cp_resolveTitle()
    end if
    if m.cpState <> invalid
        if stateText = invalid or stateText = ""
            m.cpState.text = cp_stateText()
        else
            m.cpState.text = stateText
        end if
    end if
    cp_updateProgress(m.cpLastPosition)
    cp_refreshSubtitleLayout()

    m.cpUiTimer.control = "stop"
    if m.video <> invalid and m.video.state = "playing"
        m.cpUiTimer.control = "start"
    end if
end sub

sub cp_hideUi()
    if m.cpUi <> invalid
        m.cpUi.visible = false
    end if
    cp_refreshSubtitleLayout()
    if m.cpUiTimer <> invalid
        m.cpUiTimer.control = "stop"
    end if
end sub


sub cp_refreshSubtitleLayout()
    if m.lastSubtitleText <> invalid and m.lastSubtitleText <> ""
        updateSubtitleLayout(m.lastSubtitleText)
    end if
end sub

sub cp_onUiTimeout()
    if m.video <> invalid and m.video.state = "playing"
        cp_hideUi()
    end if
end sub

sub cp_showToast(message as String)
    if m.cpToast = invalid or m.cpToastText = invalid
        return
    end if
    m.cpToastText.text = message
    m.cpToast.visible = true
    m.cpToastTimer.control = "stop"
    m.cpToastTimer.control = "start"
end sub

sub cp_onToastTimeout()
    if m.cpToast <> invalid
        m.cpToast.visible = false
    end if
end sub

sub cp_noteInteraction()
    cp_showUi(cp_stateText())
end sub

sub cp_updateProgress(position as Dynamic)
    if position = invalid or position < 0
        position = 0
    end if
    m.cpLastPosition = position

    duration = 0
    if m.video <> invalid and m.video.duration <> invalid
        duration = m.video.duration
    end if
    if duration > 0
        m.cpLastDuration = duration
    else
        duration = m.cpLastDuration
    end if

    if m.cpCurrent <> invalid
        m.cpCurrent.text = cp_formatTime(position)
    end if
    if m.cpDuration <> invalid
        if duration > 0
            m.cpDuration.text = cp_formatTime(duration)
        else
            m.cpDuration.text = "--:--"
        end if
    end if

    if m.cpProgressFill <> invalid
        fillWidth = 1
        if duration > 0
            ratio = position / duration
            if ratio < 0
                ratio = 0
            end if
            if ratio > 1
                ratio = 1
            end if
            fillWidth = Int(ratio * m.cpProgressWidth)
            if fillWidth < 1
                fillWidth = 1
            end if
        end if
        m.cpProgressFill.width = fillWidth
    end if
end sub

sub cp_onPosition(position as Dynamic)
    ' While the user is stacking seek presses, keep the OSD on the preview target
    ' rather than letting live playback position notifications snap it backwards.
    if m.cpSeekPending = true
        return
    end if
    cp_updateProgress(position)
end sub

sub cp_onDurationChanged()
    cp_updateProgress(m.cpLastPosition)
end sub

sub cp_onBufferStatus(status as Dynamic)
    if m.cpBufferUi = invalid
        return
    end if
    if status = invalid
        if m.video <> invalid and m.video.state <> "buffering"
            m.cpBufferUi.visible = false
        end if
        return
    end if

    percent = 0
    if status.percentage <> invalid
        percent = status.percentage
    end if
    if percent < 0
        percent = 0
    end if
    if percent > 100
        percent = 100
    end if

    if m.cpBufferText <> invalid
        m.cpBufferText.text = "BUFFERING  " + percent.ToStr() + "%"
    end if
    if m.cpBufferFill <> invalid
        fillWidth = Int((percent / 100.0) * m.cpBufferWidth)
        if fillWidth < 1
            fillWidth = 1
        end if
        m.cpBufferFill.width = fillWidth
    end if
    m.cpBufferUi.visible = true
end sub

sub cp_onState(state as String)
    ' If a source/quality rebuild had to start playback while the user intended
    ' to remain paused, immediately restore the paused state.
    if state = "playing" and m.cpUserPaused = true
        m.video.control = "pause"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
        cp_showUi("PAUSED")
        return
    end if

    if state = "buffering"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = true
        end if
        cp_showUi("BUFFERING")
    else if state = "playing"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
        cp_showUi("PLAYING")
    else if state = "paused"
        m.cpUserPaused = true
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
        cp_showUi("PAUSED")
    else if state = "error"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
        cp_showUi("PLAYBACK ERROR")
        errorText = "Playback failed"
        if m.video <> invalid and m.video.errorMsg <> invalid and m.video.errorMsg <> ""
            errorText = m.video.errorMsg
        end if
        cp_showToast(errorText)
    else if state = "finished"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
        cp_showUi("FINISHED")
    else if state = "stopped"
        if m.cpBufferUi <> invalid
            m.cpBufferUi.visible = false
        end if
    end if
end sub

sub cp_togglePause()
    if m.video = invalid
        return
    end if

    if m.cpUserPaused = true or m.video.state = "paused"
        m.cpUserPaused = false
        if m.video.state = "paused"
            m.video.control = "resume"
        else if m.video.state <> "playing" and m.video.state <> "buffering"
            m.video.control = "play"
        end if
        cp_showUi("PLAYING")
        cp_showToast("Play")
    else if m.video.state = "playing" or m.video.state = "buffering"
        m.cpUserPaused = true
        m.video.control = "pause"
        cp_showUi("PAUSED")
        cp_showToast("Pause")
    else if m.video.state = "stopped" or m.video.state = "finished"
        m.cpUserPaused = false
        m.video.control = "play"
        cp_showUi("PLAYING")
    end if
end sub

sub cp_forcePlay()
    if m.video = invalid
        return
    end if
    m.cpUserPaused = false
    if m.video.state = "paused"
        m.video.control = "resume"
    else if m.video.state <> "playing"
        m.video.control = "play"
    end if
    cp_showUi("PLAYING")
end sub

sub cp_forcePause()
    if m.video = invalid
        return
    end if
    m.cpUserPaused = true
    if m.video.state = "playing" or m.video.state = "buffering"
        m.video.control = "pause"
    end if
    cp_showUi("PAUSED")
end sub

sub cp_seekBy(deltaSeconds as Integer)
    if m.video = invalid
        return
    end if

    current = m.cpLastPosition
    if m.cpSeekPending = true
        current = m.cpSeekTarget
    else
        if m.video.position <> invalid and m.video.position >= 0
            current = m.video.position
        end if
        m.cpSeekBase = current
    end if

    target = current + deltaSeconds
    if target < 0
        target = 0
    end if

    duration = m.video.duration
    if duration <> invalid and duration > 0 and target > duration
        target = duration - 0.25
        if target < 0
            target = 0
        end if
    end if

    m.cpSeekTarget = target
    m.cpSeekPending = true
    m.cpLastPosition = target
    cp_updateProgress(target)

    totalDelta = Int(target - m.cpSeekBase)
    if totalDelta > 0
        cp_showToast("Seek +" + totalDelta.ToStr() + "s")
    else
        cp_showToast("Seek " + totalDelta.ToStr() + "s")
    end if
    cp_showUi(cp_stateText())

    if m.cpSeekTimer <> invalid
        m.cpSeekTimer.control = "stop"
        m.cpSeekTimer.control = "start"
    else
        cp_commitPendingSeek()
    end if
end sub

sub cp_commitPendingSeek()
    if m.cpSeekPending <> true
        return
    end if
    m.cpSeekPending = false
    if m.video = invalid
        return
    end if
    target = m.cpSeekTarget
    m.video.seek = target
    m.cpLastPosition = target
    cp_updateProgress(target)
end sub

function cp_isTransportKey(key as String) as Boolean
    return key = "OK" or key = "play" or key = "playonly" or key = "pause" or key = "replay" or key = "rewind" or key = "fastforward" or key = "left" or key = "right" or key = "up" or key = "down" or key = "options" or key = "back"
end function
