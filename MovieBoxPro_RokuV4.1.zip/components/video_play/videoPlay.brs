'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.video = m.top.findNode("my_video")
    m.skiptip = m.top.findNode("skiptip")
    m.skiptip_end = m.top.findNode("skiptip_end")
    m.skip_text = m.top.FindNode("skip_text")
    m.skip_text2 = m.top.FindNode("skip_text2")
    m.subbg = m.top.findNode("subbg")
    m.textshadow = m.top.findNode("textshadow")
    m.srt_bg22 = m.top.findNode("srt_bg22")
    m.subtext = m.top.findNode("subtext")
    m.fontshadow = m.top.FindNode("fontshadow")
    m.subfont = m.top.FindNode("subfont")
    m.lastSubtitleText = ""
    m.subtitleMaxWidth = 960
    m.subtitlePadH = 14
    m.subtitlePadV = 9
    m.fontRegistry = CreateObject("roFontRegistry")
    m.fontFamilyCache = {}
    m.measureFontCache = {}
    m.subtitleFontFamily = "Arial Unicode MS"
    m.pendingSeekTime = 0
    m.resumeSeekTarget = 0
    m.resumeSeekTries = 0
    m.skipSaveConfirmPending = false
    m.skipPlayDlg = m.top.findNode("skipPlayDlg")
    m.skipPlayDlgText = m.top.findNode("skipPlayDlgText")
    m.skipPlayBtnYes = m.top.findNode("skipPlayBtnYes")
    m.skipPlayBtnNo = m.top.findNode("skipPlayBtnNo")
    m.skipPlayBtnYesNormal = "0x0066CCFF"
    m.skipPlayBtnYesFocus = "0x00AAFFFF"
    m.skipPlayBtnNoNormal = "0x333333FF"
    m.skipPlayBtnNoFocus = "0x555555FF"
    m.skipPlayFocusYes = true
    m.skipSettingHandled = false
    m.skipSettingFlowActive = false
    m.videosetWasVisibleBeforeSkip = false
    m.audio_track_applied = ""
    m.episodeSetting = invalid
    m.srt_source_delay = 0.0
    m.srt_manual_delay = 0.0
    m.subtitleBgOpacity = 65
    m.subtitleTextOpacity = 100
    m.failedSourceUrls = {}
    m.sourceFailoverCount = 0
    m.lastFailoverUrl = ""
    m.modalOkGuard = false
    m.activePlaySeason = invalid
    m.activePlayEpisode = invalid
    m.settingsClosePending = false
    m.settingsModalActive = false
    m.settingsCloseTimer = CreateObject("roSGNode", "Timer")
    m.settingsCloseTimer.duration = 0.12
    m.settingsCloseTimer.repeat = false
    m.settingsCloseTimer.ObserveField("fire", "finishVideoSettingsClose")
    m.modalGuardTimer = CreateObject("roSGNode", "Timer")
    m.modalGuardTimer.duration = 0.45
    m.modalGuardTimer.repeat = false
    m.modalGuardTimer.ObserveField("fire", "clearModalOkGuard")

    ' Initialize the custom player shell before binding playback observers.
    cp_init()

    ' Observe the player once for the lifetime of this component. Re-observing on
    ' every content change can multiply callbacks after several episodes/quality changes.
    m.video.ObserveField("position", "onPositionChanged")
    m.video.ObserveField("state", "controlvideoplay")
    m.video.ObserveField("bufferingStatus", "onBufferingStatusChanged")
    m.video.ObserveField("duration", "cp_onDurationChanged")
    m.bufferWatchdog = CreateObject("roSGNode", "Timer")
    m.bufferWatchdog.duration = 18
    m.bufferWatchdog.repeat = false
    m.bufferWatchdog.ObserveField("fire", "onBufferWatchdog")
    m.bufferWatchdogActive = false
    m.bufferRetryCount = 0
    m.lastBufferPercent = -1
    m.lastPlayablePosition = 0
    m.lastRecoveryPosition = 0
end function

function resolveSubtitleFontFamily(fontUri as String) as String
    if m.fontFamilyCache[fontUri] <> invalid
        return m.fontFamilyCache[fontUri]
    end if

    families = m.fontRegistry.GetFamilies()
    beforeCount = families.Count()
    m.fontRegistry.Register(fontUri)
    families = m.fontRegistry.GetFamilies()

    familyName = m.subtitleFontFamily
    if families.Count() > beforeCount
        familyName = families[families.Count() - 1]
    else if m.subtitleFontFamily <> invalid and m.subtitleFontFamily <> ""
        familyName = m.subtitleFontFamily
    end if

    m.fontFamilyCache[fontUri] = familyName
    return familyName
end function

function getSubtitleMeasureFont() as Object
    fontSize = 28
    if m.srt_size <> invalid
        fontSize = m.srt_size
    end if

    fontUri = "pkg:/images/arial_unicode_ms.ttf"
    if m.subfont <> invalid and m.subfont.uri <> invalid and m.subfont.uri <> ""
        fontUri = m.subfont.uri
    end if

    cacheKey = fontUri + ":" + fontSize.ToStr()
    if m.measureFontCache[cacheKey] <> invalid
        return m.measureFontCache[cacheKey]
    end if

    familyName = resolveSubtitleFontFamily(fontUri)
    font = m.fontRegistry.GetFont(familyName, fontSize, false, false)
    m.measureFontCache[cacheKey] = font
    return font
end function

function getSubtitleFontSize() as Integer
    fontSize = 28
    if m.srt_size <> invalid
        fontSize = m.srt_size
    end if
    return fontSize
end function

function getSubtitleLineHeight() as Integer
    return getSubtitleFontSize() + 12
end function

function estimateSubtitleLineCount(text as String, maxW as Integer, font as Object) as Integer
    paragraphs = text.Split(chr(10))
    totalLines = 0

    for each para in paragraphs
        para = para.Trim()
        if para = ""
            continue for
        end if
        fullW = font.GetOneLineWidth(para, 2000)
        if fullW <= maxW
            totalLines = totalLines + 1
        else
            wrapLines = Int((fullW + maxW - 1) / maxW)
            if wrapLines < 1
                wrapLines = 1
            end if
            totalLines = totalLines + wrapLines
        end if
    end for

    if totalLines < 1
        totalLines = 1
    end if
    return totalLines
end function

function getSubtitleLabelWidth(text as String, lineCount as Integer, maxW as Integer, font as Object) as Integer
    widthPad = 16

    if lineCount <= 1
        singleLine = text.Replace(chr(13), "").Replace(chr(10), " ").Trim()
        singleW = font.GetOneLineWidth(singleLine, maxW) + widthPad
        if singleW > maxW
            return maxW
        end if
        if singleW < 60
            return 60
        end if
        return singleW
    end if

    paragraphs = text.Split(chr(10))
    maxLineW = 0
    for each para in paragraphs
        para = para.Trim()
        if para = ""
            continue for
        end if
        fullW = font.GetOneLineWidth(para, 2000)
        if fullW > maxW
            return maxW
        end if
        if fullW > maxLineW
            maxLineW = fullW
        end if
    end for

    maxLineW = maxLineW + widthPad
    if maxLineW > maxW
        return maxW
    end if
    if maxLineW < 60
        return 60
    end if
    return maxLineW
end function

sub updateSubtitleLayout(text as String)
    maxW = m.subtitleMaxWidth
    padH = m.subtitlePadH
    padV = m.subtitlePadV
    lineSpacing = 1
    lineH = getSubtitleLineHeight()
    font = getSubtitleMeasureFont()
    cleanText = text.Replace(chr(13), "").Trim()

    ' Give the label a real measurement box before reading wrappedLines.
    m.subtext.width = maxW
    m.subtext.height = 260
    m.subtext.ellipsizeOnBoundary = false
    m.subtext.wrap = true
    m.subtext.text = cleanText
    m.textshadow.text = cleanText

    lineCount = estimateSubtitleLineCount(cleanText, maxW, font)
    wrapped = m.subtext.wrappedLines
    if wrapped <> invalid and wrapped > lineCount
        lineCount = wrapped
    end if

    labelWidth = getSubtitleLabelWidth(cleanText, lineCount, maxW, font)
    if labelWidth < maxW
        m.subtext.width = labelWidth
        wrapped = m.subtext.wrappedLines
        if wrapped <> invalid and wrapped > lineCount
            lineCount = wrapped
            labelWidth = maxW
            m.subtext.width = maxW
        end if
    end if

    contentH = lineCount * lineH
    if lineCount > 1
        contentH = contentH + (lineCount - 1) * lineSpacing
    end if

    bgWidth = labelWidth + padH * 2
    bgHeight = contentH + padV * 2
    if bgWidth < 60
        bgWidth = 60
    end if
    if bgHeight < 36
        bgHeight = 36
    end if

    m.srt_bg22.width = bgWidth
    m.srt_bg22.height = bgHeight
    m.subtext.width = labelWidth
    m.subtext.height = contentH
    m.subtext.translation = [padH, padV]
    m.textshadow.width = labelWidth
    m.textshadow.height = contentH
    m.textshadow.translation = [padH + 1, padV + 1]

    centerX = Int((1280 - bgWidth) / 2)
    yPos = 570
    if m.srt_position <> invalid
        yPos = m.srt_position
    end if
    subtitleSafeBottom = 700
    if m.cpUi <> invalid and m.cpUi.visible = true
        ' Keep subtitles above the custom transport bar while it is visible.
        subtitleSafeBottom = 540
    end if
    maxY = subtitleSafeBottom - bgHeight
    if maxY < 0
        maxY = 0
    end if
    if yPos > maxY
        yPos = maxY
    end if
    if yPos < 0
        yPos = 0
    end if
    m.subbg.translation = [centerX, yPos]
end sub

sub OnContentChange()
    m.videoinfo = m.top.content
    m.video.content = m.videoinfo.content
    cp_resetForContent()
    m.audio_track_applied = ""
    m.bufferWatchdog.control = "stop"
    m.bufferWatchdogActive = false
    m.bufferRetryCount = 0
    m.lastBufferPercent = -1
    m.lastPlayablePosition = 0
    m.lastRecoveryPosition = 0
    m.failedSourceUrls = {}
    m.sourceFailoverCount = 0
    m.lastFailoverUrl = ""

    if m.episodeSetting <> invalid
        m.episodeSetting.visible = false
    end if
    if m.skipSetting <> invalid
        m.skipSetting.visible = false
    end if
    if m.videoset <> invalid
        m.top.removeChild(m.videoset)
        m.videoset = invalid
    end if
    
    ' Cancel subtitle work from the previous episode/source before resetting state.
    if m.readContentTask <> invalid
        m.readContentTask.unobserveField("content")
        m.readContentTask.control = "STOP"
        m.readContentTask = invalid
    end if
    if m.subtitleRefreshTask <> invalid
        m.subtitleRefreshTask.unobserveField("content")
        m.subtitleRefreshTask.control = "STOP"
        m.subtitleRefreshTask = invalid
    end if

    ' New content always starts with subtitles OFF. Server defaults and the
    ' previous episode's language preference must not select a second track.
    m.current_srt = invalid
    m.current_srt_lang = invalid
    m.srtMap = []
    m.srt_source_delay = 0.0
    m.lastSubtitleText = ""
    m.subbg.visible = false
    user = CreateObject("roRegistrySection", "User")
    m.srt_manual_delay = 0.0
    if user.Exists("subtitle_manual_delay")
        m.srt_manual_delay = user.Read("subtitle_manual_delay").ToFloat()
    end if
    if user.Exists("subtitle_bg_opacity")
        m.subtitleBgOpacity = user.Read("subtitle_bg_opacity").ToInt()
    end if
    if user.Exists("subtitle_text_opacity")
        m.subtitleTextOpacity = user.Read("subtitle_text_opacity").ToInt()
    end if
    user.Delete("select_subtitle_lang")
    user.Flush()
    applySubtitleAppearance()
    if m.videoinfo.subtitle_list <> invalid
        m.videoinfo.subtitle_list["select"] = {"sid":0}
    end if

    arr = m.videoinfo.moviedata
    m.activePlaySeason = invalid
    m.activePlayEpisode = invalid
    if arr <> invalid
        if arr.season <> invalid
            m.activePlaySeason = arr.season
        end if
        if arr.episode <> invalid
            m.activePlayEpisode = arr.episode
        end if
    end if

    activeSource = video_play_find_current_source()
    activeFid = ""
    if m.videoinfo.active_fid <> invalid and m.videoinfo.active_fid <> ""
        activeFid = m.videoinfo.active_fid
    else
        activeFid = video_play_source_fid(activeSource)
    end if
    if activeFid <> ""
        arr["fid"] = activeFid
        m.videoinfo["active_fid"] = activeFid
    end if
    m.videoinfo["moviedata"] = arr
    m.videoset = createObject("RoSGNode", "videosetting")
    ' Focus fence: Roku list/grid nodes can restore focus after an itemSelected or
    ' component-field observer finishes. Watch the entire Settings subtree so any
    ' post-close focus reclaim by Audio/Subtitles is immediately redirected back
    ' to HyperPlayer. Roku recommends observing focusedChild for custom-component
    ' focus ownership instead of relying only on one-shot setFocus calls.
    m.videoset.ObserveField("focusedChild", "onVideoSettingsFocusedChildChanged")
    m.videoset.content = m.videoinfo
    m.videoset.videoNode = m.video
    m.videoset.visible = false
    m.typelist = m.videoset.FindNode("Typelist")
    m.vlist = m.videoset.FindNode("vlist")
    m.vlist.ObserveField("itemSelected", "setquality")
    m.audiolist = m.videoset.FindNode("audiolist")
    m.videoset.observeField("audioSelectIndex", "setaudio")
    m.subtitles = m.videoset.FindNode("itemsList")
    m.subtitles.ObserveField("itemSelected", "srtselected")
    m.videoset.observeField("srt_con", "srtSet")
    m.settingbg = m.videoset.FindNode("settingbg")
    m.sub_settingbg = m.videoset.FindNode("sub_settingbg")
    m.subtitle_btns = m.videoset.FindNode("subtitle_btns")
    m.subtitle_btns.ObserveField("itemSelected", "close_subtitle")
    m.srt_btn2 = m.videoset.FindNode("btn2")
    m.srt_time = m.videoset.FindNode("srt_time")
    if m.srt_time <> invalid
        m.srt_time.text = subtitleSyncLabel()
    end if
    m.srt_btn2.visible = true
    if m.current_srt <> invalid
        for i = 0 to m.subtitles.content.getChildCount() - 1
            tt = m.subtitles.content.getChild(i)
            if tt.id = m.current_srt.ToStr()
                tt.update({"SecondaryTitle":"true"}, false)
                Exit for
            end if
        end for
    end if
    m.subtitle_delay = m.videoset.FindNode("subtitle_delay")
    m.subtitle_delay.ObserveField("itemSelected", "srt_delay")
    m.srt_bg_opacity_txt = m.videoset.FindNode("srt_bg_opacity")
    m.srt_text_opacity_txt = m.videoset.FindNode("srt_text_opacity")
    m.subtitle_bg_opacity = m.videoset.FindNode("subtitle_bg_opacity")
    m.subtitle_text_opacity = m.videoset.FindNode("subtitle_text_opacity")
    if m.subtitle_bg_opacity <> invalid
        m.subtitle_bg_opacity.ObserveField("itemSelected", "srt_bg_opacity_change")
    end if
    if m.subtitle_text_opacity <> invalid
        m.subtitle_text_opacity.ObserveField("itemSelected", "srt_text_opacity_change")
    end if
    updateSubtitleAppearanceLabels()
    m.videoset.observeField("skip_request", "openSkipSetting")
    m.videoset.observeField("episode_request", "openEpisodePanel")
    m.top.appendChild(m.videoset)
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("srt_size") = true
        m.srt_size = user.Read("srt_size")
        m.srt_size = m.srt_size.ToInt()
    end if
    if m.srt_size = invalid
        m.srt_size = 28
    end if
    m.srt_sizetxt = m.videoset.FindNode("srt_size")
    if m.srt_size <> 28
        m.srt_sizetxt.text = m.srt_size.ToStr()
        m.fontshadow.size = m.srt_size + 1
        m.subfont.size = m.srt_size
    end if
    m.subtitle_size = m.videoset.FindNode("subtitle_size")
    m.subtitle_size.ObserveField("itemSelected", "srt_size2")
    if user.Exists("srt_position") = true
        m.srt_position = user.Read("srt_position")
        m.srt_position = m.srt_position.ToInt()
    end if
    m.font_list = m.videoset.FindNode("font_list")
    m.font_list.ObserveField("itemSelected", "srt_font2")
    if user.Exists("srt_font") = true
        ttf = user.Read("srt_font")
        m.fontshadow.uri = "pkg:/images/"+ttf
        m.subfont.uri = "pkg:/images/"+ttf
        m.subtitleFontFamily = lookupSubtitleFontFamily(ttf)
    end if
    m.subtitle_move = m.videoset.FindNode("subtitle_move")
    m.subtitle_move.ObserveField("itemSelected", "srt_move")
    m.skip_start_raw = 0
    m.skip_end_raw = 0
    m.skip2 = 0
    m.skip_end = 0
    m.close_skiptip = 0
    
    resumeSec = bestResumeSeconds(arr, m.videoinfo)
    m.videoinfo.seconds = resumeSec
    m.resumeSeekTarget = resumeSec
    m.resumeSeekTries = 0

    if arr.box_type = 2
        if m.videoinfo.skips.start > 0
            m.skip_start_raw = m.videoinfo.skips.start
        end if
        if m.videoinfo.skips.end > 0
            m.skip_end_raw = m.videoinfo.skips.end
        end if
    end if

    if isSkipIntroOutroEnabled()
        if arr.box_type = 2
            if m.skip_start_raw > 0 and m.skip_start_raw > resumeSec
                m.video.seek = m.skip_start_raw
                m.skip2 = m.skip_start_raw
            else
                m.video.seek = resumeSec
            end if
            if m.skip_end_raw > 0
                m.skip_end = m.skip_end_raw
            end if
        else
            if arr.plan_watched <> invalid and arr.plan_watched = 1
                m.video.seek = 0
            else
                m.video.seek = resumeSec
            end if
        end if
        if m.videoinfo.replay = 1
            if arr.box_type = 2
                if m.skip_start_raw > 0
                    m.video.seek = m.skip_start_raw
                    m.skip2 = m.skip_start_raw
                else
                    m.video.seek = 0
                end if
            else
                m.video.seek = 0
            end if
        end if
    else
        if arr.box_type = 2
            m.video.seek = resumeSec
        else
            if arr.plan_watched <> invalid and arr.plan_watched = 1
                m.video.seek = 0
            else
                m.video.seek = resumeSec
            end if
        end if
        if m.videoinfo.replay = 1
            m.video.seek = 0
        end if
    end if
    if m.videoinfo.replay = 1
        m.resumeSeekTarget = 0
    else if m.skip2 > 0
        m.resumeSeekTarget = m.skip2
    else
        m.resumeSeekTarget = resumeSec
    end if
    if m.videoinfo.content <> invalid and m.resumeSeekTarget > 0
        m.videoinfo.content.setField("playStart", m.resumeSeekTarget)
        m.video.content = m.videoinfo.content
    end if
    m.video.control = "play"
    m.video.visible = true
    m.video.suppressCaptions = true
    cp_takeFocus()
    video_play_sync_audio_stream_url()

    ' print m.video

    if m.skip2 > 0 and isSkipIntroOutroEnabled()
        m.skip_text.text = "Skipped Opening "+m.skip2.ToStr()+"S,"
        m.skiptip.visible = true
        m.skiptimer = CreateObject("roSGNode", "Timer")
        m.skiptimer.duration = 5
        m.skiptimer.control = "start"
        m.skiptimer.ObserveField("fire","hideskip")
    end if
end sub

function setquality()
    if videoSettingsModalIsActive() = false
        return false
    end if
    if m.vlist = invalid or m.vlist.content = invalid or m.videoinfo = invalid or m.videoinfo.list = invalid
        return false
    end if
    idx = m.vlist.itemSelected
    if idx = invalid or idx < 0 or idx >= m.videoinfo.list.Count()
        return false
    end if
    video = m.videoinfo.list[idx]
    if video_play_is_supported_candidate(video) = false
        cp_showToast("That quality is not supported on this Roku")
        current = video_play_find_current_source()
        video_play_mark_selected_source(current)
        closeVideoSettings(true)
        return false
    end if

    oldFid = ""
    if m.videoinfo.active_fid <> invalid
        oldFid = m.videoinfo.active_fid.ToStr()
    end if
    newFid = video_play_source_fid(video)

    video_play_mark_selected_source(video)
    if video.quality <> invalid and video.quality <> ""
        ' Persist only selections made through the fixed v4.3 picker. This includes
        ' ORG when the user deliberately chooses it; startup still falls back if
        ' that format is not compatible with the current Roku.
        quality2 = video.quality
        user = CreateObject("roRegistrySection", "User")
        user.Write("select_quality", quality2)
        user.Write("quality_user_selected_v43", "1")
        user.Flush()
    end if

    seconds = m.video.position
    if seconds = invalid or seconds < 0
        seconds = m.lastPlayablePosition
    end if
    if seconds = invalid or seconds < 0
        seconds = 0
    end if

    m.video.control = "stop"
    m.videoset.audioStreamUrl = ""
    m.videoset.selectedAudioTrackId = ""
    m.videoset.currentAudioList = []
    m.videoset.currentSourceIndex = 0
    m.videoset.callFunc("clearAudioTrackList")

    videocontent = video_play_make_content(video, seconds)
    m.video.content = videocontent
    m.videoset.audioStreamUrl = videocontent.url
    m.audio_track_applied = ""
    m.resumeSeekTarget = seconds
    m.resumeSeekTries = 0
    m.bufferRetryCount = 0
    m.lastBufferPercent = -1
    m.failedSourceUrls = {}
    m.sourceFailoverCount = 0

    if newFid <> ""
        m.videoinfo["active_fid"] = newFid
        arr = m.videoinfo.moviedata
        arr["fid"] = newFid
        m.videoinfo["moviedata"] = arr
    end if

    video_play_sync_current_audio_list()
    m.video.control = "play"
    closeVideoSettings(true)

    if newFid <> "" and oldFid <> newFid
        video_play_refresh_subtitles_for_source(video)
    end if
    return true
end function

function video_play_stream_format(video as Dynamic, videoUrl as String) as String
    fmt = ""
    if video <> invalid and video.format <> invalid
        fmt = LCase(video.format.ToStr())
    end if
    lowerUrl = LCase(videoUrl)

    ' Prefer unmistakable URL/container evidence over inconsistent API labels.
    if Instr(1, lowerUrl, ".m3u8") > 0 or fmt = "hls" or fmt = "m3u8"
        return "hls"
    else if Instr(1, lowerUrl, ".mpd") > 0 or fmt = "dash" or fmt = "mpd"
        return "dash"
    else if Instr(1, lowerUrl, ".mkv") > 0 or Instr(1, lowerUrl, ".webm") > 0 or fmt = "mkv" or fmt = "webm"
        return "mkv"
    else if Instr(1, lowerUrl, ".mp4") > 0 or Instr(1, lowerUrl, ".mov") > 0 or Instr(1, lowerUrl, ".m4v") > 0
        return "mp4"
    else if fmt = "mp4" or fmt = "mov" or fmt = "m4v"
        return "mp4"
    end if

    ' Roku defaults an unspecified streamFormat to ordinary MP4 semantics. Never
    ' pass codec names such as h264/h265 through as if they were containers.
    return ""
end function

function video_play_subtitle_group_matches(group as Dynamic, preference as Dynamic) as Boolean
    if group = invalid or preference = invalid or preference = ""
        return false
    end if
    wanted = LCase(preference.ToStr())
    if group.language <> invalid and LCase(group.language.ToStr()) = wanted
        return true
    end if
    if group.lang <> invalid and LCase(group.lang.ToStr()) = wanted
        return true
    end if
    if group.subtitles <> invalid
        for each subItem in group.subtitles
            if subItem <> invalid
                if subItem.language <> invalid and LCase(subItem.language.ToStr()) = wanted
                    return true
                end if
                if subItem.lang <> invalid and LCase(subItem.lang.ToStr()) = wanted
                    return true
                end if
            end if
        end for
    end if
    return false
end function

function video_play_make_content(video as Object, startAt as Dynamic) as Object
    content = createObject("RoSGNode", "ContentNode")
    if video <> invalid
        if video.filename <> invalid
            content.setField("title", video.filename)
        end if
        videoUrl = ""
        if video.path <> invalid and video.path <> ""
            videoUrl = video.path
        else if video.m3u8_url <> invalid and video.m3u8_url <> ""
            videoUrl = video.m3u8_url
        end if
        content.setField("url", videoUrl)
        streamFormat = video_play_stream_format(video, videoUrl)
        if streamFormat <> ""
            content.setField("streamformat", streamFormat)
        end if
    end if
    if startAt <> invalid and startAt > 0
        content.setField("playStart", startAt)
    end if
    return content
end function

function video_play_source_url(video as Dynamic) as String
    if video = invalid
        return ""
    end if
    if video.path <> invalid and video.path <> ""
        return video.path
    end if
    if video.m3u8_url <> invalid and video.m3u8_url <> ""
        return video.m3u8_url
    end if
    return ""
end function

function video_play_source_fid(video as Dynamic) as String
    if video = invalid
        return ""
    end if
    if video.source_key <> invalid and video.source_key <> ""
        return video.source_key.ToStr()
    end if
    if video.fid <> invalid and video.fid <> ""
        return video.fid.ToStr()
    end if
    return ""
end function

function video_play_quality_rank(video as Dynamic) as Integer
    if video = invalid or video.quality = invalid
        return 0
    end if
    q = UCase(video.quality.ToStr())
    if q = "ORG"
        return 1000
    else if q.Instr("8K") >= 0 or q.Instr("4320") >= 0
        return 9000
    else if q.Instr("4K") >= 0 or q.Instr("2160") >= 0
        return 8000
    else if q.Instr("1440") >= 0
        return 7000
    else if q.Instr("1080") >= 0
        return 6000
    else if q = "AUTO"
        return 5500
    else if q.Instr("720") >= 0
        return 5000
    else if q.Instr("480") >= 0
        return 4000
    else if q.Instr("360") >= 0
        return 3000
    else if q.Instr("240") >= 0
        return 2000
    end if
    return 1000
end function

function video_play_is_supported_candidate(video as Dynamic) as Boolean
    if video = invalid
        return false
    end if
    url = LCase(video_play_source_url(video))
    if url = ""
        return false
    end if
    format = ""
    if video.format <> invalid
        format = LCase(video.format.ToStr())
    end if

    ' Reject containers Roku's playback stack does not support. Signed URLs may
    ' contain query strings, so substring tests are intentional here.
    if format = "avi" or format = "flv" or format = "rm" or format = "rmvb" or format = "wmv"
        return false
    end if
    if Instr(1, url, ".avi") > 0 or Instr(1, url, ".flv") > 0 or Instr(1, url, ".rmvb") > 0 or Instr(1, url, ".wmv") > 0
        return false
    end if
    if format = "av1" and Instr(1, url, ".mpd") = 0
        return false
    end if

    isHevc = false
    if video.h265 <> invalid and video.h265.ToStr() = "1"
        isHevc = true
    end if
    if isHevc
        deviceInfo = CreateObject("roDeviceInfo")
        decode = deviceInfo.CanDecodeVideo({"codec":"hevc"})
        if decode = invalid or decode.result <> true
            return false
        end if
    end if
    return true
end function

sub video_play_mark_selected_source(video as Dynamic)
    if m.vlist = invalid or m.vlist.content = invalid or m.videoinfo = invalid or m.videoinfo.list = invalid
        return
    end if
    targetUrl = video_play_source_url(video)
    if targetUrl = ""
        return
    end if
    for i = 0 to m.vlist.content.getChildCount() - 1
        row = m.vlist.content.getChild(i)
        selected = false
        if i < m.videoinfo.list.Count()
            selected = video_play_source_url(m.videoinfo.list[i]) = targetUrl
        end if
        if selected
            row.update({"SecondaryTitle":"true"}, false)
            m.vlist.jumpToItem = i
        else
            row.update({"SecondaryTitle":"false"}, false)
        end if
    end for
end sub

function video_play_find_best_fallback_source() as Dynamic
    if m.videoinfo = invalid or m.videoinfo.list = invalid
        return invalid
    end if
    currentUrl = ""
    if m.video <> invalid and m.video.content <> invalid and m.video.content.url <> invalid
        currentUrl = m.video.content.url
    end if
    best = invalid
    bestRank = -1
    for each item in m.videoinfo.list
        url = video_play_source_url(item)
        if url <> "" and url <> currentUrl
            alreadyFailed = false
            if m.failedSourceUrls <> invalid and m.failedSourceUrls[url] <> invalid
                alreadyFailed = true
            end if
            if alreadyFailed = false and video_play_is_supported_candidate(item)
                rank = video_play_quality_rank(item)
                if rank > bestRank
                    best = item
                    bestRank = rank
                end if
            end if
        end if
    end for
    return best
end function

function video_play_try_failover(reason as String) as Boolean
    current = video_play_find_current_source()
    currentUrl = video_play_source_url(current)
    if currentUrl = "" and m.video <> invalid and m.video.content <> invalid and m.video.content.url <> invalid
        currentUrl = m.video.content.url
    end if
    if currentUrl <> ""
        m.failedSourceUrls[currentUrl] = true
    end if

    replacementSource = video_play_find_best_fallback_source()
    if replacementSource = invalid
        return false
    end if

    resumeAt = m.lastPlayablePosition
    if m.video.position <> invalid and m.video.position > resumeAt
        resumeAt = m.video.position
    end if
    if resumeAt < 0
        resumeAt = 0
    end if

    oldFid = ""
    if m.videoinfo.active_fid <> invalid
        oldFid = m.videoinfo.active_fid.ToStr()
    end if
    newFid = video_play_source_fid(replacementSource)

    m.sourceFailoverCount = m.sourceFailoverCount + 1
    m.lastFailoverUrl = video_play_source_url(replacementSource)
    m.bufferRetryCount = 0
    m.lastBufferPercent = -1
    m.video.control = "stop"
    m.video.content = video_play_make_content(replacementSource, resumeAt)
    m.resumeSeekTarget = resumeAt
    m.resumeSeekTries = 0
    m.video.control = "play"
    video_play_mark_selected_source(replacementSource)
    video_play_sync_audio_stream_url()

    if newFid <> ""
        m.videoinfo["active_fid"] = newFid
        arr = m.videoinfo.moviedata
        arr["fid"] = newFid
        m.videoinfo["moviedata"] = arr
        if oldFid <> newFid
            video_play_refresh_subtitles_for_source(replacementSource)
        end if
    end if

    label = "Compatible source"
    if replacementSource.quality <> invalid and replacementSource.quality <> ""
        label = replacementSource.quality.ToStr()
    end if
    cp_showToast("Source fallback: " + label)
    cp_showUi("RECOVERING")
    return true
end function

sub video_play_refresh_subtitles_for_source(video as Dynamic)
    fid = video_play_source_fid(video)
    if fid = "" or m.videoinfo = invalid or m.videoinfo.moviedata = invalid
        return
    end if
    m.videoinfo["active_fid"] = fid
    arr = {}
    for each key in m.videoinfo.moviedata
        arr[key] = m.videoinfo.moviedata[key]
    end for
    arr["fid"] = fid
    arr["type"] = "subtitles"
    m.subtitleRefreshTask = createObject("RoSGNode", "GetContentReader")
    m.subtitleRefreshTask.content = arr
    m.subtitleRefreshTask.observeField("content", "onActiveSourceSubtitlesRefreshed")
    m.subtitleRefreshTask.control = "RUN"
end sub

sub onActiveSourceSubtitlesRefreshed()
    if m.subtitleRefreshTask = invalid
        return
    end if
    data = m.subtitleRefreshTask.content
    if data = invalid or Type(data) <> "roAssociativeArray"
        return
    end if
    if data.list = invalid
        data["list"] = []
    end if
    m.videoinfo["subtitle_list"] = data

    preferredLang = m.current_srt_lang
    user = CreateObject("roRegistrySection", "User")
    if (preferredLang = invalid or preferredLang = "") and user.Exists("select_subtitle_lang")
        preferredLang = user.Read("select_subtitle_lang")
    end if

    selectedSub = invalid
    if preferredLang <> invalid and preferredLang <> ""
        for each group in data.list
            groupLang = ""
            if group.language <> invalid
                groupLang = group.language
            end if
            if video_play_subtitle_group_matches(group, preferredLang) and group.subtitles <> invalid and group.subtitles.Count() > 0
                selectedSub = group.subtitles[0]
                exit for
            end if
        end for
    end if

    if selectedSub <> invalid
        m.srt_source_delay = subtitleDelaySeconds(selectedSub.delay)
        m.current_srt = selectedSub.sid
        if selectedSub.lang <> invalid
            m.current_srt_lang = selectedSub.lang
        else if selectedSub.language <> invalid
            m.current_srt_lang = selectedSub.language
        end if
        data["select"] = selectedSub
        getsrtContent(selectedSub.file_path)
    else
        m.current_srt = invalid
        m.current_srt_lang = invalid
        m.srt_source_delay = 0.0
        m.srtMap = []
        m.subbg.visible = false
        m.lastSubtitleText = ""
        data["select"] = {"sid":0}
        user.Delete("select_subtitle_lang")
        user.Flush()
    end if

    if m.videoset <> invalid
        m.videoset.content = m.videoinfo
        m.videoset.callFunc("refreshSubtitleContent")
    end if
end sub

function subtitleSyncLabel() as String
    value = m.srt_manual_delay
    if value = invalid
        value = 0.0
    end if
    prefix = ""
    if value > 0
        prefix = "+"
    end if
    return prefix + value.ToStr() + " S"
end function

sub applySubtitleAppearance()
    if m.subtitleBgOpacity = invalid
        m.subtitleBgOpacity = 65
    end if
    if m.subtitleTextOpacity = invalid
        m.subtitleTextOpacity = 100
    end if
    if m.subtitleBgOpacity < 0
        m.subtitleBgOpacity = 0
    else if m.subtitleBgOpacity > 100
        m.subtitleBgOpacity = 100
    end if
    if m.subtitleTextOpacity < 20
        m.subtitleTextOpacity = 20
    else if m.subtitleTextOpacity > 100
        m.subtitleTextOpacity = 100
    end if
    if m.srt_bg22 <> invalid
        m.srt_bg22.color = "0x000000FF"
        m.srt_bg22.opacity = m.subtitleBgOpacity / 100.0
    end if
    if m.subtext <> invalid
        m.subtext.opacity = m.subtitleTextOpacity / 100.0
    end if
    if m.textshadow <> invalid
        m.textshadow.opacity = m.subtitleTextOpacity / 100.0
    end if
end sub

sub updateSubtitleAppearanceLabels()
    if m.srt_bg_opacity_txt <> invalid
        m.srt_bg_opacity_txt.text = m.subtitleBgOpacity.ToStr() + "%"
    end if
    if m.srt_text_opacity_txt <> invalid
        m.srt_text_opacity_txt.text = m.subtitleTextOpacity.ToStr() + "%"
    end if
end sub

sub srt_bg_opacity_change()
    if videoSettingsModalIsActive() = false
        return
    end if
    if m.subtitle_bg_opacity = invalid
        return
    end if
    if m.subtitle_bg_opacity.itemSelected = 0
        m.subtitleBgOpacity = m.subtitleBgOpacity - 10
    else
        m.subtitleBgOpacity = m.subtitleBgOpacity + 10
    end if
    if m.subtitleBgOpacity < 0
        m.subtitleBgOpacity = 0
    else if m.subtitleBgOpacity > 100
        m.subtitleBgOpacity = 100
    end if
    applySubtitleAppearance()
    updateSubtitleAppearanceLabels()
    user = CreateObject("roRegistrySection", "User")
    user.Write("subtitle_bg_opacity", m.subtitleBgOpacity.ToStr())
    user.Flush()
end sub

sub srt_text_opacity_change()
    if videoSettingsModalIsActive() = false
        return
    end if
    if m.subtitle_text_opacity = invalid
        return
    end if
    if m.subtitle_text_opacity.itemSelected = 0
        m.subtitleTextOpacity = m.subtitleTextOpacity - 10
    else
        m.subtitleTextOpacity = m.subtitleTextOpacity + 10
    end if
    if m.subtitleTextOpacity < 20
        m.subtitleTextOpacity = 20
    else if m.subtitleTextOpacity > 100
        m.subtitleTextOpacity = 100
    end if
    applySubtitleAppearance()
    updateSubtitleAppearanceLabels()
    user = CreateObject("roRegistrySection", "User")
    user.Write("subtitle_text_opacity", m.subtitleTextOpacity.ToStr())
    user.Flush()
end sub

function video_play_find_current_source() as Object
    if m.videoinfo = invalid or m.videoinfo.list = invalid or m.video = invalid or m.video.content = invalid
        return invalid
    end if
    currentUrl = m.video.content.url
    if currentUrl = invalid
        currentUrl = ""
    end if
    for each item in m.videoinfo.list
        itemUrl = ""
        if item.path <> invalid and item.path <> ""
            itemUrl = item.path
        else if item.m3u8_url <> invalid and item.m3u8_url <> ""
            itemUrl = item.m3u8_url
        end if
        if itemUrl <> "" and itemUrl = currentUrl
            return item
        end if
    end for
    return invalid
end function

sub video_play_sync_audio_stream_url()
    if m.videoset = invalid or m.video = invalid or m.video.content = invalid
        return
    end if
    if m.video.content.url <> invalid
        m.videoset.audioStreamUrl = m.video.content.url
    end if
    video_play_sync_current_audio_list()
end sub

sub video_play_sync_current_audio_list()
    if m.videoset = invalid or m.videoinfo = invalid or m.videoinfo.list = invalid
        return
    end if
    currentUrl = ""
    if m.video.content <> invalid and m.video.content.url <> invalid
        currentUrl = m.video.content.url
    end if
    audioList = []
    sourceIndex = 0
    matched = false
    if m.vlist <> invalid and m.vlist.content <> invalid
        for i = 0 to m.vlist.content.getChildCount() - 1
            child = m.vlist.content.getChild(i)
            if child.SecondaryTitle = "true" and i < m.videoinfo.list.Count()
                item = m.videoinfo.list[i]
                if item.audio_list <> invalid
                    audioList = item.audio_list
                end if
                if item.source_index <> invalid
                    sourceIndex = item.source_index
                end if
                matched = true
                exit for
            end if
        end for
    end if
    if matched = false
        for each item in m.videoinfo.list
            itemUrl = ""
            if item.path <> invalid and item.path <> ""
                itemUrl = item.path
            else if item.m3u8_url <> invalid and item.m3u8_url <> ""
                itemUrl = item.m3u8_url
            end if
            if itemUrl <> "" and itemUrl = currentUrl
                if item.audio_list <> invalid
                    audioList = item.audio_list
                end if
                if item.source_index <> invalid
                    sourceIndex = item.source_index
                end if
                exit for
            end if
        end for
    end if
    m.videoset.currentAudioList = audioList
    m.videoset.currentSourceIndex = sourceIndex
    sourceCount = 1
    if m.videoinfo.source_count <> invalid and m.videoinfo.source_count > 0
        sourceCount = m.videoinfo.source_count
    end if
    m.videoset.sourceCount = sourceCount
end sub

function video_play_api_lang(apiItem as Object) as String
    if apiItem = invalid
        return ""
    end if
    if apiItem.language <> invalid and apiItem.language <> ""
        return apiItem.language
    end if
    if apiItem.lang <> invalid and apiItem.lang <> ""
        return apiItem.lang
    end if
    if apiItem.audio_lang <> invalid and apiItem.audio_lang <> ""
        return apiItem.audio_lang
    end if
    return ""
end function

function video_play_api_name(apiItem as Object) as String
    if apiItem = invalid
        return ""
    end if
    if apiItem.title <> invalid and apiItem.title <> ""
        return apiItem.title
    end if
    if apiItem.name <> invalid and apiItem.name <> ""
        return apiItem.name
    end if
    if apiItem.quality <> invalid and apiItem.quality <> "" and apiItem.quality <> "audio"
        return apiItem.quality
    end if
    return ""
end function

function video_play_track_lang(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Language <> invalid and track.Language <> ""
        return track.Language
    end if
    if track.lang <> invalid and track.lang <> ""
        return track.lang
    end if
    return ""
end function

function video_play_track_name(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Name <> invalid and track.Name <> ""
        return track.Name
    end if
    if track.Track <> invalid and track.Track <> ""
        return track.Track
    end if
    return ""
end function

function video_play_track_matches_api(track as Object, apiItem as Object) as Boolean
    apiLang = video_play_api_lang(apiItem)
    apiName = video_play_api_name(apiItem)
    trackLang = video_play_track_lang(track)
    trackName = video_play_track_name(track)
    if apiLang <> "" and trackLang <> ""
        if LCase(apiLang) <> LCase(trackLang)
            return false
        end if
    end if
    if apiName <> "" and trackName <> ""
        if LCase(apiName) <> LCase(trackName)
            return false
        end if
    end if
    return apiLang <> "" or apiName <> ""
end function

function video_play_audio_track_key(track as Object) as String
    if track = invalid
        return ""
    end if
    trackId = video_play_audio_track_id(track)
    if trackId <> ""
        return LCase(trackId)
    end if
    lang = video_play_track_lang(track)
    name = video_play_track_name(track)
    if lang <> "" or name <> ""
        return LCase(lang + "|" + name)
    end if
    return ""
end function

function video_play_resolve_audio_tracks(tracks as Object) as Object
    if tracks = invalid
        return []
    end if
    result = []
    for i = 0 to tracks.Count() - 1
        result.Push(tracks[i])
    end for
    return result
end function

function video_play_audio_track_id(track as Object) as String
    if track = invalid
        return ""
    end if
    if track.Track <> invalid and track.Track <> ""
        val = track.Track
        if Type(val) = "roString" or Type(val) = "String"
            return val
        end if
        return val.toStr()
    end if
    return ""
end function

sub video_play_apply_saved_audio_track()
    if m.videoset = invalid
        return
    end if
    streamUrl = m.videoset.audioStreamUrl
    if streamUrl = invalid or streamUrl = ""
        return
    end if
    if m.audio_track_applied = streamUrl
        return
    end if
    if m.video.content = invalid or m.video.content.url = invalid
        return
    end if
    if m.video.content.url <> streamUrl
        return
    end if
    tracks = video_play_resolve_audio_tracks(m.video.availableAudioTracks)
    if tracks.Count() <= 1
        m.audio_track_applied = streamUrl
        return
    end if
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("select_audio_track")
        savedId = user.Read("select_audio_track")
        for each track in tracks
            trackId = video_play_audio_track_id(track)
            if trackId <> "" and trackId = savedId
                m.video.audioTrack = trackId
                m.videoset.selectedAudioTrackId = trackId
                m.audio_track_applied = streamUrl
                return
            end if
        end for
    else if user.Exists("select_audio_lang")
        savedLang = user.Read("select_audio_lang")
        for each track in tracks
            if track.Language = savedLang or track.lang = savedLang
                trackId = video_play_audio_track_id(track)
                if trackId <> ""
                    m.video.audioTrack = trackId
                    m.videoset.selectedAudioTrackId = trackId
                    m.audio_track_applied = streamUrl
                    return
                end if
            end if
        end for
    end if
    defaultTrackId = video_play_audio_track_id(tracks[0])
    if defaultTrackId <> ""
        m.videoset.selectedAudioTrackId = defaultTrackId
    end if
    m.audio_track_applied = streamUrl
end sub

function video_play_resolve_item_track_id(trackId as String) as String
    if trackId = ""
        return ""
    end if
    if Left(trackId, 4) = "api_"
        apiIndex = trackId.Replace("api_", "").ToInt()
        tracks = video_play_resolve_audio_tracks(m.video.availableAudioTracks)
        if apiIndex >= 0 and apiIndex < tracks.Count()
            resolvedId = video_play_audio_track_id(tracks[apiIndex])
            if resolvedId <> ""
                return resolvedId
            end if
        end if
        return trackId
    end if
    if Left(trackId, 4) = "idx_"
        trackIndex = trackId.Replace("idx_", "").ToInt()
        tracks = video_play_resolve_audio_tracks(m.video.availableAudioTracks)
        if trackIndex >= 0 and trackIndex < tracks.Count()
            resolvedId = video_play_audio_track_id(tracks[trackIndex])
            if resolvedId <> ""
                return resolvedId
            end if
        end if
        return trackId
    end if
    return trackId
end function

sub setaudio()
    if videoSettingsModalIsActive() = false
        return
    end if
    if m.videoset = invalid or m.videoset.visible <> true
        return
    end if
    audios = m.videoset.FindNode("audios")
    if audios = invalid or audios.visible <> true
        return
    end if
    if m.videoset.audioTrackRefreshing = true
        return
    end if
    if m.audiolist.content = invalid
        return
    end if
    index = m.videoset.audioSelectIndex
    if index = invalid or index < 0
        return
    end if
    item = m.audiolist.content.getChild(index)
    if item = invalid or item.id = invalid
        return
    end if
    trackId = item.id
    if Type(trackId) <> "roString" and Type(trackId) <> "String"
        trackId = trackId.toStr()
    end if
    if trackId = ""
        return
    end if
    trackId = video_play_resolve_item_track_id(trackId)
    if trackId = ""
        return
    end if
    currentTrack = m.video.audioTrack
    if currentTrack <> invalid and currentTrack <> "" and currentTrack = trackId
        m.videoset.audioSelectIndex = -1
        closeVideoSettings(true)
        return
    end if
    for i = 0 to m.audiolist.content.getChildCount() - 1
        row = m.audiolist.content.getChild(i)
        if i = index
            row.update({"SecondaryTitle":"true"}, false)
        else
            row.update({"SecondaryTitle":"false"}, false)
        end if
    end for
    m.video.audioTrack = trackId
    m.videoset.selectedAudioTrackId = trackId
    user = CreateObject("roRegistrySection", "User")
    user.Write("select_audio_track", trackId)
    tracks = video_play_resolve_audio_tracks(m.video.availableAudioTracks)
    for each track in tracks
        tid = video_play_audio_track_id(track)
        if tid = trackId
            if track.Language <> invalid
                user.Write("select_audio_lang", track.Language)
            else if track.lang <> invalid
                user.Write("select_audio_lang", track.lang)
            end if
            exit for
        end if
    end for
    m.videoset.audioSelectIndex = -1
    closeVideoSettings(true)
end sub

function getsrtContent(url as string)
    if m.readContentTask <> invalid
        m.readContentTask.unobserveField("content")
        m.readContentTask.control = "STOP"
        m.readContentTask = invalid
    end if
    m.readContentTask = createObject("RoSGNode","ReadsrtFile")
    m.readContentTask.content = url
    m.readContentTask.observeField("content", "getSrt2")
    m.readContentTask.control = "RUN"
end function

function getSrt2()
    srt = m.readContentTask.content
    getSrt(srt,1)
    m.subbg = m.top.FindNode("subbg")
    m.subtext = m.top.FindNode("subtext")
    m.textshadow = m.top.FindNode("textshadow")
end function

function srtSet()
    srt = m.videoset.srt_con
    getSrt(srt,1)
    if m.videoset.srt_sid <> invalid and m.videoset.srt_sid <> ""
        m.current_srt = m.videoset.srt_sid
        sidInt = 0
        sidType = Type(m.current_srt)
        if sidType = "roString" or sidType = "String"
            sidInt = m.current_srt.ToInt()
        else
            sidInt = m.current_srt
        end if
        if m.videoinfo <> invalid and m.videoinfo.subtitle_list <> invalid
            if m.videoinfo.subtitle_list.select = invalid
                m.videoinfo.subtitle_list["select"] = {"sid": sidInt}
            else
                m.videoinfo.subtitle_list.select.sid = sidInt
            end if
        end if
    end if
    if m.videoset.srt_lang <> invalid and m.videoset.srt_lang <> ""
        m.current_srt_lang = m.videoset.srt_lang
    end if
    m.srt_btn2.visible = true
    m.subbg = m.top.FindNode("subbg")
    m.subtext = m.top.FindNode("subtext")
    m.textshadow = m.top.FindNode("textshadow")
end function

' 获取并处理外挂字幕
function getSrt(srtText as string, index as integer)
    m.srtMap = []
    if srtText <> invalid
        srtItem = ParseSRT(srtText)
        m.srtMap[index] = srtItem
    end if
end function

'将 srt 文本转化为字幕数组
function createSrtArr(srt as string) as Object
    ' arr = srt.Split(chr(10)+chr(10))
    reg = CreateObject("roRegex", "\n\n|\r\r|\r\n\r\n", "")
    arr = reg.Split(srt)
    if arr.Count() < 2
        arr = srt.Split(chr(10)+chr(13)+chr(10))
        if arr.Count() < 2
            arr = {}
        end if
    end if
    result = []
    r = CreateObject("roRegex", "<font[^>]*>", "i")

    for each item in arr
        srtObj = {}
        item = item.Trim()
        containArr = item.Split(chr(10))

        if containArr[1] <> invalid
            containArr[1] = containArr[1].Trim()
            reg = CreateObject("roRegex", "^(\d{1,2}):(\d{2}):(\d{2})[\.,](\d{1,3}) --\> (\d{1,2}):(\d{2}):(\d{2})[\.,](\d{1,3})", "g")
            regResult = reg.Match(containArr[1])
            if regResult.Count() = 0
                regResult = reg.Match(containArr[2])
                containArr.shift()
            end if
            
            if regResult <> invalid and regResult.Count() > 0
                timeSplit = regResult[0].Split(" --> ")
                srtObj.from = GetSeconds(timeSplit[0])
                srtObj.to = GetSeconds(timeSplit[1])
                srtObj.Text = containArr.Slice(2).Join(chr(10))
                srtObj.Text = r.ReplaceAll(srtObj.Text, "")
                srtObj.Text = srtObj.Text.Replace("</font>", "")
                ' print srtObj
                result.Push(srtObj)
            end if
        end if
    end for

    return result
end function

function ParseSRT(srtContent As String) As Object
    subtitleList = []
    if srtContent = invalid or srtContent = ""
        return subtitleList
    end if

    clean = srtContent.Replace(chr(13), "")
    lines = clean.Split(chr(10))
    tagRegex = CreateObject("roRegex", "<[^>]+>", "i")

    i = 0
    while i < lines.Count()
        line = lines[i].Trim()
        if line = "" or UCase(line) = "WEBVTT"
            i = i + 1
            continue while
        end if

        timeIndex = -1
        if line.Instr("-->") > 0
            timeIndex = i
        else if i + 1 < lines.Count() and lines[i + 1].Instr("-->") > 0
            timeIndex = i + 1
        end if

        if timeIndex < 0
            i = i + 1
            continue while
        end if

        timeRange = lines[timeIndex].Trim()
        timeParts = timeRange.Split("-->")
        if timeParts.Count() < 2
            i = timeIndex + 1
            continue while
        end if

        startTime = GetSeconds(timeParts[0].Trim())
        endToken = timeParts[1].Trim()
        spaceAt = endToken.Instr(" ")
        if spaceAt > 0
            endToken = Left(endToken, spaceAt)
        end if
        endTime = GetSeconds(endToken)

        subtitleText = ""
        j = timeIndex + 1
        while j < lines.Count()
            textLine = lines[j].Replace(chr(13), "")
            trimmed = textLine.Trim()
            if trimmed = ""
                exit while
            end if
            if trimmed.Instr("-->") > 0
                exit while
            end if
            if trimmed.ToInt() > 0 and j + 1 < lines.Count() and lines[j + 1].Instr("-->") > 0
                exit while
            end if
            if m.current_srt_lang = "ar"
                textLine = tagRegex.ReplaceAll(textLine, "")
                textLine = ReverseString(textLine)
            end if
            if subtitleText <> ""
                subtitleText = subtitleText + chr(10)
            end if
            subtitleText = subtitleText + textLine
            j = j + 1
        end while

        subtitleText = subtitleText.Trim()
        subtitleText = tagRegex.ReplaceAll(subtitleText, "")
        if subtitleText <> "" and endTime >= startTime
            subtitleObj = {
                "from": startTime,
                "to": endTime,
                "Text": subtitleText
            }
            subtitleList.Push(subtitleObj)
        end if

        if j <= timeIndex
            i = timeIndex + 1
        else if j < lines.Count() and lines[j].Trim().Instr("-->") > 0
            i = j
        else
            i = j + 1
        end if
    end while

    return subtitleList
end function

function GetSeconds(val as string) as Float
    if val = invalid
        return 0.0
    end if
    value = val.Trim()
    if value = ""
        return 0.0
    end if

    ' Strip WebVTT cue settings if they are present after the end timestamp.
    spaceAt = value.Instr(" ")
    if spaceAt > 0
        value = Left(value, spaceAt)
    end if

    reg = CreateObject("roRegex", "\,|\.", "")
    parts = reg.Split(value)
    base = parts[0]
    frac = 0.0
    if parts.Count() > 1
        digits = parts[1].Trim()
        if Len(digits) = 1
            frac = digits.ToFloat() / 10.0
        else if Len(digits) = 2
            frac = digits.ToFloat() / 100.0
        else if Len(digits) > 2
            frac = Left(digits, 3).ToFloat() / 1000.0
        end if
    end if

    fields = base.Split(":")
    sec = 0.0
    if fields.Count() >= 3
        sec = fields[0].ToFloat() * 3600.0 + fields[1].ToFloat() * 60.0 + fields[2].ToFloat()
    else if fields.Count() = 2
        sec = fields[0].ToFloat() * 60.0 + fields[1].ToFloat()
    else if fields.Count() = 1
        sec = fields[0].ToFloat()
    end if
    return sec + frac
end function

function ReverseString(s as String) as String
    reversed = ""
    for i = Len(s) to 1 step -1
        reversed = reversed + Mid(s, i, 1)
    end for
    return reversed
end function

' 获取当前时间对应的字幕内容
function getSubtitle(currentTime as Float, arr as Object) as string
    if arr = invalid or arr.Count() = 0
        return ""
    end if
    low = 0
    high = arr.Count() - 1

    while low <= high
        mid = Int((low + high) / 2)
        cue = arr[mid]
        if cue.from <= currentTime and cue.to >= currentTime
            return cue.Text
        else if cue.from > currentTime
            high = mid - 1
        else
            low = mid + 1
        end if
    end while
    return ""
end function

function subtitleDelaySeconds(value as Dynamic) as Float
    if value = invalid
        return 0.0
    end if
    t = Type(value)
    if t = "roString" or t = "String"
        if value = ""
            return 0.0
        end if
        return value.ToFloat()
    end if
    return value * 1.0
end function

function onPositionChanged(event as object)
    newPosition = event.getData()
    cp_onPosition(newPosition)
    if newPosition <> invalid and newPosition >= 0
        m.lastPlayablePosition = newPosition
        if m.bufferRetryCount > 0 and newPosition - m.lastRecoveryPosition >= 30
            m.bufferRetryCount = 0
        end if
    end if

    if isSkipIntroOutroEnabled() and m.video.duration > 0 and m.skip_end > 0 and m.close_skiptip = 0 and m.skiptip_end.visible = false
        if m.video.duration - newPosition <= m.skip_end
            m.skip_text2.text = "Skip Ending "+m.skip_end.ToStr()+"S,"
            m.skiptip_end.visible = true
        end if
    end if

    if m.srtMap <> invalid and m.srtMap.Count() > 1 and m.srtMap[1] <> invalid
        subtitlePosition = newPosition + subtitleDelaySeconds(m.srt_source_delay) - subtitleDelaySeconds(m.srt_manual_delay)
        text = getSubtitle(subtitlePosition, m.srtMap[1])
        if text = ""
            m.subbg.visible = false
            m.lastSubtitleText = ""
        else
            m.subbg.visible = true
            if text <> m.lastSubtitleText
                m.lastSubtitleText = text
                updateSubtitleLayout(text)
            end if
        end if
    end if
end function

sub applyPendingResumeSeek()
    if m.resumeSeekTarget = invalid or m.resumeSeekTarget <= 0
        return
    end if
    if m.resumeSeekTries = invalid
        m.resumeSeekTries = 0
    end if
    if m.resumeSeekTries >= 3
        m.resumeSeekTarget = 0
        return
    end if
    curPos = 0
    if m.video.position <> invalid
        curPos = m.video.position
    end if
    if m.resumeSeekTarget - curPos > 5
        m.video.seek = m.resumeSeekTarget
        m.resumeSeekTries = m.resumeSeekTries + 1
    else
        m.resumeSeekTarget = 0
    end if
end sub

sub restartBufferWatchdog()
    if m.bufferWatchdog = invalid
        return
    end if
    m.bufferWatchdog.control = "stop"
    m.bufferWatchdog.duration = 18
    m.bufferWatchdog.control = "start"
    m.bufferWatchdogActive = true
end sub

sub onBufferingStatusChanged(event as Object)
    status = event.getData()
    cp_onBufferStatus(status)
    if m.video.state <> "buffering"
        return
    end if
    if status = invalid or status.percentage = invalid
        return
    end if
    percent = status.percentage
    if percent > m.lastBufferPercent
        m.lastBufferPercent = percent
        ' Only recover when buffering has actually stopped making progress.
        restartBufferWatchdog()
    end if
end sub

sub onBufferWatchdog()
    m.bufferWatchdogActive = false
    if m.video = invalid or m.video.state <> "buffering"
        return
    end if
    if m.bufferRetryCount >= 2
        ' A stream that never makes buffering progress is frequently a container/
        ' codec variant Roku cannot actually start. Try another compatible source
        ' before surfacing a terminal stall.
        if video_play_try_failover("buffering")
            return
        end if
        m.video.control = "stop"
        cp_onBufferStatus(invalid)
        cp_showUi("STREAM STALLED")
        cp_showToast("No compatible source left - Down opens settings")
        return
    end if

    source = video_play_find_current_source()
    if source = invalid
        return
    end if

    resumeAt = m.lastPlayablePosition
    if m.video.position <> invalid and m.video.position > resumeAt
        resumeAt = m.video.position
    end if
    if resumeAt < 0
        resumeAt = 0
    end if

    m.bufferRetryCount = m.bufferRetryCount + 1
    m.lastRecoveryPosition = resumeAt
    m.lastBufferPercent = -1
    replacement = video_play_make_content(source, resumeAt)

    m.video.control = "stop"
    m.video.content = replacement
    m.resumeSeekTarget = resumeAt
    m.resumeSeekTries = 0
    m.video.control = "play"
end sub

sub controlvideoplay()
    state = m.video.state
    cp_onState(state)
    if state = "finished"
        m.skiptip.visible = false
        m.skiptip_end.visible = false
        m.bufferWatchdog.control = "stop"
        m.bufferWatchdogActive = false
        if isNaturalPlaybackFinish(m.video) = false
            if video_play_try_failover("premature finish")
                return
            end if
            cp_showUi("SOURCE ENDED EARLY")
            cp_showToast("No compatible source left - Down opens settings")
        end if
    else if state = "playing"
        m.bufferWatchdog.control = "stop"
        m.bufferWatchdogActive = false
        m.lastBufferPercent = -1
        applyPendingResumeSeek()
        video_play_sync_current_audio_list()
        video_play_apply_saved_audio_track()
        if m.videoset <> invalid and m.videoset.visible = true and m.videoset.FindNode("audios").visible <> true
            m.videoset.callFunc("updateAudioTabs")
        end if
    else if state = "buffering"
        applyPendingResumeSeek()
        if m.bufferWatchdogActive = false
            restartBufferWatchdog()
        end if
    else if state = "error"
        m.bufferWatchdog.control = "stop"
        m.bufferWatchdogActive = false
        if video_play_try_failover("error")
            return
        end if
        cp_showUi("UNSUPPORTED / PLAYBACK ERROR")
        cp_showToast("No compatible source left - Down opens settings")
    else if state = "stopped"
        m.bufferWatchdog.control = "stop"
        m.bufferWatchdogActive = false
    end if
end sub

sub srtselected()
    if videoSettingsModalIsActive() = false
        return
    end if
    if m.subtitles = invalid or m.subtitles.content = invalid
        return
    end if
    idx = m.subtitles.itemSelected
    if idx = invalid or idx < 0 or idx >= m.subtitles.content.getChildCount()
        return
    end if
    info = m.subtitles.content.getChild(idx)
    if info = invalid
        return
    end if

    if info.id = "0" or (info.data <> invalid and info.data.is_off = true)
        disableSubtitles(true)
        return
    end if

    for i = 0 to m.subtitles.content.getChildCount() - 1
        tt = m.subtitles.content.getChild(i)
        if tt.SecondaryTitle = "true"
            tt.update({"SecondaryTitle":"false"}, false)
        end if
    end for
    info.update({"SecondaryTitle":"true"}, false)
    sid = info.id
    if m.videoinfo.subtitle_list.select = invalid or Type(m.videoinfo.subtitle_list.select) = "roArray"
        m.videoinfo.subtitle_list["select"] = {"sid":sid.ToInt()}
    else
        m.videoinfo.subtitle_list.select.sid = sid.ToInt()
    end if
    user = CreateObject("roRegistrySection", "User")
    user.Write("select_subtitle_lang", info.data["language"])
    user.Flush()
    m.videoset.content = m.videoinfo
    closeVideoSettings(true)
    m.srt_source_delay = subtitleDelaySeconds(info.data["delay"])
    m.current_srt = sid
    m.current_srt_lang = info.data["language"]
    getsrtContent(info.Description)
    m.srt_time.text = subtitleSyncLabel()
    m.srt_btn2.visible = true
    subtitle_select(sid)
end sub

sub subtitle_select(sid)
    arr = {}
    for each key in m.videoinfo.moviedata
        arr[key] = m.videoinfo.moviedata[key]
    end for
    arr["sid"] = sid
    arr["type"] = "sub_select"
    
    m.selectContentTask = createObject("RoSGNode","GetContentReader")
    m.selectContentTask.content = arr
    m.selectContentTask.control = "RUN"
end sub

sub disableSubtitles(notifyServer as Boolean)
    sid = m.current_srt
    if m.readContentTask <> invalid
        m.readContentTask.unobserveField("content")
        m.readContentTask.control = "STOP"
        m.readContentTask = invalid
    end if
    if m.subtitles <> invalid and m.subtitles.content <> invalid
        for i = 0 to m.subtitles.content.getChildCount() - 1
            tt = m.subtitles.content.getChild(i)
            if tt.id = "0"
                tt.update({"SecondaryTitle":"true"}, false)
            else if tt.SecondaryTitle = "true"
                tt.update({"SecondaryTitle":"false"}, false)
            end if
        end for
    end if
    m.current_srt = invalid
    m.current_srt_lang = invalid
    m.srt_source_delay = 0.0
    m.subbg.visible = false
    m.lastSubtitleText = ""
    m.srtMap = []
    if m.videoinfo <> invalid and m.videoinfo.subtitle_list <> invalid
        m.videoinfo.subtitle_list["select"] = {"sid":0}
    end if
    user = CreateObject("roRegistrySection", "User")
    user.Delete("select_subtitle_lang")
    user.Flush()
    if m.videoset <> invalid
        m.videoset.content = m.videoinfo
        m.videoset.callFunc("refreshSubtitleContent")
        wasVisible = m.videoset.visible
        closeVideoSettings(wasVisible)
    end if
    if m.sub_settingbg <> invalid
        m.sub_settingbg.visible = false
    end if
    if m.settingbg <> invalid
        m.settingbg.visible = true
    end if
    cp_takeFocus()

    if notifyServer and sid <> invalid and m.videoinfo <> invalid and m.videoinfo.moviedata <> invalid
        arr = {}
        for each key in m.videoinfo.moviedata
            arr[key] = m.videoinfo.moviedata[key]
        end for
        arr["sid"] = sid
        arr["type"] = "sub_select_del"
        m.selectContentTask2 = createObject("RoSGNode", "GetContentReader")
        m.selectContentTask2.content = arr
        m.selectContentTask2.control = "RUN"
    end if
end sub

sub close_subtitle()
    if videoSettingsModalIsActive() = false
        return
    end if
    index = m.subtitle_btns.itemSelected
    if index = 4
        disableSubtitles(true)
    end if
end sub

sub srt_delay()
    if videoSettingsModalIsActive() = false
        return
    end if
    index = m.subtitle_delay.itemSelected
    m.srt_manual_delay = subtitleDelaySeconds(m.srt_manual_delay)
    if index = 0
        m.srt_manual_delay = m.srt_manual_delay - 0.25
    else
        m.srt_manual_delay = m.srt_manual_delay + 0.25
    end if
    if m.srt_manual_delay < -30
        m.srt_manual_delay = -30
    else if m.srt_manual_delay > 30
        m.srt_manual_delay = 30
    end if
    if m.srt_time <> invalid
        m.srt_time.text = subtitleSyncLabel()
    end if
    user = CreateObject("roRegistrySection", "User")
    user.Write("subtitle_manual_delay", m.srt_manual_delay.ToStr())
    user.Flush()
end sub

' Retained for compatibility with older callbacks. Delay is now a local sync
' preference; it is intentionally no longer written back to MovieBoxPro.
sub subtitle_delay()
end sub

sub srt_size2()
    if videoSettingsModalIsActive() = false
        return
    end if
    index = m.subtitle_size.itemSelected
    if m.srt_size = invalid
        m.srt_size = 28
    end if
    if index = 0
        m.srt_size = m.srt_size - 1
    else
        m.srt_size = m.srt_size + 1
    end if
    m.srt_sizetxt.text = m.srt_size.ToStr()
    m.fontshadow.size = m.srt_size + 1
    m.subfont.size = m.srt_size
    m.measureFontCache = {}
    if m.lastSubtitleText <> invalid and m.lastSubtitleText <> ""
        updateSubtitleLayout(m.lastSubtitleText)
    end if
    print m.srt_size
    user = CreateObject("roRegistrySection", "User")
    user.Write("srt_size", m.srt_size.ToStr())
end sub

function lookupSubtitleFontFamily(ttf as String) as String
    if m.font_list = invalid or m.font_list.content = invalid
        return m.subtitleFontFamily
    end if
    for i = 0 to m.font_list.content.getChildCount() - 1
        item = m.font_list.content.getChild(i)
        if item.Description = ttf
            return item.title
        end if
    end for
    return m.subtitleFontFamily
end function

sub srt_font2()
    if videoSettingsModalIsActive() = false
        return
    end if
    font = m.font_list.content.getChild(m.font_list.itemSelected)
    if font.title = "default"
        m.fontshadow.uri = "pkg:/images/arial_unicode_ms.ttf"
        m.subfont.uri = "pkg:/images/arial_unicode_ms.ttf"
        m.subtitleFontFamily = "Arial Unicode MS"
        user = CreateObject("roRegistrySection", "User")
        user.Delete("srt_font")
    else
        ttf = font.Description
        m.fontshadow.uri = "pkg:/images/"+ttf
        m.subfont.uri = "pkg:/images/"+ttf
        m.subtitleFontFamily = font.title
        user = CreateObject("roRegistrySection", "User")
        user.Write("srt_font", ttf)
    end if
    m.measureFontCache = {}
    if m.lastSubtitleText <> invalid and m.lastSubtitleText <> ""
        updateSubtitleLayout(m.lastSubtitleText)
    end if
end sub

sub srt_move()
    if videoSettingsModalIsActive() = false
        return
    end if
    index = m.subtitle_move.itemSelected
    if m.srt_position = invalid
        m.srt_position = 570
    end if
    if index = 0
        m.srt_position = m.srt_position - 8
    else
        m.srt_position = m.srt_position + 8
    end if
    if m.srt_position < 0
        m.srt_position = 0
    else if m.srt_position > 690
        m.srt_position = 690
    end if

    user = CreateObject("roRegistrySection", "User")
    user.Write("srt_position", m.srt_position.ToStr())
    if m.lastSubtitleText <> invalid and m.lastSubtitleText <> ""
        updateSubtitleLayout(m.lastSubtitleText)
    else
        centerX = m.subbg.translation[0]
        m.subbg.translation = [centerX, m.srt_position]
    end if
end sub

sub hideskip()
    m.skiptip.visible = false
end sub

sub openSkipSetting()
    if m.videoset.skip_request <> true
        return
    end if
    m.videoset.skip_request = false
    showSkipSettingModal("start")
end sub

sub openEpisodePanel()
    if m.videoset = invalid or m.videoset.episode_request <> true
        return
    end if
    m.videoset.episode_request = false
    showEpisodePanel()
end sub

sub showEpisodePanel()
    arr = m.videoinfo.moviedata
    if arr = invalid or arr.box_type <> 2
        return
    end if

    if m.episodeSetting = invalid
        m.episodeSetting = createObject("roSGNode", "EpisodeSetting")
        m.episodeSetting.id = "episodeSetting"
        m.episodeSetting.observeField("play_episode", "onEpisodePlaySelected")
        m.top.appendChild(m.episodeSetting)
    end if

    if m.videoset <> invalid
        m.videoset.visible = false
    end if
    m.skiptip.visible = false
    m.skiptip_end.visible = false

    season = 1
    episode = 1
    mid = 0
    if m.activePlaySeason <> invalid
        season = m.activePlaySeason
    else if arr.season <> invalid
        season = arr.season
    end if
    if m.activePlayEpisode <> invalid
        episode = m.activePlayEpisode
    else if arr.episode <> invalid
        episode = arr.episode
    end if
    if arr.mid <> invalid
        mid = arr.mid
    end if

    payload = {
        "mid": mid,
        "season": season,
        "play_season": season,
        "play_episode": episode
    }
    if m.cachedSeasonMid <> invalid and m.cachedSeasonMid <> mid
        m.cachedSeasons = []
    end if
    m.cachedSeasonMid = mid
    if arr.season_list <> invalid
        payload["seasons"] = arr.season_list
        m.cachedSeasons = arr.season_list
    else if m.cachedSeasons <> invalid and m.cachedSeasons.Count() > 0
        payload["seasons"] = m.cachedSeasons
    end if
    if arr.max_season <> invalid
        payload["max_season"] = arr.max_season
    end if
    m.episodeSetting.content = payload
    m.episodeSetting.visible = true
    m.episodeSetting.setFocus(true)
end sub

sub onEpisodePlaySelected()
    if m.episodeSetting = invalid
        return
    end if
    ep = m.episodeSetting.play_episode
    if ep = invalid
        return
    end if
    m.top.play_episode = ep
end sub

sub showSkipSettingModal(defaultType as String)
    arr = m.videoinfo.moviedata
    if arr.box_type <> 2
        return
    end if

    if m.skipSetting = invalid
        m.skipSetting = createObject("roSGNode", "SkipSetting")
        m.skipSetting.id = "skipSetting"
        m.skipSetting.observeField("saved", "onSkipSettingSaved")
        m.skipSetting.observeField("visible", "onSkipSettingVisibleChanged")
        m.top.appendChild(m.skipSetting)
    end if

    skips = m.videoinfo.skips
    if skips = invalid
        skips = {"start": 0, "end": 0}
    end if

    m.video.control = "pause"
    m.skipSettingHandled = false
    m.skipSettingFlowActive = true
    m.videosetWasVisibleBeforeSkip = false
    if m.settingsModalActive = true or (m.videoset <> invalid and m.videoset.visible = true)
        m.videosetWasVisibleBeforeSkip = true
    end if
    m.videoset.visible = false
    m.skiptip.visible = false
    m.skiptip_end.visible = false

    skipFid = ""
    if m.videoinfo.active_fid <> invalid and m.videoinfo.active_fid <> ""
        skipFid = m.videoinfo.active_fid
    else
        currentSource = video_play_find_current_source()
        skipFid = video_play_source_fid(currentSource)
    end if
    skipContent = {
        "moviedata": arr,
        "skips": skips,
        "duration": m.video.duration,
        "fid": skipFid
    }
    m.skipSetting.content = skipContent
    m.skipSetting.visible = true
    m.skipSetting.findNode("tabList").SetFocus(true)
    if defaultType = "end"
        m.skipSetting.findNode("tabList").jumpToItem = 1
    end if
end sub

sub onSkipSettingSaved()
    saved = m.skipSetting.saved
    if saved = invalid or saved.skips = invalid
        return
    end if
    if m.skipSettingHandled = true
        return
    end if
    m.skipSettingHandled = true

    if saved.skips <> invalid
        m.videoinfo.skips = saved.skips
        if saved.skips.start <> invalid
            m.skip_start_raw = saved.skips.start
        end if
        if saved.skips.end <> invalid
            m.skip_end_raw = saved.skips.end
            m.skip_end = saved.skips.end
        end if
    end if

    m.skipSaveConfirmPending = true
    m.skipSetting.visible = false

    seekTime = 0
    if saved.seekTime <> invalid
        seekTime = saved.seekTime
    end if
    if saved.skipEnabled = true and seekTime > 0
        m.pendingSeekTime = seekTime
        showSkipPlayConfirmDialog(seekTime, saved.skipType)
    else
        finishSkipSettingFlow(false)
    end if
end sub

sub showSkipPlayConfirmDialog(seekTime as Integer, skipType as String)
    timeText = formatSkipTime(seekTime)
    label = "opening"
    if skipType = "end"
        label = "ending"
    end if
    m.skipPlayDlgText.text = "Play from the selected skip " + label + " at " + timeText + "?"
    m.skipPlayFocusYes = true
    m.skipPlayDlg.visible = true
    updateSkipPlayDlgStyle()
    m.skipPlayDlg.setFocus(true)
end sub

sub updateSkipPlayDlgStyle()
    if m.skipPlayBtnYes = invalid or m.skipPlayBtnNo = invalid
        return
    end if
    if m.skipPlayFocusYes = true
        m.skipPlayBtnYes.color = m.skipPlayBtnYesFocus
        m.skipPlayBtnNo.color = m.skipPlayBtnNoNormal
    else
        m.skipPlayBtnYes.color = m.skipPlayBtnYesNormal
        m.skipPlayBtnNo.color = m.skipPlayBtnNoFocus
    end if
end sub

sub handleSkipPlayDlgOk()
    onSkipPlayDialogSelect(m.skipPlayFocusYes)
end sub

function formatSkipTime(seconds as Integer) as String
    if seconds < 0
        seconds = 0
    end if
    mins = Int(seconds / 60)
    secs = seconds mod 60
    secText = secs.ToStr()
    if secs < 10
        secText = "0" + secText
    end if
    return mins.ToStr() + ":" + secText
end function

sub onSkipPlayDialogSelect(useSkipPoint as Boolean)
    if m.skipPlayDlg = invalid
        return
    end if
    m.skipPlayDlg.visible = false
    finishSkipSettingFlow(useSkipPoint)
end sub

sub finishSkipSettingFlow(useSkipPoint as Boolean)
    m.skipSaveConfirmPending = false
    m.skipSettingFlowActive = false

    if useSkipPoint = true and m.pendingSeekTime > 0
        m.videoinfo.seconds = m.pendingSeekTime
        m.video.seek = m.pendingSeekTime
        m.video.control = "play"
    else
        resumeVideoAfterSkipSetting()
    end if

    m.pendingSeekTime = 0
    m.skiptip.visible = false
    m.skiptip_end.visible = false
    cp_takeFocus()
end sub

sub resumeVideoAfterSkipSetting()
    if m.video.state = "paused"
        m.video.control = "resume"
    else if m.video.state = "stopped"
        m.video.control = "play"
    end if
end sub

sub onSkipSettingVisibleChanged()
    if m.skipSetting = invalid
        return
    end if
    if m.skipSetting.visible = true
        return
    end if
    if m.skipSaveConfirmPending = true
        return
    end if
    if m.skipPlayDlg <> invalid and m.skipPlayDlg.visible = true
        return
    end if
    cancelSkipSettingFlow()
end sub

sub cancelSkipSettingFlow()
    m.skipSettingFlowActive = false
    m.skipSettingHandled = false
    m.skipSaveConfirmPending = false

    if m.videosetWasVisibleBeforeSkip = true and m.videoset <> invalid
        m.videoset.visible = true
        m.typelist.jumpToItem = 0
        m.typelist.setFocus(true)
    end if
    m.videosetWasVisibleBeforeSkip = false

    resumeVideoAfterSkipSetting()
    cp_takeFocus()
end sub

function isSkipIntroOutroEnabled() as Boolean
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("skip_intro_outro") and user.Read("skip_intro_outro") = "0"
        return false
    end if
    return true
end function

sub onVideoSettingsFocusedChildChanged()
    if m.videoset = invalid
        return
    end if

    ' While Settings is genuinely open its descendants are expected to own focus.
    if m.settingsModalActive = true and m.videoset.visible = true
        return
    end if

    ' Once the modal has closed, no node in the Settings subtree is ever allowed
    ' to remain in the focus chain. This catches the late focus restore performed
    ' by MarkupList/LabelList after Audio or Subtitle selection callbacks unwind.
    if m.videoset.isInFocusChain() = true
        setVideoSettingsInputEnabled(false)
        cp_takeFocus()
    end if
end sub

function videoSettingsModalIsActive() as Boolean
    if m.settingsModalActive <> true
        return false
    end if
    if m.videoset = invalid or m.videoset.visible <> true
        return false
    end if
    return true
end function

sub setVideoSettingsInputEnabled(enabled as Boolean)
    if m.videoset = invalid
        return
    end if
    inputIds = ["Typelist", "vlist", "audiolist", "categoryList", "itemsList", "subtitle_ops", "subtitle_btns", "subtitle_delay", "subtitle_bg_opacity", "subtitle_text_opacity", "subtitle_size", "font_list", "subtitle_move", "langlist", "srtlist", "langs", "language_list", "srt_content", "srt_btns", "more", "btn2", "btn_skip", "btn_episodes"]
    for each inputId in inputIds
        inputNode = m.videoset.FindNode(inputId)
        if inputNode <> invalid
            inputNode.focusable = enabled
        end if
    end for
end sub

sub closeVideoSettings(releaseOk as Boolean)
    ' Clear authoritative modal ownership BEFORE changing visibility/focus. Any
    ' late itemSelected notification from the old list is ignored from this point.
    m.settingsModalActive = false
    if m.videoset = invalid
        cp_takeFocus()
        return
    end if

    ' Hide immediately, but reclaim focus again after the current list/key callback
    ' unwinds. Roku list nodes can finish their own selection handling after an
    ' itemSelected observer returns, which can otherwise leave an invisible list
    ' holding focus.
    if releaseOk = true
        m.modalOkGuard = true
        if m.modalGuardTimer <> invalid
            m.modalGuardTimer.control = "stop"
            m.modalGuardTimer.control = "start"
        end if
    else
        m.modalOkGuard = false
        if m.modalGuardTimer <> invalid
            m.modalGuardTimer.control = "stop"
        end if
    end if
    m.settingsClosePending = true
    m.videoset.visible = false
    setVideoSettingsInputEnabled(false)
    cp_takeFocus()
    if m.settingsCloseTimer <> invalid
        m.settingsCloseTimer.control = "stop"
        m.settingsCloseTimer.control = "start"
    end if
    cp_showUi(cp_stateText())
end sub

sub finishVideoSettingsClose()
    if m.settingsClosePending <> true
        return
    end if
    m.settingsClosePending = false
    cp_takeFocus()
end sub

sub clearModalOkGuard()
    m.modalOkGuard = false
end sub

sub openVideoSettings()
    if m.settingsCloseTimer <> invalid
        m.settingsCloseTimer.control = "stop"
    end if
    if m.modalGuardTimer <> invalid
        m.modalGuardTimer.control = "stop"
    end if
    m.settingsClosePending = false
    m.modalOkGuard = false
    m.settingsModalActive = false
    if m.videoset = invalid
        cp_showToast("Settings unavailable")
        return
    end if
    cp_hideUi()
    ' Always restore the root settings card. A previously closed nested subtitle
    ' panel used to leave settingbg hidden, which made Down appear to do nothing.
    m.settingbg = m.videoset.FindNode("settingbg")
    if m.settingbg <> invalid
        m.settingbg.visible = true
    end if
    modalIds = ["sub_settingbg", "subtitle_delaybg", "subtitle_sizebg", "subtitle_movebg", "subtitle_appearancebg", "opensubtitles", "languages", "srt_viewbg"]
    for each modalId in modalIds
        node = m.videoset.FindNode(modalId)
        if node <> invalid
            node.visible = false
        end if
    end for
    ' Claim modal ownership before making any list/grid focusable. Otherwise an
    ' old Audio/Subtitle focusedChild transition can race this open sequence and
    ' be mistaken for stale hidden focus by the fence above.
    m.settingsModalActive = true
    setVideoSettingsInputEnabled(true)
    m.videoset.visible = true
    typelist = m.videoset.FindNode("Typelist")
    if typelist <> invalid
        typelist.SetFocus(true)
    else
        m.videoset.SetFocus(true)
    end if
end sub

function OnKeyEvent(key as String, press as Boolean) as Boolean
    ' A settings list can hide itself from an itemSelected callback while the same
    ' OK event is still unwinding up the focus chain. Consume that OK through its
    ' release so it can never become a player Pause event.
    if m.modalOkGuard = true
        if key = "OK"
            if press = false
                m.modalOkGuard = false
                if m.modalGuardTimer <> invalid
                    m.modalGuardTimer.control = "stop"
                end if
            end if
            return true
        else if press = true
            m.modalOkGuard = false
        end if
    end if

    ' Modal skip confirmation owns focus first.
    if m.skipPlayDlg <> invalid and m.skipPlayDlg.visible = true
        if press = false
            return true
        end if
        if key = "OK"
            handleSkipPlayDlgOk()
            return true
        else if key = "back"
            onSkipPlayDialogSelect(false)
            return true
        else if key = "left"
            m.skipPlayFocusYes = true
            updateSkipPlayDlgStyle()
            return true
        else if key = "right"
            m.skipPlayFocusYes = false
            updateSkipPlayDlgStyle()
            return true
        end if
        return true
    end if

    ' Dedicated settings components get first chance at their own navigation.
    if m.skipSetting <> invalid and m.skipSetting.visible = true
        return false
    end if
    if m.episodeSetting <> invalid and m.episodeSetting.visible = true
        if press = true and (key = "options" or key = "back")
            m.episodeSetting.visible = false
            cp_takeFocus()
            cp_showUi(cp_stateText())
            return true
        end if
        ' Any unhandled event that reaches HyperPlayer while Episodes is open is
        ' still modal-owned. Never reinterpret it as transport.
        return true
    end if

    if m.settingsModalActive = true or (m.videoset <> invalid and m.videoset.visible = true)
        if press = true and key = "back"
            closeVideoSettings(false)
            return true
        end if
        ' Settings owns the entire key lifecycle. Child lists handle their own
        ' navigation first; anything that bubbles here is consumed, not played.
        return true
    end if

    ' Consume releases for every key owned by our player so they never reach a
    ' Roku Video-node/default transport handler.
    if press = false
        if cp_isTransportKey(key)
            return true
        end if
        return false
    end if

    cp_noteInteraction()

    ' Existing skip-tip shortcuts take priority over normal transport controls.
    if key = "OK"
        if m.skiptip.visible = true and m.videoset.visible = false
            showSkipSettingModal("start")
            return true
        end if
        if m.skiptip_end.visible = true and m.videoset.visible = false
            showSkipSettingModal("end")
            return true
        end if
        if m.videoset = invalid or m.videoset.visible = false
            cp_togglePause()
            return true
        end if
        return false
    end if

    if key = "play"
        cp_togglePause()
        return true
    else if key = "playonly"
        cp_forcePlay()
        return true
    else if key = "pause"
        cp_forcePause()
        return true
    else if key = "replay"
        cp_seekBy(-10)
        return true
    else if key = "rewind"
        cp_seekBy(-30)
        return true
    else if key = "fastforward"
        cp_seekBy(30)
        return true
    end if

    if key = "left"
        if m.skiptip.visible = true and m.videoset.visible = false
            m.video.control = "stop"
            m.video.seek = 0
            m.video.control = "play"
            m.skiptip.visible = false
            cp_showToast("Restarted")
            return true
        end if
        if m.videoset <> invalid and m.videoset.visible = true
            return false
        end if
        cp_seekBy(-10)
        return true
    end if

    if key = "right"
        if m.skiptip_end.visible = true and m.videoset.visible = false
            m.top.removeChild(m.videoset)
            m.videoset = invalid
            m.skiptip.visible = false
            m.skiptip_end.visible = false
            m.video.control = "stop"
            m.top.next_episode = m.videoinfo.moviedata.episode
            return true
        end if
        if m.videoset <> invalid and m.videoset.visible = true
            return false
        end if
        cp_seekBy(10)
        return true
    end if

    if key = "up"
        if m.videoset <> invalid and m.videoset.visible = true
            return false
        end if
        arr = invalid
        if m.videoinfo <> invalid
            arr = m.videoinfo.moviedata
        end if
        if arr <> invalid and arr.box_type = 2
            showEpisodePanel()
            return true
        end if
        cp_showUi(cp_stateText())
        return true
    end if

    if key = "down"
        if m.videoset <> invalid and m.videoset.visible = true
            return false
        end if
        openVideoSettings()
        return true
    end if

    if key = "options"
        ' Roku/TV firmware may reserve the * button. The custom player never
        ' depends on it; Episodes are on Up. Consume it when it reaches us.
        cp_showUi(cp_stateText())
        return true
    end if

    if key = "back"
        if m.skipSetting <> invalid and m.skipSetting.visible = true
            m.skipSetting.visible = false
            cp_takeFocus()
            return true
        end if
        if m.episodeSetting <> invalid and m.episodeSetting.visible = true
            m.episodeSetting.visible = false
            cp_takeFocus()
            return true
        end if
        if m.skiptip_end.visible = true
            m.close_skiptip = 1
            m.skiptip_end.visible = false
            return true
        end if
        ' Let the containing screen handle Back and leave the player.
        return false
    end if

    return false
end function
