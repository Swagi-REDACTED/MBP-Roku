sub init()
  m.loading = m.top.findNode("loadingIndicator")
  m.loading.control = "start"
  ' m.decoder = createObject("roSGNode", "GIFDecoder")
  ' m.decoder.delegate = m.top

  ' m.decoder.callFunc("decodeGIF", "pkg:/images/loading2.jfif")

  ' m.animator = createObject("roSGNode", "FrameAnimator")
end sub

sub gifDecoderDidFinish(frames as Object, fps as Float)
  ' m.animator.callFunc("start", frames, fps, m.loading)
end sub

sub OnContentChange()
  ' m.animator.callFunc("finish")
end sub