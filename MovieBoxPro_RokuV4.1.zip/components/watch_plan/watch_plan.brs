'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.title = m.top.findNode("Title")
    m.error_txt = m.top.findNode("error_txt")
    m.watching_count = m.top.findNode("watching_count")
    m.watching_list = m.top.findNode("watching_list")
    m.waiting_text = m.top.findNode("waiting_text")
    m.waiting_count = m.top.findNode("waiting_count")
    m.waiting_list = m.top.findNode("waiting_list")
    m.transAnimation = m.top.findNode("transAnimation")
    m.myInterp2 = m.top.findNode("myInterp2")
    m.watching_list.observeField("itemSelected","watchingDetail")
    m.waiting_list.observeField("itemSelected","waitingDetail")

    m.watchingDataTask = createObject("RoSGNode","GetContentReader")
    m.watchingDataTask.content = {"type":"watchings","page":1}
    m.watchingDataTask.observeField("content", "getwatchings")
    m.watchingDataTask.control = "RUN"
    m.waitingDataTask = createObject("RoSGNode","GetContentReader")
    m.waitingDataTask.content = {"type":"waitings","page":1}
    m.waitingDataTask.observeField("content", "getwaitings")
    m.waitingDataTask.control = "RUN"

    m.watching_list.setFocus(true)
    m.waitingsPage = 1
    m.playRequestId = 0
end function

sub getwatchings()
    if m.watchingDataTask.content.type <> invalid
        return
    end if
    if m.watchingDataTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return
    end if
    if m.watchingDataTask.content.code <= 0
        m.error_txt.text = m.watchingDataTask.content.msg
        m.error_txt.visible = true
        return
    end if
    Content = m.watchingDataTask.content
    m.watching_count.text = "("+Content.data.total.ToStr()+")"
    if Content.data.total > 0
        ContentNode = createObject("RoSGNode","ContentNode")
        rowContent = ContentNode.createChild("ContentNode")
        for each key in Content.data.list
            ItemContent = rowContent.createChild("ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["type"] = "continue"
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if data["box_type"] = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag_new <> invalid
                    data["quality_tag_new"] = key.quality_tag_new
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
        end for
        ItemContent = rowContent.createChild("ContentNode")
        ItemContent.title = ""
        ItemContent.hdposterurl = "pkg:/images/more_cover.png"
        ItemContent.Description = ""
        data = CreateObject("roAssociativeArray")
        data["mid"] = 0
        data["type"] = key.type
        data["name"] = key.name
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        m.watching_list.content = ContentNode
        m.watching_list_status = 1
    else
        m.watching_list_status = 0
        m.watching_count.visible = false
        m.waiting_text.translation = [40, 24 ]
        m.waiting_count.translation = [190, 22 ]
        m.waiting_list.translation = [40, 80 ]
        m.waiting_list.setFocus(true)
    end if
end sub

sub getwaitings()
    if m.waitingDataTask.content.type <> invalid
        return
    end if
    if m.waitingDataTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return
    end if
    if m.waitingDataTask.content.code <= 0
        m.error_txt.text = m.waitingDataTask.content.msg
        m.error_txt.visible = true
        return
    end if
    Content = m.waitingDataTask.content
    m.waiting_count.text = "("+Content.data.total.ToStr()+")"
    if Content.data.total > 0
        ContentNode = createObject("RoSGNode","ContentNode")
        for each key in Content.data.list
            ItemContent = ContentNode.createChild("ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["type"] = "continue"
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if data["box_type"] = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag_new <> invalid
                    data["quality_tag_new"] = key.quality_tag_new
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
        end for
        m.waiting_list.content = ContentNode
        m.waiting_list_status = 1
    else
        m.waiting_list_status = 0
    end if
end sub

function watchingDetail()
    movie = m.watching_list.content.getChild(0).getChild(m.watching_list.rowItemFocused[1])
    arr3 = movie.data
    if arr3.mid = 0
        m.watchings = createObject("roSGNode", "Watchings")
        m.watchings.id = "watchings2"
        m.top.appendChild(m.watchings)
    else
        arr3["title"] = movie.title
        arr3["cover"] = movie.hdposterurl
        m.moviedata = FormatJson(arr3)
        m.watching_prepare = 1
        m.waiting_prepare = 0
        preparation = createObject("roSGNode", "Preparation")
        preparation.arr = arr3
        preparation.id = "preparation"
        m.top.appendChild(preparation)
        m.preparation = m.top.findNode("preparation")
        m.prepare_btns = m.preparation.findNode("buttons")
        m.prepare_btns.observeField("itemSelected","prepareoperates")
    end if
end function

function waitingDetail()
    movie = m.waiting_list.content.getChild(m.waiting_list.itemSelected)
    arr3 = movie.data
    arr3["title"] = movie.title
    arr3["cover"] = movie.hdposterurl
    m.moviedata = FormatJson(arr3)
    m.waiting_prepare = 1
    m.watching_prepare = 0
    preparation = createObject("roSGNode", "Preparation")
    preparation.arr = arr3
    preparation.id = "preparation"
    m.top.appendChild(preparation)
    m.preparation = m.top.findNode("preparation")
    m.prepare_btns = m.preparation.findNode("buttons")
    m.prepare_btns.observeField("itemSelected","prepareoperates")
end function

sub prepareoperates()
    index = m.prepare_btns.itemSelected
    if index = 0 or index = 1
        aa = m.preparation.arr
        data = aa
        data["type"] = "movie_detail"
        if index = 0
            m.replay = 0
        else
            m.replay = 1
        end if
        m.getdetailContentTask = createObject("RoSGNode","GetContentReader")
        m.getdetailContentTask.content = data
        m.getdetailContentTask.observeField("content", "home_play")
        m.getdetailContentTask.control = "RUN"
    elseif index = 2
        aa = m.preparation.arr
        m.moviedata = FormatJson(aa)
        detail = createObject("roSGNode", "DetailScreen")
        detail.movieid = m.moviedata
        detail.id = "moviedetail"
        m.top.appendChild(detail)
        m.detail = m.top.findNode("moviedetail")
        m.operates = m.detail.findNode("operates")
        m.operates.setFocus(true)
        m.top.removeChild(m.preparation)
        m.preparation = invalid
    elseif index = 3
        aa = m.preparation.arr
        data = aa
        data["type"] = "watch_plan_del"
        m.removeContentTask = createObject("RoSGNode","GetContentReader")
        m.removeContentTask.content = data
        m.removeContentTask.control = "RUN"
        if m.watching_prepare <> invalid and m.watching_prepare = 1
            m.watching_list.content.getChild(0).removeChildIndex(m.watching_list.rowItemFocused[1])
            m.watching_list.setFocus(true)
        else
            m.waiting_list.content.removeChildIndex(m.waiting_list.itemSelected)
            m.waiting_list.setFocus(true)
        end if
        m.top.removeChild(m.preparation)
        m.preparation = invalid
    end if
end sub

sub movieScroll()
    if m.waitingPageStatus = invalid
        m.waitingPageStatus = false
    end if
    if m.waitingPageStatus = false
        m.waitingPageStatus = true
        m.waitingsPage = m.waitingsPage + 1
        aa = m.top.arr
        arr = {"type":"waitings","page":m.waitingsPage}
        m.waitingTask2 = createObject("RoSGNode","GetContentReader")
        m.waitingTask2.content = arr
        m.waitingTask2.observeField("content", "addmovies")
        m.waitingTask2.control = "RUN"
    end if
end sub

sub addmovies()
    m.waitingPageStatus = false
    if m.waitingTask2.content = invalid
        m.waitingsPage = m.waitingsPage - 1
        return
    end if
    if m.waitingTask2.content.data.Count() > 0
        arr = ListToContentNode2(m.waitingTask2.content.data.list)
        m.waiting_list.content.appendChildren(arr)
        m.waiting_list.jumpToItem = m.waiting_list.itemFocused + 6
    else
        m.waitingsPage = m.waitingsPage - 1
    end if
end sub

sub home_play()
    arr = m.getdetailContentTask.content
    if arr = invalid
        return
    end if
    if arr.type <> invalid
        return
    end if
    if arr.code <= 0
        return
    end if
    if arr.data.box_type = 2
        m.elist = arr.data.episode
        data = ParseJson(m.moviedata)
        if arr.data.history <> invalid
            for each item in arr.data.episode
                if arr.data.history.episode = item.episode
                    data["imdb_id"] = item.imdb_id
                    exit for
                end if
            end for
            data["season"] = arr.data.history.season
            data["episode"] = arr.data.history.episode
            if arr.data.history.seconds <> invalid
                data["seconds"] = arr.data.history.seconds
            end if
        else
            data["imdb_id"] = arr.data.episode[0].imdb_id
            data["season"] = arr.data.episode[0].season
            data["episode"] = arr.data.episode[0].episode
        end if
        if arr.data.season <> invalid
            data["season_list"] = arr.data.season
        end if
        if arr.data.max_season <> invalid
            data["max_season"] = arr.data.max_season
        end if
        m.moviedata = FormatJson(data)
    else
        data = ParseJson(m.moviedata)
        data["imdb_id"] = arr.data.imdb_id
        if arr.data.plan_watched <> invalid
            data["plan_watched"] = arr.data.plan_watched
        end if
        if arr.data.seconds <> invalid
            data["seconds"] = arr.data.seconds
        end if
        m.moviedata = FormatJson(data)
    end if
    m.loading = CreateObject("roSGNode", "Loading")
    m.top.appendChild(m.loading)
    m.top.removeChild(m.preparation)
    m.preparation = invalid
    startVideoContentReader(m, m.moviedata)
end sub

sub setplaydata()
    if isStaleVideoPlayRequest(m)
        return
    end if
    finishVideoContentRequest(m)
    if m.loading = invalid and m.video_play = invalid
        return
    end if
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
    m.videoinfo = m.readVideoContentTask.videoinfo
    if m.videoinfo = invalid
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.listbtn.setFocus(true)
        m.error_msg.text = "Playback failed, please try again"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if m.videoinfo.code <> invalid and m.videoinfo.code <= 0
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.listbtn.setFocus(true)
        m.error_msg.text = m.videoinfo.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    m.videoinfo["content"] = m.readVideoContentTask.videocontent
    if m.video_play <> invalid
        m.video.control = "stop"
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        m.video_play.content = m.videoinfo
        m.video_play.visible = true
        if m.video <> invalid
            m.video.visible = true
        end if
    else
        m.videoinfo.replay = m.replay
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        video_play = createObject("roSGNode", "videoPlay")
        video_play.content = m.videoinfo
        video_play.id = "video_play"
        m.top.appendChild(video_play)
        m.video_play = m.top.findNode("video_play")
        m.video_play.observeField("next_episode", "autonext")
        m.video_play.observeField("play_episode", "onPlayEpisodeSelected")
        m.video = m.video_play.findNode("my_video")
        m.video.observeField("state", "controlvideoplay")
        m.video_play.setFocus(true)
    end if

    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 300
    m.timer.repeat = true
    m.timer.control = "start"
    m.timer.ObserveField("fire","progressSave")
end sub

sub progressSave()
    runtime = m.video.duration
    seconds = m.video.position
    video = m.videoinfo.list[0]
    
    arr = ParseJson(m.moviedata)
    
    if arr.box_type = 2
        arr["mp4_id"] = video.tmfid
    else
        arr["mp4_id"] = video.mmfid
    end if
    arr["seconds"] = Int(seconds)
    if runtime - seconds < 300
        arr["over"] = 1
    else
        arr["over"] = 0
    end if
    persistPlayProgress(m, arr.seconds, arr.over)
    arr["type"] = "progress_save"

    moviearr = ParseJson(m.moviedata)
    moviearr["seconds"] = Int(seconds)
    m.moviedata = FormatJson(moviearr)

    m.saveContentTask = createObject("RoSGNode","GetContentReader")
    m.saveContentTask.content = arr
    ' m.saveContentTask.observeField("content", "refresh_home")
    m.saveContentTask.control = "RUN"
end sub

sub controlvideoplay()
    if m.video.state = "error"
        m.error = 1
    end if
    if m.video.state = "playing"
        m.error = 0
    end if
    if m.video.state = "finished" and m.error = 0 and isNaturalPlaybackFinish(m.video)
        m.timer.control = "stop"
        progressSave()
        arr = ParseJson(m.moviedata)
        if arr.box_type = 2
            e_list = m.elist
            next2 = 0
            for each item in e_list
                if item.episode > arr.episode
                    arr.imdb_id = item.imdb_id
                    arr.episode = item.episode
                    if item.play_progress.over = 1
                        arr.seconds = 0
                    else
                        arr.seconds = item.play_progress.seconds
                    end if
                    next2 = 1
                    exit for
                end if
            end for
            if next2 = 1
                m.moviedata = FormatJson(arr)
                startVideoContentReader(m, m.moviedata)
            else
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                if m.watching_prepare <> invalid and m.watching_prepare = 1
                    m.watching_list.setFocus(true)
                else
                    m.waiting_list.setFocus(true)
                end if
            end if
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            if m.watching_prepare <> invalid and m.watching_prepare = 1
                m.watching_list.setFocus(true)
            else
                m.waiting_list.setFocus(true)
            end if
        end if
    end if
end sub

sub autonext()
    m.timer.control = "stop"
    progressSave()
    arr = ParseJson(m.moviedata)
    if arr.box_type = 2
        e_list = m.elist
        next2 = 0
        for each item in e_list
            if item.episode > arr.episode
                arr.imdb_id = item.imdb_id
                arr.episode = item.episode
                if item.play_progress.over = 1
                    arr.seconds = 0
                else
                    arr.seconds = item.play_progress.seconds
                end if
                next2 = 1
                exit for
            end if
        end for
        if next2 = 1
            m.moviedata = FormatJson(arr)
            startVideoContentReader(m, m.moviedata)
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            if m.watching_prepare <> invalid and m.watching_prepare = 1
                m.watching_list.setFocus(true)
            else
                m.waiting_list.setFocus(true)
            end if
        end if
    end if
end sub

function ListToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["type"] = "continue"
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if data["box_type"] = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "down" then
            if m.waiting_list.hasFocus() = true
                movieScroll()
                result = true
            end if
            if m.watching_list.hasFocus() = true and m.waiting_list_status = 1
                m.myInterp2.keyValue = [ [0.0, 0.0], [0.0, -356.0] ]
                m.transAnimation.control = "start"
                m.waiting_list.setFocus(true)
                return true
            end if
        elseif key = "up" then
            if m.waiting_list.hasFocus() = true and m.watching_list_status = 1
                m.myInterp2.keyValue = [ [0.0, -356.0], [0.0, 0.0] ]
                m.transAnimation.control = "start"
                m.watching_list.setFocus(true)
                return true
            end if
        elseif key = "back" then
            if m.video_play <> invalid and m.video_play.visible = true
                m.timer.control = "stop"
                progressSave()
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                if m.watching_prepare <> invalid and m.watching_prepare = 1
                    m.watching_list.setFocus(true)
                else
                    m.waiting_list.setFocus(true)
                end if
                return true
            end if
            if m.watchings <> invalid and m.watchings.visible = true
                m.top.removeChild(m.watchings)
                m.watchings = invalid
                m.watching_list.setFocus(true)
                return true
            end if
            if m.preparation <> invalid and m.preparation.visible = true
                m.top.removeChild(m.preparation)
                m.preparation = invalid
                if m.watching_prepare <> invalid and m.watching_prepare = 1
                    m.watching_list.setFocus(true)
                else
                    m.waiting_list.setFocus(true)
                end if
                return true
            end if
            if m.detail <> invalid and m.detail.visible = true
                m.top.removeChild(m.detail)
                m.detail = invalid
                if m.watching_prepare <> invalid and m.watching_prepare = 1
                    m.watching_list.setFocus(true)
                else
                    m.waiting_list.setFocus(true)
                end if
                return true
            end if
        end if
    end if
    return result
end function