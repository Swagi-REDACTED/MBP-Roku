'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function makeMetaData()
    'database(DB) file loaction and its name
    ' DBdir = "pkg:/Database/"
    ' DBfile = DBdir + "Database.json"
    'Get artists data structure
    m.globalErrorHandler = CreateObject("roAssociativeArray")
    m.globalErrorHandler.errorCallback = function(error)
        Print "Unhandled Error: " + error.GetMessage()
        m.top.error = "Critical Error: " + error.GetMessage()
    end function

    Content = gethome()
    ' print Content
    'Convert to content meta-data node  
    if Content = "Timeout"
        m.top.content = createObject("RoSGNode","ContentNode")
        m.top.error = "Loading timeout, please try again"
        return false
    end if
    if Content <> ""
        Try
            ' 尝试解析 JSON 字符串
            arr = ParseJson(Content)
        Catch e
            m.top.content = createObject("RoSGNode","ContentNode")
            m.top.error = Content
            return false
        End Try
    else
        m.top.content = createObject("RoSGNode","ContentNode")
        m.top.error = "Api error"
        return false
    end if
    if arr.code <> invalid and arr.code < 1
        m.top.content = createObject("RoSGNode","ContentNode")
        m.top.error = arr.msg
        return false
    end if
    if arr.data = invalid
        m.top.content = createObject("RoSGNode","ContentNode")
        m.top.error = "Not data"
        return false
    end if
    m.top.error = ""

    ContentNode = ConvertToContentNode(arr.data)
    'return result by assigning it to top interface
    m.top.content = ContentNode
end function


function ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    result = advertisement()
    if result <> "" and result <> "Timeout"
        Try
            list = ParseJson(result)
        Catch e
            list = invalid
        End Try
        if list <> invalid
            if list.code <> invalid and list.code = 1
                itemContent = ContentNode.createChild("ContentNode")
                itemContent.title = ""
                for each key in list.data
                    if key.type <> 5 and key.type <> 6
                        Continue for
                    end if
                    subItemContent = itemContent.createChild("ContentNode")
                    subItemContent.title = ""
                    subItemContent.hdposterurl = key.img
                    subItemContent.Description = "adv"
                    data = CreateObject("roAssociativeArray")
                    data["mid"] = key.url.ToInt()
                    if key.type = 6
                        data["box_type"] = 2
                    elseif key.type = 5
                        data["box_type"] = 1
                    end if
                    subItemContent.addField("data", "assocarray", false)
                    subItemContent.data = data
                end for
            end if
        end if
    end if
    for each key in Content
        if key.list <> invalid and key.type <> invalid
            if key.list.Count() > 0 and key.type <> "cat" and key.type <> "playlist"
                itemContent = ContentNode.createChild("ContentNode")
                itemContent.title = key.name
                subItems = key.list
                for each subItem in subItems
                    if subItem.id = invalid
                        Continue for
                    end if
                    subItemContent = itemContent.createChild("ContentNode")
                    subItemContent.title = subItem.title
                    subItemContent.hdposterurl = subItem.poster
                    subItemContent.Description = key.type
                    data = CreateObject("roAssociativeArray")
                    data["mid"] = subItem.id
                    data["box_type"] = subItem.box_type
                    data["imdb_rating"] = subItem.imdb_rating
                    data["tomato_meter"] = subItem.tomato_meter
                    data["tomato_meter_state"] = subItem.tomato_meter_state
                    if subItem.box_type = 2
                        data["season_episode"] = subItem.season_episode
                    else
                        if subItem.quality_tag_new <> invalid
                            data["quality_tag_new"] = subItem.quality_tag_new
                        end if
                    end if
                    subItemContent.addField("data", "assocarray", false)
                    subItemContent.data = data
                end for
                if key.ismore <> invalid and key.ismore = 1
                    subItemContent = itemContent.createChild("ContentNode")
                    subItemContent.title = ""
                    subItemContent.hdposterurl = "pkg:/images/more_cover.png"
                    subItemContent.Description = ""
                    data = CreateObject("roAssociativeArray")
                    data["mid"] = 0
                    data["type"] = key.type
                    data["name"] = key.name
                    subItemContent.addField("data", "assocarray", false)
                    subItemContent.data = data
                end if
            end if
        end if
    end for
    return ContentNode
end function


function gethome()
    uaRequest = CreateObject("roUrlTransfer")
    print "Home load User-Agent: " + uaRequest.GetUserAgent()

    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Home_list_type_v5"
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["type"] = "all"
    arr["page"] = "1"
    arr["pagelimit"] = "10"
    arr["lang"] = "en"
    arr["open_udid"] = udid

    result = api(arr)
    return result
end function

function advertisement()
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Advertisement_v3"
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["adv_id"] = "6"
    arr["platform"] = "tvos"
    arr["app_version"] = "6.0"
    arr["appid"] = "web"
    arr["open_udid"] = udid
  
    result = api(arr)
    return result
  end function

function api(arr)
    return mbpApiV2(arr)
end function
