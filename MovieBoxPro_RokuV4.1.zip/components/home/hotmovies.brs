'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.title = m.top.findNode("Title")
    m.movies = m.top.findNode("movies")
    m.movies.observeField("itemSelected","hotMovieDetail")
    m.error_txt = m.top.findNode("error_txt")

    m.movies.setFocus(true)
    m.moviesPage = 1
end function

sub contentset()
    aa = m.top.arr
    m.title.text = aa.name
    arr = {"type":"home_type","type2":aa.type,"page":1}
    m.moviesTask = createObject("RoSGNode","GetContentReader")
    m.moviesTask.content = arr
    m.moviesTask.observeField("content", "getmovies")
    m.moviesTask.control = "RUN"
end sub

function getmovies()
    if m.moviesTask.content.type <> invalid
        return false
    end if
    if m.moviesTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return false
    end if
    if m.moviesTask.content.code <= 0
        m.error_txt.text = m.moviesTask.content.msg
        m.error_txt.visible = true
        return false
    end if
    content = m.moviesTask.content
    m.movies.content = ListToContentNode(content.data)
    m.movies.setFocus(true)
end function

sub hotMovieDetail()
    movie = m.movies.content.getChild(m.movies.itemSelected)
    arr3 = movie.data
    arr3["title"] = movie.title
    arr3["cover"] = movie.hdposterurl
    m.moviedata = FormatJson(arr3)
    m.detail = createObject("roSGNode", "DetailScreen")
    m.detail.movieid = m.moviedata
    m.top.appendChild(m.detail)
    m.operates = m.detail.findNode("operates")
    m.operates.setFocus(true)
end sub

sub movieScroll()
    if m.moviePageStatus = invalid
        m.moviePageStatus = false
    end if
    if m.moviePageStatus = false
        m.moviePageStatus = true
        m.moviesPage = m.moviesPage + 1
        aa = m.top.arr
        arr = {"type":"home_type","type2":aa.type,"page":m.moviesPage}
        m.movieTask2 = createObject("RoSGNode","GetContentReader")
        m.movieTask2.content = arr
        m.movieTask2.observeField("content", "addmovies")
        m.movieTask2.control = "RUN"
    end if
end sub

sub addmovies()
    m.moviePageStatus = false
    if m.movieTask2.content = invalid
        m.moviesPage = m.moviesPage - 1
        return
    end if
    if m.movieTask2.content.data.Count() > 0
        arr = ListToContentNode2(m.movieTask2.content.data)
        m.movies.content.appendChildren(arr)
        m.movies.jumpToItem = m.movies.itemFocused + 6
    else
        m.moviesPage = m.moviesPage - 1
    end if
end sub

function ListToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.box_type = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

function ListToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.box_type = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "down" then
            movieScroll()
        elseif key = "back" then
            if m.detail <> invalid and m.detail.visible = true
                m.top.removeChild(m.detail)
                m.detail = invalid
                m.movies.setFocus(true)
                return true
            end if
        end if
    end if
    return result
end function