'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function makeMetaData()
    'database(DB) file loaction and its name
    ' DBdir = "pkg:/Database/"
    ' DBfile = DBdir + "Database.json"
    'Get artists data structure
    arr = m.top.content
    if arr <> invalid
      if arr.type <> invalid and arr.type = "season"
        Content = getseason(arr)
      elseif arr.type <> invalid and arr.type = "tv_player_episodes"
        Content = tv_player_episodes(arr)
      elseif arr.type <> invalid and arr.type = "code"
        Content = getcode()
      elseif arr.type <> invalid and arr.type = "logincode"
        Content = changeLogin(arr)
      elseif arr.type <> invalid and arr.type = "home_adv"
        Content = advertisement()
      elseif arr.type <> invalid and arr.type = "home_type"
        Content = gethome_type(arr)
      elseif arr.type <> invalid and arr.type = "toplist"
        Content = top_list(arr)
      elseif arr.type <> invalid and arr.type = "toplist_movie"
        Content = top_list_movie(arr)
      elseif arr.type <> invalid and arr.type = "getmovies2"
        Content = getmovies(arr)
      elseif arr.type <> invalid and arr.type = "gettvs2"
        Content = gettvs(arr)
      elseif arr.type <> invalid and arr.type = "history"
        Content = watch_history(arr)
      elseif arr.type <> invalid and arr.type = "movie_detail"
        Content = getdetail(arr)
      elseif arr.type <> invalid and arr.type = "watchings"
        Content = watched_plan_list(arr)
      elseif arr.type <> invalid and arr.type = "waitings"
        Content = watched_plan_list2(arr)
      elseif arr.type <> invalid and arr.type = "watched_plan_episode"
        Content = watched_plan_episode_list(arr)
      elseif arr.type <> invalid and arr.type = "watch_plan_mark"
        Content = watch_plan_mark(arr)
      elseif arr.type <> invalid and arr.type = "watch_plan_add"
        Content = watch_plan_add(arr)
      elseif arr.type <> invalid and arr.type = "watch_plan_del"
        Content = watch_plan_del(arr)
      elseif arr.type <> invalid and arr.type = "tv_over"
        Content = tv_over(arr)
      elseif arr.type <> invalid and arr.type = "tv_episode_skip"
        Content = tv_episode_skip(arr)
      elseif arr.type <> invalid and arr.type = "tv_video_thumbs"
        Content = tv_video_thumbs(arr)
      elseif arr.type <> invalid and arr.type = "tv_episode_skip_vote"
        Content = tv_episode_skip_vote(arr)
      elseif arr.type <> invalid and arr.type = "tv_episode_title_vote_only"
        Content = tv_episode_title_vote_only(arr)
      elseif arr.type <> invalid and arr.type = "tv_playlist"
        Content = tv_playlist(arr)
      elseif arr.type <> invalid and arr.type = "progress_save"
        Content = progressSave(arr)
      elseif arr.type <> invalid and arr.type = "playlist"
        Content = movielist(arr)
      elseif arr.type <> invalid and arr.type = "film_festival"
        Content = film_festival(arr)
      elseif arr.type <> invalid and arr.type = "user_lists"
        Content = user_movielist(arr)
      elseif arr.type <> invalid and arr.type = "mylist"
        Content = getmylist()
      elseif arr.type <> invalid and arr.type = "playlist_detail"
        Content = playlist_get(arr)
      elseif arr.type <> invalid and arr.type = "playlist_detail2"
        Content = playlist_get_new(arr)
      elseif arr.type <> invalid and arr.type = "playlist_collect"
        Content = playlist_collect(arr)
      elseif arr.type <> invalid and arr.type = "fav"
        Content = addfav(arr)
      elseif arr.type <> invalid and arr.type = "add_playlist"
        Content = add_playlist(arr)
      elseif arr.type <> invalid and arr.type = "searchhot"
        Content = getSearchHot()
      elseif arr.type <> invalid and arr.type = "search"
        Content = search(arr)
      elseif arr.type <> invalid and arr.type = "autocomplete"
        Content = Autocomplete(arr)
      elseif arr.type <> invalid and arr.type = "mysubtitle"
        Content = mysubtitles(arr)
      elseif arr.type <> invalid and arr.type = "opensubtitle"
        Content = opensubtitles(arr)
      elseif arr.type <> invalid and arr.type = "get_srtpath"
        Content = get_srtpath(arr)
      elseif arr.type <> invalid and arr.type = "upload_srt"
        Content = upload_srt(arr)
      elseif arr.type <> invalid and arr.type = "srt_translate"
        m.top.content = srt_translate(arr)
      elseif arr.type <> invalid and arr.type = "sub_select"
        Content = subtitle_select(arr)
      elseif arr.type <> invalid and arr.type = "sub_select_del"
        Content = subtitle_select_del(arr)
      elseif arr.type <> invalid and arr.type = "subtitle_delay"
        Content = subtitle_delay(arr)
      elseif arr.type <> invalid and arr.type = "server_list"
        Content = server_list()
      elseif arr.type <> invalid and arr.type = "country_list"
        Content = country_list(arr)
      elseif arr.type <> invalid and arr.type = "trailer"
        Content = gettrailerplay(arr)
      elseif arr.type <> invalid and arr.type = "collect"
        Content = Movie_collect_list(arr)
      elseif arr.type <> invalid and arr.type = "get_app"
        Content = get_appinfo()
      elseif arr.type <> invalid and arr.type = "device"
        Content = device()
      elseif arr.type <> invalid and arr.type = "userinfo"
        Content = user_info()
      elseif arr.type <> invalid and arr.type = "comment_list"
        Content = comment_list(arr)
      elseif arr.type <> invalid and arr.type = "comment_detail"
        Content = comment_detail(arr)
      elseif arr.type <> invalid and arr.type = "comment_detail_parent"
        Content = comment_detail_parent(arr)
      elseif arr.type <> invalid and arr.type = "comment_detail_child"
        Content = comment_detail_child(arr)
      else
        Content = getsubtitles(arr)
      end if
      if arr.type <> invalid and arr.type = "srt_translate"
        if m.top.content = invalid or Type(m.top.content) <> "roAssociativeArray"
          m.top.content = {"code":0,"msg":"Translation failed. Please try again."}
        end if
      else
        'Convert to content meta-data node
        if Content <> invalid and Content <> ""
          arr2 = ParseJson(Content)
        else
          arr2 = {"code":0,"data":{}}
        end if
        if arr2 = invalid or Type(arr2) <> "roAssociativeArray"
          arr2 = {"code":0,"data":{}}
        end if
        ' content field is typed assocarray — only unwrap data when it is an AA
        if arr.type <> invalid and (arr.type = "subtitles" or arr.type = "code")
          out = arr2.data
          if out = invalid or Type(out) <> "roAssociativeArray"
            out = {}
          end if
          if arr.type = "code"
            out = mbpV2CodeResult(arr2)
          end if
          m.top.content = out
        else
          m.top.content = arr2
        end if
      end if
    end if
end function


function gethome_type(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Home_list_type_v5"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = data.type2
  arr["page"] = data.page
  arr["pagelimit"] = 24
  arr["lang"] = "en"
  arr["open_udid"] = udid
  
  result = api(arr)
  return result
end function

function top_list(data)
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Top_list"
  arr["box_type"] = data.box_type
  arr["app_version"] = "1.2"
  arr["lang"] = "en"
  
  result = api(arr)
  return result
end function

function getmovies(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_list_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["year"] = data.year
  arr["rating"] = data.rating
  arr["quality"] = data.quality
  arr["cid"] = data.cid
  arr["orderby"] = data.sort
  arr["country"] = data.country
  arr["page"] = data.page
  arr["pagelimit"] = "24"
  arr["lang"] = "en"
  arr["open_udid"] = udid
  
  result = api(arr)
  return result
end function

function gettvs(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "TV_list_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["year"] = data.year
  arr["rating"] = data.rating
  arr["quality"] = data.quality
  arr["cid"] = data.cid
  arr["orderby"] = data.sort
  arr["country"] = data.country
  arr["page"] = data.page
  arr["pagelimit"] = "24"
  arr["lang"] = "en"
  arr["open_udid"] = udid
  
  result = api(arr)
  return result
end function

function top_list_movie(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2
    arr["module"] = "Top_list_tv"
  else
    arr["module"] = "Top_list_movie"
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["id"] = data.id
  arr["page"] = data.page
  arr["pagelimit"] = 24
  arr["lang"] = "en"
  arr["open_udid"] = udid
  
  result = api(arr)
  return result
end function

function getdetail(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2 then
  arr["module"] = "TV_detail_1"
  arr["tid"] = data.mid
  else
  arr["module"] = "Movie_detail"
  arr["mid"] = data.mid
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lang"] = "en"
  arr["app_version"] = "6.0"
  arr["open_udid"] = udid

  if data.box_type = 2
    arr2 = CreateObject("roAssociativeArray")
    arr2["module"] = "TV_detail_playlist"
    arr2["uid"] = uid
    arr2["tid"] = data.mid
    arr2["open_udid"] = udid
    result2 = api(arr2)
  end if
  
  result = api(arr)
  if data.box_type = 2
    if result <> ""
      detail = ParseJson(result)
      if detail.data <> invalid
        if result2 <> ""
          list = ParseJson(result2)
          if list.data <> invalid
            detail.data["playlist"] = list.data.playlist
            result = FormatJson(detail)
          end if
        end if
      end if
    end if
  end if
  return result
end function

function getsubtitles(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    if data.box_type = 2 then
    arr["module"] = "TV_srt_list_v2"
    arr["tid"] = data.mid
    if data.season <> invalid
      arr["season"] = data.season
      arr["episode"] = data.episode
    else
      arr["season"] = 1
      arr["episode"] = 1
    end if
    else
    arr["module"] = "Movie_srt_list_v2"
    arr["mid"] = data.mid
    end if
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["fid"] = data.fid
    arr["lang"] = ""
    arr["open_udid"] = udid

    result = api(arr)
    mysubtitle = mysubtitles(data)
    if mysubtitle <> ""
      mysubtitle = ParseJson(mysubtitle)
      if mysubtitle.code > 0 and mysubtitle.data.srt_list.Count() > 0
        aa = {"language":"My Subtitles", "subtitles":mysubtitle.data.srt_list}
        result_arr = ParseJson(result)
        result_arr.data.list.Unshift(aa)
        result = FormatJson(result_arr)
      end if
    end if
    return result
end function

function subtitle_select(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2 then
    arr["module"] = "TV_srt_select"
    arr["tid"] = data.mid
    if data.season <> invalid
      arr["season"] = data.season
      arr["episode"] = data.episode
    else
      arr["season"] = 1
      arr["episode"] = 1
    end if
  else
    arr["module"] = "Movie_srt_select"
    arr["mid"] = data.mid
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["sid"] = data.sid
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function subtitle_select_del(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2 then
    arr["module"] = "TV_srt_select"
    arr["tid"] = data.mid
    if data.season <> invalid
      arr["season"] = data.season
      arr["episode"] = data.episode
    else
      arr["season"] = 1
      arr["episode"] = 1
    end if
  else
    arr["module"] = "Movie_srt_select"
    arr["mid"] = data.mid
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["sid"] = data.sid
  arr["type"] = "del"
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function subtitle_delay(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2 then
    arr["module"] = "TV_srt_delay"
  else
    arr["module"] = "Movie_srt_delay"
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["sid"] = data.sid
  arr["delay"] = data.delay
  arr["open_udid"] = udid

  result = api(arr)
  print result
  return result
end function

function progressSave(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr2 = {}
  if data.box_type = 2 then
  arr["module"] = "TV_play_progress"
  arr["tid"] = data.mid
  arr2["module"] = "TV_play"
  arr2["tid"] = data.mid
  if data.season <> invalid
    arr["season"] = data.season
    arr["episode"] = data.episode
    arr2["season"] = data.season
    arr2["episode"] = data.episode
  else
    arr["season"] = 1
    arr["episode"] = 1
    arr2["season"] = 1
    arr2["episode"] = 1
  end if
  else
  arr["module"] = "Movie_play_progress"
  arr["mid"] = data.mid
  arr2["module"] = "Movie_play"
  arr2["mid"] = data.mid
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["mp4_id"] = data.mp4_id
  saveSec = 0
  if data.seconds <> invalid
    t = Type(data.seconds)
    if t = "roString" or t = "String"
      if data.seconds <> ""
        saveSec = data.seconds.ToInt()
      end if
    else
      saveSec = Int(data.seconds)
    end if
  end if
  arr["seconds"] = saveSec
  arr["over"] = data.over
  arr["open_udid"] = udid
  arr2["uid"] = uid
  arr2["seconds"] = saveSec
  arr2["open_udid"] = udid
  arr2["device_type"] = 1

  result = api(arr)
  result = api(arr2)
  return result
end function

function getseason(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "TV_episode"
    arr["tid"] = data.mid
    arr["season"] = data.season
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["display_all"] = 1
    arr["page"] = 1
    arr["pagelimit"] = 100
    arr["open_udid"] = udid

    result = api(arr)
    return result
end function

function tv_player_episodes(data)
    epJson = getseason(data)
    epArr = invalid
    if epJson <> invalid and epJson <> ""
        epArr = ParseJson(epJson)
    end if

    episodes = []
    code = 0
    msg = "Failed to load episodes"
    if epArr <> invalid
        if epArr.code <> invalid
            code = epArr.code
        end if
        if epArr.msg <> invalid
            msg = epArr.msg
        end if
        if epArr.data <> invalid
            episodes = epArr.data
        end if
    end if

    seasons = normalizeSeasonList(data.seasons)
    maxSeason = 0
    if data.max_season <> invalid
        maxSeason = toSeasonInt(data.max_season)
    end if

    if seasons.Count() <= 1
        deviceinfo = CreateObject("roDeviceInfo")
        udid = deviceinfo.GetChannelClientId()
        user = CreateObject("roRegistrySection", "User")
        uid = user.Read("uid_v2")
        arr = CreateObject("roAssociativeArray")
        arr["module"] = "TV_detail_1"
        arr["tid"] = data.mid
        arr["display_all"] = 1
        arr["uid"] = uid
        arr["lang"] = "en"
        arr["app_version"] = "6.0"
        arr["open_udid"] = udid
        detailJson = api(arr)
        if detailJson <> invalid and detailJson <> ""
            detail = ParseJson(detailJson)
            if detail <> invalid and detail.data <> invalid
                fetched = normalizeSeasonList(detail.data.season)
                if fetched.Count() > seasons.Count()
                    seasons = fetched
                end if
                if maxSeason <= 1 and detail.data.max_season <> invalid
                    maxSeason = toSeasonInt(detail.data.max_season)
                end if
            end if
        end if
    end if

    season = 1
    if data.season <> invalid
        season = toSeasonInt(data.season)
        if season <= 0
            season = 1
        end if
    end if

    if seasons.Count() <= 1 and maxSeason > 1 and maxSeason <= 80 and season <= 80
        filled = []
        for i = 1 to maxSeason
            filled.Push(i)
        end for
        seasons = filled
    end if

    if seasons.Count() = 0 and season > 0
        seasons.Push(season)
    end if

    out = CreateObject("roAssociativeArray")
    out["code"] = code
    out["msg"] = msg
    out["data"] = {
        "seasons": seasons,
        "episodes": episodes,
        "season": season
    }
    return FormatJson(out)
end function

function toSeasonInt(v as Dynamic) as Integer
    if v = invalid
        return 0
    end if
    t = Type(v)
    if t = "roString" or t = "String"
        if v = ""
            return 0
        end if
        return v.ToInt()
    end if
    return Int(v)
end function

function normalizeSeasonList(raw as Dynamic) as Object
    seasons = []
    seen = {}
    if raw = invalid
        return seasons
    end if
    if GetInterface(raw, "ifArray") <> invalid
        for each item in raw
            n = 0
            if GetInterface(item, "ifAssociativeArray") <> invalid and item.season <> invalid
                n = toSeasonInt(item.season)
            else
                n = toSeasonInt(item)
            end if
            key = n.ToStr()
            if n > 0 and seen[key] = invalid
                seasons.Push(n)
                seen[key] = 1
            end if
        end for
        return seasons
    end if
    if GetInterface(raw, "ifAssociativeArray") <> invalid
        for each key in raw
            item = raw[key]
            n = 0
            if GetInterface(item, "ifAssociativeArray") <> invalid and item.season <> invalid
                n = toSeasonInt(item.season)
            else
                n = toSeasonInt(item)
            end if
            if n <= 0
                n = toSeasonInt(key)
            end if
            skey = n.ToStr()
            if n > 0 and seen[skey] = invalid
                seasons.Push(n)
                seen[skey] = 1
            end if
        end for
    end if
    return seasons
end function

function watched_plan_list(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watched_plan_list_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["sort"] = ""
  arr["year"] = 0
  arr["country"] = ""
  arr["content_rating"] = ""
  arr["quality"] = ""
  arr["cat_id"] = 0
  arr["box_type"] = 0
  arr["waiting"] = 0
  arr["page"] = data.page
  arr["pagelimit"] = 12
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watched_plan_list2(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watched_plan_list_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["sort"] = ""
  arr["year"] = 0
  arr["country"] = ""
  arr["content_rating"] = ""
  arr["quality"] = ""
  arr["cat_id"] = 0
  arr["box_type"] = 0
  arr["waiting"] = 1
  arr["page"] = data.page
  arr["pagelimit"] = 18
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watched_plan_episode_list(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watched_plan_episode_list"
  arr["tid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watch_plan_mark(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watch_plan_mark"
  arr["mid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["box_type"] = data.box_type
  arr["watched"] = data.watched
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watch_plan_add(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watch_plan_add"
  arr["mid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["box_type"] = data.box_type
  arr["watched"] = data.watched
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watch_plan_del(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "User_watch_plan_del"
  arr["mid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["box_type"] = data.box_type
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function tv_over(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "TV_over_v2"
  arr["tid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["season"] = data.season
  if data.episode <> invalid
    arr["episode"] = data.episode
  end if
  arr["over"] = data.over
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function tv_episode_skip(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "TV_episode_title_get"
  arr["tid"] = data.mid
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["season"] = data.season
  arr["episode"] = data.episode
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function tv_video_thumbs(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")

  thumbType = "start"
  if data.thumb_type <> invalid
    thumbType = data.thumb_type
  else if data.skip_type <> invalid
    thumbType = data.skip_type
  end if

  range = 1
  if data.range <> invalid
    range = data.range
  end if

  skip = 0
  num = 0
  hasMax = false
  maxTime = 0
  skips = data.skips

  if skips <> invalid
    if thumbType = "start"
      if skips.start <> invalid and skips.start > 0
        skip = skips.start
      end if
      if skips.start_top_list <> invalid
        for each val in skips.start_top_list
          if val.total <> invalid and val.total > num
            num = val.total
            if val.start <> invalid
              hasMax = true
              maxTime = val.start
            end if
          end if
        end for
      end if
    else
      if skips.end <> invalid and skips.end > 0
        skip = skips.end
      end if
      if skips.end_top_list <> invalid
        for each val in skips.end_top_list
          if val.total <> invalid and val.total > num
            num = val.total
            if val.end <> invalid
              hasMax = true
              maxTime = val.end
            end if
          end if
        end for
      end if
    end if
  end if

  if num < 68
    num = 68
  end if
  if skip = 0 and hasMax = true
    skip = maxTime
  end if

  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Video_thumbs_v2"
  arr["uid"] = uid
  arr["fid"] = data.fid
  arr["box_type"] = 2
  if data.box_type <> invalid
    arr["box_type"] = data.box_type
  end if
  arr["type"] = thumbType
  arr["range"] = range * 180
  arr["open_udid"] = udid

  result = api_thumbs(arr)
  if result = ""
    return FormatJson({"code": 0, "msg": "network error"})
  end if

  parsed = ParseJson(result)
  if parsed = invalid or parsed.code <> 1 or parsed.data = invalid or parsed.data.thumbs = invalid
    return result
  end if

  thumbs = parsed.data.thumbs
  count = (thumbs.Count() - 1) * 2
  processed = []
  idx = 0
  for each val in thumbs
    item = CreateObject("roAssociativeArray")
    item["url"] = val.url
    if thumbType = "end"
      if range = 2
        item["seconds"] = count - idx * 2 + 182
      else
        item["seconds"] = count - idx * 2
      end if
    else
      item["seconds"] = val.seconds
    end if
    if hasMax = true and item["seconds"] = maxTime
      item["most_chosen"] = 1
    end if

    voteHeight = 0
    if thumbType = "start" and skips <> invalid and skips.start_top_list <> invalid
      for each val2 in skips.start_top_list
        if val2.start <> invalid and val2.start = item["seconds"] and val2.total <> invalid and val2.total > 0
          voteHeight = Int((val2.total / num) * 68)
          if voteHeight < 1
            voteHeight = 1
          end if
          exit for
        end if
      end for
    else if thumbType = "end" and skips <> invalid and skips.end_top_list <> invalid
      for each val2 in skips.end_top_list
        if val2.end <> invalid and val2.end = item["seconds"] and val2.total <> invalid and val2.total > 0
          voteHeight = Int((val2.total / num) * 68)
          if voteHeight < 1
            voteHeight = 1
          end if
          exit for
        end if
      end for
    end if
    item["vote_height"] = voteHeight

    processed.Push(item)
    idx = idx + 1
  end for

  selectIdx = 0
  for i = 0 to processed.Count() - 1
    if processed[i].seconds = skip
      selectIdx = i
      exit for
    end if
  end for

  out = CreateObject("roAssociativeArray")
  out["code"] = 1
  outData = CreateObject("roAssociativeArray")
  outData["thumbs"] = processed
  outData["select_skip"] = skip
  outData["select_index"] = selectIdx
  out["data"] = outData
  return FormatJson(out)
end function

function tv_episode_skip_vote(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")

  startVal = -1
  endVal = -1
  if data.start <> invalid
    startVal = data.start
  end if
  if data.end <> invalid
    endVal = data.end
  end if
  if startVal > 360
    startVal = 360
  end if
  if endVal > 360
    endVal = 360
  end if

  arrVote = CreateObject("roAssociativeArray")
  arrVote["module"] = "TV_episode_title_vote"
  arrVote["uid"] = uid
  arrVote["tid"] = data.mid
  arrVote["season"] = data.season
  arrVote["episode"] = data.episode
  arrVote["start"] = startVal
  arrVote["end"] = endVal
  arrVote["open_udid"] = udid

  voteTask = CreateObject("roSGNode", "GetContentReader")
  voteBg = CreateObject("roAssociativeArray")
  voteBg["type"] = "tv_episode_title_vote_only"
  voteBg["payload"] = arrVote
  voteTask.content = voteBg
  voteTask.control = "RUN"

  arrMark = CreateObject("roAssociativeArray")
  arrMark["module"] = "TV_episode_title_mark"
  arrMark["uid"] = uid
  arrMark["tid"] = data.mid
  arrMark["season"] = data.season
  arrMark["episode"] = data.episode
  arrMark["start"] = startVal
  arrMark["end"] = endVal
  arrMark["type"] = "add"
  arrMark["open_udid"] = udid

  result = api(arrMark)
  return result
end function

function tv_episode_title_vote_only(data)
  if data.payload = invalid
    return FormatJson({"code": 0})
  end if
  api(data.payload)
  return FormatJson({"code": 1})
end function

function advertisement()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Advertisement_v3"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["adv_id"] = "6"
  arr["platform"] = "tvos"
  arr["app_version"] = "6.0"
  
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function gettrailerplay(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Youtube_download"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["vid"] = data.vid
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function Movie_collect_list(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_collect"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "get"
  arr["page"] = data.page
  arr["pagelimit"] = 24
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function watch_history(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_play_record"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "get"
  arr["page"] = data.page
  arr["pagelimit"] = 24
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function tv_playlist(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "TV_detail_playlist"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["tid"] = data.tid
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function movielist(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_list_v4"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = data.type2
  arr["page"] = data.page
  arr["pagelimit"] = data.limit
  arr["platform"] = "tvos"
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function user_movielist(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_list_v4"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "user_playlists"
  arr["playlist_uid"] = data.uid
  arr["page"] = data.page
  arr["pagelimit"] = data.limit
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function film_festival(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_compilations_detail"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["cid"] = data.id
  arr["page"] = data.page
  arr["pagelimit"] = 18
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function playlist_get(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_get"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lid"] = data.id
  arr["page"] = data.page
  arr["pagelimit"] = 18
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function playlist_get_new(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_get_v3"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lid"] = data.id
  arr["sort_by"] = data.sort_by
  arr["sort"] = data.sort
  arr["page"] = data.page
  arr["pagelimit"] = 18
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function playlist_collect(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_collect"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lid"] = data.id
  arr["type"] = data.type2
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function getmylist()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_list_v4"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "mine"
  arr["page"] = 1
  arr["pagelimit"] = 200
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function comment_list(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_comment_list"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["mid"] = data.mid
  arr["box_type"] = data.box_type
  if data.page <> invalid
    arr["page"] = data.page
  else
    arr["page"] = 1
  end if
  if data.sort <> invalid
    arr["sort"] = data.sort
  else
    arr["sort"] = "update_time_desc"
  end if
  arr["pagelimit"] = 15
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function comment_detail(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  sort = "update_time_desc"
  if data.sort <> invalid
    sort = data.sort
  end if

  parent_list = []
  own_list = []
  children_list = []
  parent_has_more = false
  child_has_more = false
  pageLimit = 12

  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_comment_list_by_id"
  arr["uid"] = uid
  arr["mid"] = data.mid
  arr["box_type"] = data.box_type
  arr["comment_id"] = data.comment_id
  arr["type"] = 0
  arr["sort"] = sort
  arr["page"] = 1
  arr["pagelimit"] = pageLimit
  arr["open_udid"] = udid
  result = api(arr)
  if result <> ""
    parsed = ParseJson(result)
    if parsed <> invalid and parsed.code = 1 and parsed.data <> invalid and parsed.data.list <> invalid
      list = parsed.data.list
      parent_has_more = list.Count() >= pageLimit
      i = list.Count() - 1
      while i >= 0
        parent_list.Push(list[i])
        i = i - 1
      end while
    end if
  end if

  arr2 = CreateObject("roAssociativeArray")
  arr2["module"] = "Movie_comment_get"
  arr2["uid"] = uid
  arr2["comment_ids"] = [data.comment_id]
  arr2["open_udid"] = udid
  result2 = api(arr2)
  if result2 <> ""
    parsed2 = ParseJson(result2)
    if parsed2 <> invalid and parsed2.code = 1 and parsed2.data <> invalid and parsed2.data.list <> invalid
      own_list = parsed2.data.list
    end if
  end if

  arr3 = CreateObject("roAssociativeArray")
  arr3["module"] = "Movie_comment_list_by_id"
  arr3["uid"] = uid
  arr3["mid"] = data.mid
  arr3["box_type"] = data.box_type
  arr3["comment_id"] = data.comment_id
  arr3["type"] = 2
  arr3["sort"] = sort
  arr3["page"] = 1
  arr3["pagelimit"] = pageLimit
  arr3["open_udid"] = udid
  result3 = api(arr3)
  if result3 <> ""
    parsed3 = ParseJson(result3)
    if parsed3 <> invalid and parsed3.code = 1 and parsed3.data <> invalid and parsed3.data.list <> invalid
      children_list = parsed3.data.list
      child_has_more = children_list.Count() >= pageLimit
    end if
  end if

  out = {
    "code": 1,
    "data": {
      "parent_list": parent_list,
      "own_list": own_list,
      "children_list": children_list,
      "parent_has_more": parent_has_more,
      "child_has_more": child_has_more
    }
  }
  return FormatJson(out)
end function

function comment_detail_parent(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  sort = "update_time_desc"
  page = 1
  pageLimit = 12
  if data.sort <> invalid
    sort = data.sort
  end if
  if data.page <> invalid
    page = data.page
  end if

  parent_list = []
  has_more = false
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_comment_list_by_id"
  arr["uid"] = uid
  arr["mid"] = data.mid
  arr["box_type"] = data.box_type
  arr["comment_id"] = data.comment_id
  arr["type"] = 0
  arr["sort"] = sort
  arr["page"] = page
  arr["pagelimit"] = pageLimit
  arr["open_udid"] = udid
  result = api(arr)
  if result <> ""
    parsed = ParseJson(result)
    if parsed <> invalid and parsed.code = 1 and parsed.data <> invalid and parsed.data.list <> invalid
      list = parsed.data.list
      has_more = list.Count() >= pageLimit
      i = list.Count() - 1
      while i >= 0
        parent_list.Push(list[i])
        i = i - 1
      end while
    end if
  end if

  out = {"code": 1, "data": {"list": parent_list, "has_more": has_more, "part": "parent"}}
  return FormatJson(out)
end function

function comment_detail_child(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  sort = "update_time_desc"
  page = 1
  pageLimit = 12
  if data.sort <> invalid
    sort = data.sort
  end if
  if data.page <> invalid
    page = data.page
  end if

  children_list = []
  has_more = false
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_comment_list_by_id"
  arr["uid"] = uid
  arr["mid"] = data.mid
  arr["box_type"] = data.box_type
  arr["comment_id"] = data.comment_id
  arr["type"] = 2
  arr["sort"] = sort
  arr["page"] = page
  arr["pagelimit"] = pageLimit
  arr["open_udid"] = udid
  result = api(arr)
  if result <> ""
    parsed = ParseJson(result)
    if parsed <> invalid and parsed.code = 1 and parsed.data <> invalid and parsed.data.list <> invalid
      children_list = parsed.data.list
      has_more = children_list.Count() >= pageLimit
    end if
  end if

  out = {"code": 1, "data": {"list": children_list, "has_more": has_more, "part": "child"}}
  return FormatJson(out)
end function

function addfav(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Movie_collect"
    if data.box_type = 2 then
      arr["tid"] = [data.mid]
    else
      arr["mid"] = [data.mid]
    end if
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["type"] = data.type2
    arr["watched"] = 0
    arr["open_udid"] = udid

    result = api(arr)
    return result
end function

function add_playlist(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Playlists_video_add"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lid"] = data.lid
  arr["mid"] = data.mid
  arr["box_type"] = data.box_type
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function server_list()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Test_network_url_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["app_version"] = "3.2"
  arr["platform"] = "web"
  arr["lang"] = "zh"
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function country_list(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Movie_country_list"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["box_type"] = data.box_type
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function getcode()
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Add_captcha"
    arr["open_udid"] = udid

    result = api(arr)
    return result
end function

function changeLogin(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Login_captcha_v2"
    arr["code"] = data.code
    arr["openudid"] = udid

    result = api(arr)
    return result
end function

function device()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Device_v2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["device_name"] = deviceinfo.GetModelDisplayName()
  arr["device_model"] = deviceinfo.GetModel()
  arr["devicetoken"] = ""
  arr["udid"] = ""
  arr["receive"] = 1
  arr["platform"] = "Roku OS"
  versions = deviceinfo.GetOSVersion()
  arr["platform_version"] = versions["major"]+"."+versions["minor"]
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function getSearchHot()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Search_hot"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "movie"
  arr["page"] = 1
  arr["pagelimit"] = 10
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function Autocomplete(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Autocomplate2"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = "all"
  arr["keyword"] = data.key
  arr["pagelimit"] = 10
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function search(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Search5"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["type"] = data.type2
  arr["keyword"] = data.key
  arr["page"] = data.page
  arr["pagelimit"] = 18
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function user_info()
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Userinfo"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function mysubtitles(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "My_srt"
    arr["mid"] = data.mid
    if data.box_type = 2 then
      if data.season <> invalid
        arr["season"] = data.season
        arr["episode"] = data.episode
      else
        arr["season"] = 1
        arr["episode"] = 1
      end if
    else
      arr["season"] = 0
      arr["episode"] = 0
    end if
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    arr["box_type"] = data.box_type
    arr["open_udid"] = udid

    result = api(arr)
    return result
end function

function opensubtitles(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Opensubtitles_search"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["imdb_id"] = data.imdb_id
  arr["text"] = ""
  arr["languages"] = data.lang
  arr["page"] = data.page
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function get_srtpath(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Opensubtitles_download"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["subtitle_id"] = data.subtitle_id
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function upload_srt(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  if data.box_type = 2
    arr["module"] = "Upload_tv_srt_user"
    arr["tid"] = data.mid
    arr["season"] = data.season
    arr["episode"] = data.episode
  else
    arr["module"] = "Upload_movie_srt_user"
    arr["mid"] = data.mid
  end if
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["lang"] = data.lang
  arr["language"] = data.language
  arr["format"] = data.format
  arr["charset"] = data.charset
  arr["trans_from"] = data.trans_from
  arr["srt_url"] = data.filepath
  arr["file_name"] = data.filename
  arr["open_udid"] = udid

  result = api(arr)
  return result
end function

function srt_translate(data)
  deviceinfo = CreateObject("roDeviceInfo")
  udid = deviceinfo.GetChannelClientId()
  arr = CreateObject("roAssociativeArray")
  arr["module"] = "Srttrans_v4"
  user = CreateObject("roRegistrySection", "User")
  uid = user.Read("uid_v2")
  arr["uid"] = uid
  arr["open_udid"] = udid
  if data.box_type = 2
    arr["tv_sid"] = data.sid
  else
    arr["movie_sid"] = data.sid
  end if
  arr["from"] = data.from
  arr["to"] = data.to
  arr["lang"] = data.to
  arr["language"] = data.language
  timeoutMs = 130000
  if data.content <> invalid and data.content <> ""
    arr["content"] = data.content
    timeoutMs = 60000
  end if
  result = api_call_with_timeout(arr, "https://mbpapi.shegu.net/api/api_client/index", timeoutMs)
  if result = invalid or result = ""
    return {"code":0,"msg":"Translation timed out. Please try again."}
  end if
  return parse_srt_translate_to_aa(result)
end function

function translate_as_string(val as Dynamic) as String
  if val = invalid
    return ""
  end if
  valType = Type(val)
  if valType = "roString" or valType = "String"
    return val
  end if
  return val.ToStr()
end function

function translate_cues_to_srt(cues as Object) as String
  srt = ""
  if cues = invalid
    return srt
  end if
  for each cue in cues
    num = translate_as_string(cue.num)
    time = translate_as_string(cue.time)
    content = translate_as_string(cue.content)
    if num <> "" or time <> "" or content <> ""
      srt = srt + num + chr(10) + time + chr(10) + content + chr(10) + chr(10)
    end if
  end for
  return srt
end function

function translate_cues_to_preview(cues as Object) as String
  text = ""
  if cues = invalid
    return text
  end if
  for each cue in cues
    content = translate_as_string(cue.content)
    if content <> ""
      if text <> ""
        text = text + chr(10)
      end if
      text = text + content
    end if
  end for
  return text
end function

function parse_srt_translate_response(raw as String) as String
  parsed = parse_srt_translate_to_aa(raw)
  return FormatJson(parsed)
end function

function parse_concatenated_json_line(line as String) as Object
  events = []
  chunks = line.Split("}{")
  if chunks.Count() < 2
    return events
  end if
  lastIdx = chunks.Count() - 1
  idx = 0
  for each chunk in chunks
    piece = chunk
    if idx = 0
      piece = chunk + "}"
    else if idx = lastIdx
      piece = "{" + chunk
    else
      piece = "{" + chunk + "}"
    end if
    ev = ParseJson(piece)
    if ev <> invalid and Type(ev) = "roAssociativeArray"
      events.Push(ev)
    end if
    idx = idx + 1
  end for
  return events
end function

function collect_srt_translate_events(raw as String) as Object
  events = []
  normalized = raw.Replace(chr(13) + chr(10), chr(10))
  normalized = normalized.Replace(chr(13), chr(10))
  lines = normalized.Split(chr(10))
  for each line in lines
    line = line.Trim()
    if line <> "" and Left(line, 1) = "{"
      ev = invalid
      if Instr(1, line, "}{") = 0
        ev = ParseJson(line)
      end if
      if ev <> invalid and Type(ev) = "roAssociativeArray"
        events.Push(ev)
      else
        extra = parse_concatenated_json_line(line)
        for each extraEv in extra
          events.Push(extraEv)
        end for
      end if
    end if
  end for
  return events
end function

function parse_srt_translate_to_aa(raw as String) as Object
  if raw = invalid or raw = ""
    return {"code":0,"msg":"Translation timed out. Please try again."}
  end if
  events = []
  if looksLikeNdjson(raw) = true
    events = collect_srt_translate_events(raw)
  else
    single = ParseJson(raw)
    if single <> invalid and Type(single) = "roAssociativeArray"
      events.Push(single)
    else
      events = collect_srt_translate_events(raw)
    end if
  end if
  return fold_srt_translate_events(events)
end function

function fold_srt_translate_events(events as Object) as Object
  last = invalid
  srtAcc = ""
  previewAcc = ""
  doneCount = 0
  totalCount = 0
  sawError = invalid
  for each ev in events
    if ev <> invalid and Type(ev) = "roAssociativeArray"
      last = ev
      if ev.total <> invalid
        totalCount = ev.total
      end if
      if ev.done_count <> invalid
        doneCount = ev.done_count
      end if
      if ev.code <> invalid and ev.code.ToStr() = "-3"
        msg = "This feature is only available to VIP users."
        if ev.msg <> invalid and ev.msg <> ""
          msg = ev.msg
        end if
        return {"code":-3,"msg":msg}
      end if
      if ev.type <> invalid and ev.type = "error"
        sawError = ev
      end if
      if ev.srt <> invalid and ev.srt <> ""
        srtAcc = srtAcc + ev.srt
      end if
      if ev.cues <> invalid
        srtAcc = srtAcc + translate_cues_to_srt(ev.cues)
        cuePreview = translate_cues_to_preview(ev.cues)
        if cuePreview <> ""
          if previewAcc <> ""
            previewAcc = previewAcc + chr(10) + cuePreview
          else
            previewAcc = cuePreview
          end if
        end if
      end if
    end if
  end for
  if last = invalid
    return {"code":0,"msg":"Translation failed. Please try again."}
  end if
  if last.code <> invalid and last.code.ToStr() = "-3"
    msg = "This feature is only available to VIP users."
    if last.msg <> invalid and last.msg <> ""
      msg = last.msg
    end if
    return {"code":-3,"msg":msg}
  end if
  if sawError <> invalid and previewAcc = "" and srtAcc = ""
    msg = "Translation failed"
    if sawError.msg <> invalid and sawError.msg <> ""
      msg = sawError.msg
    end if
    return {"code":0,"msg":msg,"data":{"done_count":doneCount,"total":totalCount}}
  end if
  hasResult = false
  if last.type <> invalid and last.type = "done"
    hasResult = true
  end if
  if srtAcc <> "" or previewAcc <> ""
    hasResult = true
  end if
  if last.srt_url <> invalid or last.srt_id <> invalid or last.sid <> invalid or last.srt_info <> invalid
    hasResult = true
  end if
  if hasResult = true
    data = {}
    if last.data <> invalid and Type(last.data) = "roAssociativeArray"
      data = last.data
    end if
    if last.srt_id <> invalid
      data["srt_id"] = last.srt_id
    end if
    if last.sid <> invalid
      data["sid"] = last.sid
    end if
    if last.srt_url <> invalid
      data["srt_url"] = last.srt_url
    end if
    if last.srt_info <> invalid
      data["srt_info"] = last.srt_info
    end if
    if srtAcc <> ""
      data["srt_content"] = srtAcc
    else if last.srt <> invalid
      data["srt_content"] = last.srt
    end if
    if previewAcc <> ""
      data["preview_text"] = previewAcc
    end if
    data["done_count"] = doneCount
    data["total"] = totalCount
    msg = "success"
    if last.type <> invalid and last.type <> "done"
      msg = "partial"
    end if
    return {"code":1,"msg":msg,"data":data}
  end if
  msg = "Translation failed"
  if last.msg <> invalid and last.msg <> "" and last.msg <> "ok"
    msg = last.msg
  end if
  if last.type <> invalid and (last.type = "meta" or last.type = "ping")
    msg = "Translation incomplete. Please try again."
  end if
  return {"code":0,"msg":msg,"data":{"done_count":doneCount,"total":totalCount}}
end function

function get_appinfo()
  request = CreateObject("roUrlTransfer")
  url = "https://mini-install.com/api/index/get_param_by_id.html?id=92"
  request.SetUrl(url)
  request.EnablePeerVerification(false)
  request.EnableHostVerification(false)
  response = request.GetToString()
  encryptedData2 = response.Trim()
  return encryptedData2
end function

function api(arr)
    return api_call(arr, "https://mbpapi.shegu.net/api/api_client/index")
end function

function api_thumbs(arr)
    result = api_call(arr, "https://video-thumbs-web1.shegu.net/api/api_client/index")
    if result = ""
        result = api_call(arr, "https://video-thumbs-web1.shegu.net/api/api_client")
    end if
    if result = ""
        result = api_call(arr, "https://mbpapi.shegu.net/api/api_client/index")
    end if
    return result
end function

function api_call(arr, apiUrl as String)
    return api_call_with_timeout(arr, apiUrl, 30000)
end function

function api_call_with_timeout(arr, apiUrl as String, timeoutMs as Integer)
    if apiUrl = "https://mbpapi.shegu.net/api/api_client/index"
        return mbpApiV2(arr, timeoutMs)
    end if
    arr = applyChildModeToRequest(arr)
    date = CreateObject("roDateTime")
    ' tolerate device clock skew (param error2 if expired_date < server time)
    arr["expired_date"] = date.AsSeconds() + 86400 * 30
    json = FormatJson(arr)
    data2 = CreateObject("roByteArray")
    data2.FromAsciiString(json)
    
    ' appid=28 config: appkey=83ns6Jb18sdh7p8G, skey=Jy39hl!4
    appkey = "83ns6Jb18sdh7p8G"
    cipher = CreateObject("roEVPCipher")
    cipher.Setup(true, "des-cbc", "4a793339686c2134", "7745697068546e21", 1)
    ct = cipher.Process(data2)
    ct = ct.ToBase64String()
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(appkey)
    digest = CreateObject("roEVPDigest")
    digest.Setup("md5")
    ak = digest.Process(ba)
    ba2 = CreateObject("roByteArray")
    ba2.FromAsciiString(ak+"Jy39hl!4"+ct)
    digest2 = CreateObject("roEVPDigest")
    digest2.Setup("md5")
    verify = digest.Process(ba2)
    arr2 = {"app_key":ak,"encrypt_data":ct,"verify":verify}
    json2 = FormatJson(arr2)
    ba3 = CreateObject("roByteArray")
    ba3.FromAsciiString(json2)
    param = ba3.ToBase64String()
    request = CreateObject("roUrlTransfer")
    param = request.Escape(param)
    request.SetUrl(apiUrl+"?data="+param+"&appid=28")
    request.EnablePeerVerification(false)
    request.EnableHostVerification(false)
    port = CreateObject("roMessagePort")
	  request.SetMessagePort(port)
    If (request.AsyncGetToString())
      msg = Wait(timeoutMs, request.GetPort())
      If msg = invalid Then
        request.AsyncCancel()
        return ""
      Else If Type( msg ) = "roUrlEvent" Then
        response = msg.GetString()
        result = response.Trim()
        return processApiResponse(result, arr.module)
      End If
    End If
    return ""
end function