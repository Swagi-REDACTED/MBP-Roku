'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.title = m.top.findNode("Title")
    m.error_txt = m.top.findNode("error_txt")
    m.list2 = m.top.findNode("list2")
    m.list2.observeField("itemSelected","listdetail")

    m.list2.setFocus(true)
    m.listPage = 1
end function

sub contentset()
    aa = m.top.arr
    m.title.text = m.top.arr.name
    if aa.type = "user_lists"
        arr = {"type":"user_lists","uid":aa.uid,"page":1}
    else
        arr = {"type":"film_festival","id":aa.id,"page":1}
    end if
    m.listTask = createObject("RoSGNode","GetContentReader")
    m.listTask.content = arr
    m.listTask.observeField("content", "getlist")
    m.listTask.control = "RUN"
end sub

function getlist()
    if m.listTask.content.type <> invalid
        return false
    end if
    if m.listTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return false
    end if
    if m.listTask.content.code <= 0
        m.error_txt.text = m.listTask.content.msg
        m.error_txt.visible = true
        return false
    end if
    content = m.listTask.content
    m.list2.content = ListToContentNode(content.data)
    m.list2.setFocus(true)
end function

sub listdetail()
    list = m.list2.content.getChild(m.list2.itemSelected)
    data = {"id":list.data.lid}
    m.list_detail = createObject("roSGNode", "PlayList2")
    m.list_detail.arr = data
    m.top.appendChild(m.list_detail)
end sub

sub listScroll()
    if m.listPageStatus = invalid
        m.listPageStatus = false
    end if
    if m.listPageStatus = false
        m.listPageStatus = true
        m.listPage = m.listPage + 1
        aa = m.top.arr
        if aa.type = "user_lists"
            arr = {"type":"user_lists","uid":aa.uid,"page":m.listPage}
        else
            arr = {"type":"film_festival","id":aa.id,"page":m.listPage}
        end if
        m.listTask = createObject("RoSGNode","GetContentReader")
        m.listTask.content = arr
        m.listTask.observeField("content", "addList")
        m.listTask.control = "RUN"
    end if
end sub

sub addList()
    m.listPageStatus = false
    if m.listTask.content = invalid
        m.listPage = m.listPage - 1
        return
    end if
    if m.listTask.content.data.Count() > 0
        arr = ListToContentNode2(m.listTask.content.data)
        m.list2.content.appendChildren(arr)
        m.list2.jumpToItem = m.list2.itemFocused + 3
    else
        m.listPage = m.listPage - 1
    end if
end sub

function ListToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.imgArr[0]
        data = CreateObject("roAssociativeArray")
        data["lid"] = key.lid
        data["count"] = key.count
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

function ListToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.imgArr[0]
        data = CreateObject("roAssociativeArray")
        data["lid"] = key.lid
        data["count"] = key.count
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "down" then
            listScroll()
            result = true
        elseif key = "back"
            if m.list_detail <> invalid and m.list_detail.visible = true
                m.top.removeChild(m.list_detail)
                m.list_detail = invalid
                m.list2.setFocus(true)
                return true
            end if
        end if
    end if
    return result
end function