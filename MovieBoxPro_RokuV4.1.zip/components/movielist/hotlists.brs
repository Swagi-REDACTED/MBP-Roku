'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.title = m.top.findNode("Title")
    m.error_txt = m.top.findNode("error_txt")
    m.list2 = m.top.findNode("list2")
    m.list2.observeField("itemSelected","listdetail")

    m.list2.setFocus(true)
    m.listPage = 1
end function

sub contentset()
    aa = m.top.arr
    m.title.text = m.top.arr.name
    if aa.type = "compilations"
        arr = {"type":"playlist","type2":aa.type,"page":1,"limit":24}
    else
        arr = {"type":"playlist","type2":aa.type,"page":1,"limit":18}
    end if
    m.listTask = createObject("RoSGNode","GetContentReader")
    m.listTask.content = arr
    m.listTask.observeField("content", "getlist")
    m.listTask.control = "RUN"
end sub

function getlist()
    if m.listTask.content.type <> invalid
        return false
    end if
    if m.listTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return false
    end if
    if m.listTask.content.code <= 0
        m.error_txt.text = m.listTask.content.msg
        m.error_txt.visible = true
        return false
    end if
    content = m.listTask.content
    aa = m.top.arr
    if aa.type = "compilations"
        m.list2.content = FestivalToContentNode(content.data)
    else
        m.list2.content = ListToContentNode(content.data)
    end if
    m.list2.setFocus(true)
end function

sub listdetail()
    list = m.list2.content.getChild(m.list2.itemSelected)
    if list.data <> invalid
        data = {"id":list.data.lid}
        list_detail = createObject("roSGNode", "PlayList2")
        list_detail.arr = data
        list_detail.id = "list_detail"
        m.top.appendChild(list_detail)
        m.list_detail = m.top.findNode("list_detail")
    else
        data = {"id":list.id,"name":list.title,"type":"film_festival"}
        movielists = createObject("roSGNode", "MovieList2")
        movielists.arr = data
        movielists.id = "movielists2"
        m.top.appendChild(movielists)
        m.movielists2 = m.top.findNode("movielists2")
    end if
end sub

sub listScroll()
    if m.listPageStatus = invalid
        m.listPageStatus = false
    end if
    if m.listPageStatus = false
        m.listPageStatus = true
        m.listPage = m.listPage + 1
        aa = m.top.arr
        if aa.type = "compilations"
            arr = {"type":"playlist","type2":aa.type,"page":m.listPage,"limit":24}
        else
            arr = {"type":"playlist","type2":aa.type,"page":m.listPage,"limit":18}
        end if
        m.listTask = createObject("RoSGNode","GetContentReader")
        m.listTask.content = arr
        m.listTask.observeField("content", "addList")
        m.listTask.control = "RUN"
    end if
end sub

sub addList()
    m.listPageStatus = false
    if m.listTask.content = invalid
        m.listPage = m.listPage - 1
        return
    end if
    if m.listTask.content.data.Count() > 0
        aa = m.top.arr
        if aa.type = "compilations"
            arr = FestivalToContentNode2(m.listTask.content.data)
            m.list2.content.appendChildren(arr)
            m.list2.jumpToItem = m.list2.itemFocused + 4
        else
            arr = ListToContentNode2(m.listTask.content.data)
            m.list2.content.appendChildren(arr)
            m.list2.jumpToItem = m.list2.itemFocused + 3
        end if
    else
        m.listPage = m.listPage - 1
    end if
end sub

function ListToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.imgArr[0]
        data = CreateObject("roAssociativeArray")
        data["lid"] = key.lid
        data["count"] = key.count
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

function ListToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.imgArr[0]
        data = CreateObject("roAssociativeArray")
        data["lid"] = key.lid
        data["count"] = key.count
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

function FestivalToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.id = key.id
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.cover
    end for
    return ContentNode
end function

function FestivalToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.id = key.id
        ItemContent.title = key.name
        ItemContent.hdposterurl = key.cover
        arr.Push(ItemContent)
    end for
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "down" then
            listScroll()
        elseif key = "back" then
            if m.list_detail <> invalid and m.list_detail.visible = true
                m.top.removeChild(m.list_detail)
                m.list_detail = invalid
                m.list2.setFocus(true)
                return true
            end if
            if m.movielists2 <> invalid and m.movielists2.visible = true
                m.top.removeChild(m.movielists2)
                m.movielists2 = invalid
                m.list2.setFocus(true)
                return true
            end if
        end if
    end if
    return result
end function