'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.title = m.top.findNode("Title")
    m.desc = m.top.findNode("desc")
    m.avatar = m.top.findNode("avatar")
    m.username = m.top.findNode("username")
    m.add_time = m.top.findNode("add_time")
    m.userbg = m.top.findNode("userbg")
    m.border = m.top.findNode("border")
    m.error_txt = m.top.findNode("error_txt")
    m.error_tip = m.top.findNode("error_tip")
    m.error_msg = m.top.findNode("error_msg")

    m.listbtn = m.top.findNode("listbtn")
    m.listbtn.observeField("itemSelected","btnoperate")
    
    m.sortbg = m.top.findNode("sortbg")
    m.sortlist = m.top.findNode("sortlist")
    m.sortlist.observeField("itemSelected","setsort")

    m.movies = m.top.findNode("movies")
    m.movies.observeField("itemSelected","listMovieDetail")
    m.movies.setFocus(true)
    m.listPage = 1
    m.playRequestId = 0
end function

sub contentset()
    aa = m.top.arr
    arr = {"type":"playlist_detail","id":aa.id,"page":1}
    m.moviesTask = createObject("RoSGNode","GetContentReader")
    m.moviesTask.content = arr
    m.moviesTask.observeField("content", "getmovies")
    m.moviesTask.control = "RUN"
end sub

function getmovies()
    if m.moviesTask.content.type <> invalid
        return false
    end if
    if m.moviesTask.content = invalid
        m.error_txt.text = "Content acquisition failed. Please return and try again"
        m.error_txt.visible = true
        return false
    end if
    if m.moviesTask.content.code <= 0
        m.error_txt.text = m.moviesTask.content.msg
        m.error_txt.visible = true
        return false
    end if
    content = m.moviesTask.content

    contentRoot2 = createObject("roSGNode", "ContentNode")
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "shuffle"
    child2.hdposterurl = "pkg:/images/shuffle.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "sort"
    child2.hdposterurl = "pkg:/images/sort.png"
    child2 = contentRoot2.createChild("ContentNode")
    child2.title = "fav"
    if content.data.is_collect = 1
        child2.hdposterurl = "pkg:/images/faved2.png"
    else
        child2.hdposterurl = "pkg:/images/fav2.png"
    end if
    data = CreateObject("roAssociativeArray")
    data["is_collect"] = content.data.is_collect
    child2.addField("data", "assocarray", false)
    child2.data = data
    m.listbtn.content = contentRoot2

    m.userbg.addField("data", "assocarray", false)
    m.userbg.data = {"uid":content.data.uid,"name":content.data.username}
    m.title.text = content.data.name
    m.desc.text = content.data.desc
    m.avatar.uri = content.data.avatar
    m.username.text = content.data.username
    date = CreateObject("roDateTime")
    date.FromSeconds(content.data.dateline)
    time = date.asDateStringLoc("dd-MM-y")
    m.add_time.text = time
    m.movies.content = ListToContentNode(content.data.list)
    m.movies.setFocus(true)
end function

function btnoperate()
    index = m.listbtn.itemSelected
    if index = 0
        num = m.movies.content.getChildCount()
        rand = Rnd(num)
        movie = m.movies.content.getChild(rand-1)
        m.moviedata = FormatJson(movie.data)
        arr = movie.data
        m.loading = CreateObject("roSGNode", "Loading")
        m.top.appendChild(m.loading)
        m.shuffle = 1
        arr["type"] = "movie_detail"
        m.getdetailContentTask = createObject("RoSGNode","GetContentReader")
        m.getdetailContentTask.content = arr
        m.getdetailContentTask.observeField("content", "getplay")
        m.getdetailContentTask.control = "RUN"
    elseif index = 1
        m.sortbg.visible = true
        m.sortlist.setFocus(true)
    elseif index = 2
        m.btn = m.listbtn.content.getChild(m.listbtn.itemSelected)
        aa = m.top.arr
        if m.btn.data.is_collect = 1
            arr = {"type":"playlist_collect","id":aa.id,"type2":"del"}
            m.is_collect = 0
        else
            arr = {"type":"playlist_collect","id":aa.id,"type2":"add"}
            m.is_collect = 1
        end if
        m.addcollectTask = createObject("RoSGNode","GetContentReader")
        m.addcollectTask.content = arr
        m.addcollectTask.observeField("content", "collect2")
        m.addcollectTask.control = "RUN"
    end if
end function

sub getplay()
    arr = m.getdetailContentTask.content
    if arr = invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
        m.error_msg.text = "Playback failed"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if arr.type <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
        return
    end if
    if arr.code <= 0
        m.top.removeChild(m.loading)
        m.loading = invalid
        m.error_msg.text = arr.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if arr.data.box_type = 2
        m.elist = arr.data.episode
        data = ParseJson(m.moviedata)
        if arr.data.history <> invalid and arr.data.history.episode <> invalid
            for each item in arr.data.episode
                if arr.data.history.episode = item.episode
                    data["imdb_id"] = item.imdb_id
                    exit for
                end if
            end for
            data["season"] = arr.data.history.season
            data["episode"] = arr.data.history.episode
            if arr.data.history.seconds <> invalid
                data["seconds"] = arr.data.history.seconds
            end if
        else
            data["imdb_id"] = arr.data.episode[0].imdb_id
            data["season"] = arr.data.episode[0].season
            data["episode"] = arr.data.episode[0].episode
        end if
        if arr.data.season <> invalid
            data["season_list"] = arr.data.season
        end if
        if arr.data.max_season <> invalid
            data["max_season"] = arr.data.max_season
        end if
        m.moviedata = FormatJson(data)
    else
        data = ParseJson(m.moviedata)
        data["imdb_id"] = arr.data.imdb_id
        if arr.data.plan_watched <> invalid
            data["plan_watched"] = arr.data.plan_watched
        end if
        if arr.data.seconds <> invalid
            data["seconds"] = arr.data.seconds
        end if
        m.moviedata = FormatJson(data)
    end if
    ' m.loading = CreateObject("roSGNode", "Loading")
    ' m.top.appendChild(m.loading)
    m.shuffle = 1
    startVideoContentReader(m, m.moviedata)
end sub

sub setplaydata()
    if isStaleVideoPlayRequest(m)
        return
    end if
    finishVideoContentRequest(m)
    if m.loading = invalid and m.video_play = invalid
        return
    end if
    if m.loading <> invalid
        m.top.removeChild(m.loading)
        m.loading = invalid
    end if
    m.videoinfo = m.readVideoContentTask.videoinfo
    if m.videoinfo = invalid
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.listbtn.setFocus(true)
        m.error_msg.text = "Playback failed, please try again"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    if m.videoinfo.code <> invalid and m.videoinfo.code <= 0
        if m.video <> invalid
            m.video.control = "stop"
        end if
        m.listbtn.setFocus(true)
        m.error_msg.text = m.videoinfo.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return
    end if
    m.videoinfo["content"] = m.readVideoContentTask.videocontent
    if m.video_play <> invalid
        m.video.control = "stop"
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        m.video_play.content = m.videoinfo
        m.video_play.visible = true
        if m.video <> invalid
            m.video.visible = true
        end if
    else
        m.videoinfo["moviedata"] = ParseJson(m.moviedata)
        applyResumeSeconds(m.videoinfo)
        video_play = createObject("roSGNode", "videoPlay")
        video_play.content = m.videoinfo
        video_play.id = "video_play"
        m.top.appendChild(video_play)
        m.video_play = m.top.findNode("video_play")
        m.video_play.observeField("next_episode", "autonext")
        m.video_play.observeField("play_episode", "onPlayEpisodeSelected")
        m.video = m.video_play.findNode("my_video")
        m.video.observeField("state", "controlvideoplay")
        m.video_play.setFocus(true)
    end if

    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 300
    m.timer.repeat = true
    m.timer.control = "start"
    m.timer.ObserveField("fire","progressSave")
end sub

function user_playlists()
    arr = m.userbg.data
    data = {"uid":arr.uid,"name":arr.name+"'s PlayLists","type":"user_lists"}
    m.user_movielists = createObject("roSGNode", "MovieList2")
    m.user_movielists.arr = data
    m.top.appendChild(m.user_movielists)
end function

function setsort()
    index = m.sortlist.itemSelected
    aa = m.top.arr
    if index = 0
        arr = {"type":"playlist_detail","id":aa.id,"page":1}
        m.sort = invalid
    elseif index = 1
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"name","sort":"asc","page":1}
        m.sort = {"sort_by":"name","sort":"asc"}
    elseif index = 2
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"name","sort":"desc","page":1}
        m.sort = {"sort_by":"name","sort":"desc"}
    elseif index = 3
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"add_time","sort":"desc","page":1}
        m.sort = {"sort_by":"add_time","sort":"desc"}
    elseif index = 4
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"add_time","sort":"asc","page":1}
        m.sort = {"sort_by":"add_time","sort":"asc"}
    elseif index = 5
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"released","sort":"desc","page":1}
        m.sort = {"sort_by":"released","sort":"desc"}
    elseif index = 6
        arr = {"type":"playlist_detail2","id":aa.id,"sort_by":"released","sort":"asc","page":1}
        m.sort = {"sort_by":"released","sort":"asc"}
    end if
    m.moviesortTask = createObject("RoSGNode","GetContentReader")
    m.moviesortTask.content = arr
    m.moviesortTask.observeField("content", "movies_sort")
    m.moviesortTask.control = "RUN"
    m.sortbg.visible = false
    m.listbtn.setFocus(true)
end function

function movies_sort()
    if m.moviesortTask.content.type <> invalid
        return false
    end if
    status = 0
    if m.moviesortTask.content = invalid
        m.error_msg.text = "List sorting failed"
        m.error_tip.visible = true
        status = 1
    end if
    if m.moviesortTask.content.code <= 0
        m.error_msg.text = m.moviesortTask.content.msg
        m.error_tip.visible = true
        status = 1
    end if
    if status = 1
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return false
    end if
    content = m.moviesortTask.content
    m.movies.content = ListToContentNode(content.data.list)
end function

function collect2()
    content = m.addcollectTask.content
    if content.type <> invalid
        return false
    end if
    if content = invalid
        m.error_msg.text = "Collection failed"
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return false
    end if
    if content.code <= 0
        m.error_msg.text = content.msg
        m.error_tip.visible = true
        m.msgtimer = CreateObject("roSGNode", "Timer")
        m.msgtimer.duration = 3
        m.msgtimer.control = "start"
        m.msgtimer.ObserveField("fire","hidemsg")
        return false
    end if
    if m.is_collect = 1
        m.btn.update({"hdposterurl":"pkg:/images/faved2.png"}, false)
        m.btn.update({"data":{"is_collect":1}}, false)
    else
        m.btn.update({"hdposterurl":"pkg:/images/fav2.png"}, false)
        m.btn.update({"data":{"is_collect":0}}, false)
    end if
end function

sub listMovieDetail()
    movie = m.movies.content.getChild(m.movies.itemSelected)
    arr3 = movie.data
    arr3["title"] = movie.title
    arr3["cover"] = movie.hdposterurl
    m.moviedata = FormatJson(arr3)
    m.detail = createObject("roSGNode", "DetailScreen")
    m.detail.movieid = m.moviedata
    m.top.appendChild(m.detail)
    m.operates = m.detail.findNode("operates")
    m.operates.setFocus(true)
end sub

sub progressSave()
    runtime = m.video.duration
    seconds = m.video.position
    video = m.videoinfo.list[0]
    
    arr = ParseJson(m.moviedata)
    
    if arr.box_type = 2
        arr["mp4_id"] = video.tmfid
    else
        arr["mp4_id"] = video.mmfid
    end if
    arr["seconds"] = Int(seconds)
    if runtime - seconds < 300
        arr["over"] = 1
    else
        arr["over"] = 0
    end if
    persistPlayProgress(m, arr.seconds, arr.over)
    arr["type"] = "progress_save"

    moviearr = ParseJson(m.moviedata)
    moviearr["seconds"] = Int(seconds)
    m.moviedata = FormatJson(moviearr)

    m.saveContentTask = createObject("RoSGNode","GetContentReader")
    m.saveContentTask.content = arr
    ' m.saveContentTask.observeField("content", "refresh_home")
    m.saveContentTask.control = "RUN"
end sub

sub controlvideoplay()
    if m.video.state = "finished" and isNaturalPlaybackFinish(m.video)
        m.timer.control = "stop"
        progressSave()
        arr = ParseJson(m.moviedata)
        if arr.box_type = 2
            e_list = m.elist
            next2 = 0
            for each item in e_list
                if item.episode > arr.episode
                    arr.imdb_id = item.imdb_id
                    arr.episode = item.episode
                    if item.play_progress.over = 1
                        arr.seconds = 0
                    else
                        arr.seconds = item.play_progress.seconds
                    end if
                    next2 = 1
                    exit for
                end if
            end for
            if next2 = 1
                m.moviedata = FormatJson(arr)
                startVideoContentReader(m, m.moviedata)
            else
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.listbtn.setFocus(true)
            end if
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.listbtn.setFocus(true)
        end if
    end if
end sub

sub autonext()
    m.timer.control = "stop"
    progressSave()
    arr = ParseJson(m.moviedata)
    if arr.box_type = 2
        e_list = m.elist
        next2 = 0
        for each item in e_list
            if item.episode > arr.episode
                arr.imdb_id = item.imdb_id
                arr.episode = item.episode
                if item.play_progress.over = 1
                    arr.seconds = 0
                else
                    arr.seconds = item.play_progress.seconds
                end if
                next2 = 1
                exit for
            end if
        end for
        if next2 = 1
            m.moviedata = FormatJson(arr)
            startVideoContentReader(m, m.moviedata)
        else
            m.video.control = "stop"
            m.top.removeChild(m.video_play)
            m.video_play = invalid
            m.listbtn.setFocus(true)
        end if
    end if
end sub

function hidemsg()
    m.error_tip.visible = false
end function

sub movieScroll()
    if m.listPageStatus = invalid
        m.listPageStatus = false
    end if
    if m.listPageStatus = false
        m.listPageStatus = true
        m.listPage = m.listPage + 1
        aa = m.top.arr
        if m.sort <> invalid
            arr = {"type":"playlist_detail2","id":aa.id,"sort_by":m.sort.sort_by,"sort":m.sort.sort,"page":m.listPage}
        else
            arr = {"type":"playlist_detail","id":aa.id,"page":m.listPage}
        end if
        m.listTask = createObject("RoSGNode","GetContentReader")
        m.listTask.content = arr
        m.listTask.observeField("content", "addmovieList")
        m.listTask.control = "RUN"
    end if
end sub

sub addmovieList()
    m.listPageStatus = false
    if m.listTask.content = invalid
        m.listPage = m.listPage - 1
        return
    end if
    if m.listTask.content.data.list.Count() > 0
        arr = ListToContentNode2(m.listTask.content.data.list)
        m.movies.content.appendChildren(arr)
        m.movies.jumpToItem = m.movies.itemFocused + 6
    else
        m.listPage = m.listPage - 1
    end if
end sub

function ListToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in Content
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.box_type = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for
    return ContentNode
end function

function ListToContentNode2(Content as Object) as Object
    arr = []
    for each key in Content
        ItemContent = createObject("RoSGNode","ContentNode")
        ItemContent.title = key.title
        ItemContent.hdposterurl = key.poster
        data = CreateObject("roAssociativeArray")
        data["mid"] = key.id
        data["box_type"] = key.box_type
        data["imdb_rating"] = key.imdb_rating
        data["tomato_meter"] = key.tomato_meter
        if key.tomato_meter_state <> invalid
            data["tomato_meter_state"] = key.tomato_meter_state
        else
            data["tomato_meter_state"] = ""
        end if
        if key.box_type = 2
            if key.season_episode <> invalid
                data["season_episode"] = key.season_episode
            end if
        else
            if key.quality_tag_new <> invalid
                data["quality_tag_new"] = key.quality_tag_new
            end if
        end if
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
        arr.Push(ItemContent)
    end for
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "up" then
            if m.sortbg.visible = true
                return true
            end if
            if m.user_movielists <> invalid and m.user_movielists.visible = true
                return true
            end if
            m.listbtn.setFocus(true)
            result = true
        elseif key = "down" then
            if m.sortbg.visible = true
                return true
            end if
            if m.user_movielists <> invalid and m.user_movielists.visible = true
                return true
            end if
            if m.listbtn.hasFocus() = true or m.userbg.hasFocus() = true
                m.border.visible = false
                m.movies.setFocus(true)
            else
                movieScroll()
            end if
            result = true
        else if key = "OK" then
            if m.userbg.hasFocus() = true
                user_playlists()
            end if
        elseif key = "right" then
            if m.listbtn.hasFocus() = true
                m.border.visible = true
                m.userbg.setFocus(true)
                result = true
            end if
        elseif key = "left" then
            if m.userbg.hasFocus() = true
                m.border.visible = false
                m.listbtn.setFocus(true)
                result = true
            end if
        elseif key = "back" then
            if m.video_play <> invalid and m.video_play.visible = true
                m.timer.control = "stop"
                progressSave()
                m.video.control = "stop"
                m.top.removeChild(m.video_play)
                m.video_play = invalid
                m.listbtn.setFocus(true)
                return true
            end if
            if m.detail <> invalid and m.detail.visible = true
                m.top.removeChild(m.detail)
                m.detail = invalid
                m.movies.setFocus(true)
                return true
            end if
            if m.user_movielists <> invalid and m.user_movielists.visible = true
                m.top.removeChild(m.user_movielists)
                m.user_movielists = invalid
                m.userbg.setFocus(true)
                return true
            end if
            if m.error_tip.visible = true
                m.error_tip.visible = false
                return true
            end if
            if m.sortbg.visible = true
                m.sortbg.visible = false
                m.listbtn.setFocus(true)
                result = true
            end if
        end if
    end if
    return result
end function