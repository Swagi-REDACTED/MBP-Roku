' API v2 wire format verified against Android TV 13.3 (version code 125).
' This client requires Roku OS 15.2+ for roEVPCipher.GetTag().
function mbpV2Payload(business as Object, environment as Object) as Object
    payload = {}
    for each key in business
        if key <> "module"
            payload[key] = business[key]
        end if
    end for
    for each key in environment
        if key <> "numeric_uid" and payload.DoesExist(key) = false and (key <> "uid" or environment[key] <> "")
            payload[key] = environment[key]
        end if
    end for
    return payload
end function

function mbpV2UsesAppCrypto(module as String) as Boolean
    modules = "Add_captcha,Add_qrcode,Login,Login_captcha,Login_captcha_v2,Login_google,Login_google_v2,Login_qrcode,Login_qrcode_v2,Login_thirdpart,Register_v3,Register_is_need_code,DeleteCode,Recommend_username,Device_delete,Network_test,Ip_info,Test_network_feedback,Test_network_url,Test_network_url_v2,Advertisement,Advertisement_notify,Advertisement_v2,Advertisement_v3,Agreement_list,Agreement_status,Agreement_transactions,Article_list,Common_problems,Appstore_active,Invite_active"
    return Instr(1, "," + modules + ",", "," + module + ",") > 0
end function

function mbpV2Outer(module as String, environment as Object, session as Dynamic, encrypted as String) as Object
    outer = { appid: "27", crypto: "app", data: encrypted, platform: "android_tv", app_version: "13.3" }
    if environment.numeric_uid <> invalid and environment.numeric_uid <> ""
        outer.uid = environment.numeric_uid
    end if
    if mbpV2UsesAppCrypto(module) = false and Type(session) = "roAssociativeArray"
        if mbpV2String(session.session_key) <> ""
            outer.crypto = "session"
            outer.open_udid = environment.open_udid
            if mbpV2String(session.sk_ver) <> ""
                outer.sk_ver = mbpV2String(session.sk_ver)
            end if
        end if
    end if
    return outer
end function

function mbpV2String(value as Dynamic) as String
    if value = invalid then return ""
    if GetInterface(value, "ifString") <> invalid then return value
    if GetInterface(value, "ifInt") <> invalid or GetInterface(value, "ifLongInt") <> invalid or GetInterface(value, "ifFloat") <> invalid or GetInterface(value, "ifDouble") <> invalid
        return value.ToStr()
    end if
    return ""
end function

function mbpV2Normalize(parsed as Dynamic, module as String) as Dynamic
    if Type(parsed) <> "roAssociativeArray" then return parsed
    if module <> "Login_captcha_v2" and module <> "User_token" then return parsed
    if GetInterface(parsed.data, "ifString") <> invalid
        parsed.data = ParseJson(parsed.data)
    end if
    if module <> "Login_captcha_v2" or Type(parsed.data) <> "roAssociativeArray" then return parsed
    data = parsed.data
    for each key in ["appid", "avatar", "bind_gmail", "email", "nickname", "username", "uid_v2"]
        data[key] = mbpV2String(data[key])
    end for
    for each key in ["uid", "family", "isvip", "dead_time"]
        if data[key] = invalid
            data[key] = 0
        else if GetInterface(data[key], "ifString") <> invalid
            data[key] = Val(data[key])
        end if
    end for
    return parsed
end function

function mbpV2CodeResult(parsed as Dynamic) as Object
    result = { code: "", login_error: "Could not load a login code. Select Refresh to retry." }
    if Type(parsed) <> "roAssociativeArray" then return result
    if mbpV2String(parsed.code) <> "1"
        message = mbpV2String(parsed.msg)
        if message <> "" then result.login_error = "Login code request failed: " + Left(message, 180)
        return result
    end if
    if Type(parsed.data) <> "roAssociativeArray" then return result
    code = mbpV2String(parsed.data.code)
    if Len(code) <> 8 then return result
    result.code = code
    result.login_error = ""
    return result
end function

function mbpV2SessionInvalid(parsed as Dynamic) as Boolean
    if Type(parsed) <> "roAssociativeArray" then return false
    if mbpV2String(parsed.code) = "1" then return false
    if mbpV2String(parsed.code) = "-10001" or mbpV2String(parsed.code) = "-10022" then return false
    return Instr(1, LCase(mbpV2String(parsed.msg)), "session_key") > 0
end function

function mbpV2Environment() as Object
    deviceInfoV2 = CreateObject("roDeviceInfo")
    user = CreateObject("roRegistrySection", "User")
    return {
        app_version: "13.3", channel: "movie", platform: "android_tv", lang: "en"
        open_udid: deviceInfoV2.GetChannelClientId(), device_model: deviceInfoV2.GetModel()
        device_name: deviceInfoV2.GetModelDisplayName(), platform_version: "android_tv"
        appid: "com.movieboxpro.androidtv", childmode: getChildModeApiValue()
        expired_date: CreateObject("roDateTime").AsSeconds() + 43200
        uid: user.Read("uid_v2"), numeric_uid: user.Read("uid")
    }
end function

function mbpV2ReadSession(uid as String) as Dynamic
    if uid = "" then return invalid
    store = CreateObject("roRegistrySection", "ApiSessionV2")
    raw = store.Read(uid)
    if raw = "" then return invalid
    session = ParseJson(raw)
    if Type(session) <> "roAssociativeArray" then return invalid
    if mbpV2String(session.session_key) = "" then return invalid
    return session
end function

sub mbpV2SaveSession(uid as String, session as Object)
    if uid = "" or mbpV2String(session.session_key) = "" then return
    store = CreateObject("roRegistrySection", "ApiSessionV2")
    store.Write(uid, FormatJson(session))
    store.Flush()
end sub

function mbpV2Encrypt(payload as Object, secret as String, appKey as String, nonceHex = "" as String) as String
    digest = CreateObject("roEVPDigest")
    digest.Setup("sha256")
    secretBytes = CreateObject("roByteArray")
    secretBytes.FromAsciiString(secret)
    keyHex = digest.Process(secretBytes)
    keyBytes = CreateObject("roByteArray")
    keyBytes.FromHexString(keyHex)
    if nonceHex = ""
        randomBytes = CreateObject("roByteArray")
        randomBytes.FromAsciiString(CreateObject("roDeviceInfo").GetRandomUUID())
        nonceHex = Left(digest.Process(randomBytes), 24)
    end if
    nonce = CreateObject("roByteArray")
    nonce.FromHexString(nonceHex)
    if nonce.Count() <> 12 then return ""
    cipher = CreateObject("roEVPCipher")
    if cipher.Setup(true, "aes-256-gcm", keyHex, nonceHex, 0) <> 0 then return ""
    plaintext = CreateObject("roByteArray")
    plaintext.FromAsciiString(FormatJson(payload))
    ciphertext = cipher.Process(plaintext)
    tag = cipher.GetTag()
    if ciphertext = invalid or tag = invalid then return ""
    digest.Setup("md5")
    appBytes = CreateObject("roByteArray")
    appBytes.FromAsciiString(appKey)
    appHash = LCase(digest.Process(appBytes))
    n = nonce.ToBase64String()
    ct = ciphertext.ToBase64String()
    authTag = tag.ToBase64String()
    message = CreateObject("roByteArray")
    message.FromAsciiString(appHash + n + ct + authTag)
    hmac = CreateObject("roHMAC")
    if hmac.Setup("sha256", keyBytes) <> 0 then return ""
    signature = hmac.Process(message)
    envelope = { v: 2, app_key: appHash, nonce: n, ciphertext: ct, tag: authTag, verify: LCase(signature.ToHexString()) }
    encoded = CreateObject("roByteArray")
    encoded.FromAsciiString(FormatJson(envelope))
    return encoded.ToBase64String()
end function

function mbpV2Transport(module as String, payload as Object, environment as Object, session as Dynamic, timeoutMs as Integer) as String
    config = ParseJson(ReadAsciiFile("pkg:/components/api_config.json"))
    if Type(config) <> "roAssociativeArray" then return FormatJson({code:0,msg:"API configuration is missing"})
    secret = config.app_skey
    if mbpV2UsesAppCrypto(module) = false and Type(session) = "roAssociativeArray"
        if mbpV2String(session.session_key) <> "" then secret = session.session_key
    end if
    encrypted = mbpV2Encrypt(payload, secret, config.app_key)
    if encrypted = "" then return FormatJson({code:0,msg:"Unable to encrypt API request; Roku OS 15.2 or newer is required"})
    outer = mbpV2Outer(module, environment, session, encrypted)
    request = CreateObject("roUrlTransfer")
    request.SetCertificatesFile("common:/certs/ca-bundle.crt")
    request.EnablePeerVerification(true)
    request.EnableHostVerification(true)
    request.AddHeader("Content-Type", "application/x-www-form-urlencoded")
    request.AddHeader("Accept", "text/plain; charset=utf-8")
    request.AddHeader("Platform", "android_tv")
    request.SetUrl("https://mbpssl.shegu.net/api/" + request.Escape(module))
    body = ""
    for each key in outer
        if body <> "" then body = body + "&"
        body = body + request.Escape(key) + "=" + request.Escape(mbpV2String(outer[key]))
    end for
    port = CreateObject("roMessagePort")
    request.SetMessagePort(port)
    if request.AsyncPostFromString(body) = false then return FormatJson({code:0,msg:"Could not start API request"})
    event = Wait(timeoutMs, port)
    if event = invalid
        request.AsyncCancel()
        return FormatJson({code:0,msg:"API request timed out. Please retry."})
    end if
    if Type(event) <> "roUrlEvent" then return FormatJson({code:0,msg:"Unexpected API response"})
    status = event.GetResponseCode()
    if status < 200 or status >= 300
        print "[api-v2] "; module; " HTTP "; status
        return FormatJson({code:0,msg:"API HTTP error " + status.ToStr()})
    end if
    return event.GetString().Trim()
end function

function mbpV2Refresh(environment as Object, session as Dynamic, timeoutMs as Integer) as Dynamic
    payload = mbpV2Payload({uid:environment.uid}, environment)
    response = mbpV2Transport("User_token", payload, environment, session, timeoutMs)
    parsed = mbpV2Normalize(ParseJson(response), "User_token")
    if Type(parsed) <> "roAssociativeArray" then return invalid
    if mbpV2String(parsed.code) <> "1" or Type(parsed.data) <> "roAssociativeArray" then return invalid
    data = parsed.data
    if mbpV2String(data.session_key) = "" or mbpV2String(data.uid) = "" then return invalid
    renewed = { session_key: data.session_key, sk_ver: mbpV2String(data.sk_ver), uid_v2: data.uid, uid_v2_exp: data.uid_v2_exp }
    mbpV2SaveSession(environment.numeric_uid, renewed)
    user = CreateObject("roRegistrySection", "User")
    if user.Read("uid") = environment.numeric_uid
        user.Write("uid_v2", renewed.uid_v2)
        user.Flush()
    end if
    environment.uid = renewed.uid_v2
    return renewed
end function

function mbpApiV2(business as Object, timeoutMs = 30000 as Integer) as String
    module = mbpV2String(business.module)
    if module = "" then return FormatJson({code:0,msg:"Missing API module"})
    version = CreateObject("roDeviceInfo").GetOSVersion()
    if Val(mbpV2String(version.major)) < 15 or (Val(mbpV2String(version.major)) = 15 and Val(mbpV2String(version.minor)) < 2)
        return FormatJson({code:0,msg:"Please update Roku OS to 15.2 or newer for sign-in"})
    end if
    environment = mbpV2Environment()
    session = mbpV2ReadSession(environment.numeric_uid)
    if Type(session) = "roAssociativeArray" and mbpV2String(session.uid_v2) <> ""
        environment.uid = session.uid_v2
    end if
    payload = mbpV2Payload(business, environment)
    if business.uid <> invalid and environment.uid <> "" then payload.uid = environment.uid
    response = mbpV2Transport(module, payload, environment, session, timeoutMs)
    if response = "" or looksLikeNdjson(response) then return response
    parsed = mbpV2Normalize(ParseJson(response), module)
    if Type(parsed) <> "roAssociativeArray" then return FormatJson({code:0,msg:"Invalid API response"})
    if mbpV2SessionInvalid(parsed) and environment.numeric_uid <> "" and module <> "User_token" and mbpV2UsesAppCrypto(module) = false
        latest = mbpV2ReadSession(environment.numeric_uid)
        if Type(latest) = "roAssociativeArray" and Type(session) = "roAssociativeArray" and latest.session_key <> session.session_key
            session = latest
            environment.uid = session.uid_v2
        else
            session = mbpV2Refresh(environment, session, timeoutMs)
        end if
        if Type(session) = "roAssociativeArray"
            payload.uid = environment.uid
            response = mbpV2Transport(module, payload, environment, session, timeoutMs)
            parsed = mbpV2Normalize(ParseJson(response), module)
        end if
    end if
    if module = "Login_captcha_v2" and Type(parsed) = "roAssociativeArray"
        if mbpV2String(parsed.code) = "1" and Type(parsed.data) = "roAssociativeArray"
            data = parsed.data
            if data.uid <= 0 or data.uid_v2 = "" or mbpV2String(data.session_key) = ""
                return FormatJson({code:0,msg:"Login response did not contain a session. Please refresh the code."})
            end if
            entry = {session_key:data.session_key,sk_ver:mbpV2String(data.sk_ver),uid_v2:data.uid_v2,uid_v2_exp:data.uid_v2_exp}
            mbpV2SaveSession(mbpV2String(data.uid), entry)
            ' Keep session keys inside the Task/registry, out of SceneGraph callbacks.
            data.Delete("session_key")
        end if
    end if
    return processApiResponse(FormatJson(parsed), module)
end function
