'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function Init()
    m.top.ObserveField("visible", "onVisibleChange")

    m.categoryList = m.top.FindNode("categoryList")
    ' observe "itemFocused" so we can know which season gain focus
    m.categoryList.ObserveField("itemFocused", "OnCategoryItemFocused")
    m.itemsList = m.top.FindNode("itemsList")
end function

sub OnContentChange() ' invoked when EpisodesScreen content is changed
    arr = m.top.content
    m.SubtitlesContentTask = createObject("RoSGNode","GetContentReader")
    m.SubtitlesContentTask.content = arr
    m.SubtitlesContentTask.observeField("content", "SubtitlesSet")
    m.SubtitlesContentTask.control = "RUN"
end sub

function SubtitlesSet()
    m.top.content = m.SubtitlesContentTask.content
    aa = DataSet(m.top.content.list)
    m.top.content.list = aa
    m.langlist = ConvertToContentNode(m.top.content.list)
    m.categoryList.content = m.langlist
    m.srtlist = ConvertToContentNode2(m.top.content.list[0].subtitles)
    m.itemsList.content = m.srtlist
end function

sub onVisibleChange() ' invoked when Episodes screen becomes visible
    if m.top.visible = true
        m.itemsList.setFocus(true) ' set focus to the episodes list
    end if
end sub

sub OnCategoryItemFocused()
    index = m.categoryList.itemFocused
    m.srtlist = ConvertToContentNode2(m.top.content.list[index].subtitles)
    m.itemsList.content = m.srtlist
end sub

function DataSet(Content as Object) as Object
    data = []
    i = 0
    for each subItem in Content
        data[i] = subItem
        j = 0
        for each key in subItem.subtitles
            key["index"] = j
            subItem.subtitles[j] = key
            j = j+1
        end for
        data[i] = subItem
        i = i+1
    end for
    return data
end function

function ConvertToContentNode(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.title = subItem.language
    end for
    return ContentNode
end function

function ConvertToContentNode2(Content as Object) as Object
    ContentNode = createObject("RoSGNode","ContentNode")
    for each subItem in Content
        parts = subItem.file_path.Split("/")
        fileName = parts[parts.Count() - 1]
        itemContent = ContentNode.createChild("ContentNode")
        itemContent.id = subItem.index
        itemContent.title = fileName
        ' itemContent.language = subItem.language
        itemContent.Description = subItem.file_path
    end for
    return ContentNode
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        ' handle "left" key press
        if key = "left" and m.itemsList.HasFocus() ' episodes list should be focused
            m.categoryListGainFocus = true
            ' navigate to seasons list
            m.categoryList.SetFocus(true)
            m.itemsList.drawFocusFeedback = false
            result = true
        ' handle "right" key press
        else if key = "right" and m.categoryList.HasFocus() ' seasons list should be focused
            m.itemsList.drawFocusFeedback = true
            ' navigate to episodes list
            m.itemsList.SetFocus(true)
            result = true
        else if key = "up"
            result = true
        end if
    end if
    return result
end function