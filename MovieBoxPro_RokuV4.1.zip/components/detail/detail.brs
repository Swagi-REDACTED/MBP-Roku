'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function makeMetaData()
    'database(DB) file loaction and its name
    ' DBdir = "pkg:/Database/"
    ' DBfile = DBdir + "Database.json"
    'Get artists data structure
    arr = m.top.content
    Content = getdetail(arr)
    ' print Content
    'Convert to content meta-data node  
    if Content <> ""
        arr = ParseJson(Content)
      else
        arr = {"code":0,"data":{}}
      end if
    if arr = invalid
        arr = {"data":{}}
    end if
    if arr.data = invalid
        arr.data = {}
    end if
    if arr.code <= 0
        arr.data = {}
    end if
    'return result by assigning it to top interface
    arr = ParseJson(Content)
    fontRegistry = CreateObject("roFontRegistry")
    fontRegistry.Register("pkg:/images/arial_unicode_ms.ttf")
    font = fontRegistry.GetFont("Arial Unicode MS", 32, false, false) ' 获取默认字体，大小为36
    text = arr.data.title
    textWidth = font.GetOneLineWidth(text, 700)
    arr.data["title_width"] = textWidth
    m.top.content = arr.data
end function


function getdetail(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    arr = CreateObject("roAssociativeArray")
    if data.box_type = 2 then
    arr["module"] = "TV_detail_1"
    arr["tid"] = data.mid
    arr["display_all"] = 1
    ' arr["season"] = "1"
    else
    arr["module"] = "Movie_detail"
    arr["mid"] = data.mid
    end if
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr["uid"] = uid
    if data.lang <> invalid
        arr["lang"] = data.lang
    else
        arr["lang"] = "en"
    end if
    arr["app_version"] = "6.0"
    arr["open_udid"] = udid

    if data.box_type = 2
        arr2 = CreateObject("roAssociativeArray")
        arr2["module"] = "TV_detail_playlist"
        arr2["uid"] = uid
        arr2["tid"] = data.mid
        arr2["open_udid"] = udid
        result2 = api(arr2)
    end if
      
    result = api(arr)
    if data.box_type = 2
        if result <> ""
            detail = ParseJson(result)
            if detail.data <> invalid
                if result2 <> ""
                    list = ParseJson(result2)
                    if list.data <> invalid
                        detail.data["playlist"] = list.data.playlist
                        result = FormatJson(detail)
                    end if
                end if
            end if
        end if
    end if
    if result <> ""
        detail = ParseJson(result)
        if detail <> invalid and detail.data <> invalid and detail.code > 0
            actorInfo = getActorList(data, 8)
            detail.data["actor_list"] = actorInfo.list
            detail.data["actor_total"] = actorInfo.total
            result = FormatJson(detail)
        end if
    end if
    return result
end function

function fetchActors()
    data = m.top.content
    pagelimit = 1000
    if data.pagelimit <> invalid
        pagelimit = data.pagelimit
    end if
    m.top.content = getActorList(data, pagelimit)
end function

function getActorList(data, pagelimit as Integer)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr = CreateObject("roAssociativeArray")
    if data.box_type = 2 then
        arr["module"] = "TV_actor"
        arr["tid"] = data.mid
    else
        arr["module"] = "Movie_actor"
        arr["mid"] = data.mid
    end if
    arr["uid"] = uid
    if data.lang <> invalid
        arr["lang"] = data.lang
    else
        arr["lang"] = "en"
    end if
    arr["page"] = 1
    arr["pagelimit"] = pagelimit
    arr["channel"] = "Website"
    arr["app_version"] = "3.7"
    arr["open_udid"] = udid

    result = api(arr)
    actorInfo = {"list": [], "total": 0}
    if result = ""
        return actorInfo
    end if
    parsed = ParseJson(result)
    if parsed = invalid or parsed.code <= 0 or parsed.data = invalid
        return actorInfo
    end if

    actors = parsed.data
    if parsed.total <> invalid
        actorInfo.total = parsed.total
    elseif parsed.count <> invalid
        actorInfo.total = parsed.count
    else
        actorInfo.total = actors.Count()
    end if

  for i = 0 to actors.Count() - 1
    actor = actors[i]
    if actor.avatar = invalid or actor.avatar = ""
      actor["new_name"] = getActorInitials(actor.name)
    end if
    actors[i] = actor
  end for

    actorInfo.list = actors
    return actorInfo
end function

function getActorInitials(name as String) as String
    if name = invalid or name = ""
        return "?"
    end if
    words = name.Tokenize(" ")
    initials = ""
    for i = 0 to words.Count() - 1
        if i >= 2
            exit for
        end if
        if Len(words[i]) > 0
            initials = initials + Left(words[i], 1)
        end if
    end for
    if initials = ""
        return "?"
    end if
    return UCase(initials)
end function

function fetchActorDetail()
    data = m.top.content
    m.top.content = getActorDetail(data)
end function

function getActorDetail(data)
    deviceinfo = CreateObject("roDeviceInfo")
    udid = deviceinfo.GetChannelClientId()
    user = CreateObject("roRegistrySection", "User")
    uid = user.Read("uid_v2")
    arr = CreateObject("roAssociativeArray")
    arr["module"] = "Actor"
    arr["actor_id"] = data.actor_id
    arr["uid"] = uid
    arr["platform"] = "web"
    if data.lang <> invalid and data.lang <> ""
        arr["lang"] = data.lang
    else
        arr["lang"] = "en"
    end if
    arr["app_version"] = "6.0"
    arr["open_udid"] = udid

    result = api(arr)
    empty = {"code": 0, "data": {}}
    if result = ""
        return empty
    end if
    parsed = ParseJson(result)
    if parsed = invalid or parsed.code <= 0 or parsed.data = invalid
        return empty
    end if
    if parsed.data.actor <> invalid
        actor = parsed.data.actor
        if actor.avatar = invalid or actor.avatar = ""
            actor["new_name"] = getActorInitials(actor.name)
            parsed.data.actor = actor
        end if
    end if
    return parsed
end function

function api(arr)
    return mbpApiV2(arr)
end function