' Child mode helpers (aligned with MBP web childmode API parameter)

function getChildModeEnabled() as Boolean
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("child_mode") = true and user.Read("child_mode") = "1"
        return true
    end if
    return false
end function

function getSuperChildModeEnabled() as Boolean
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("super_child_mode") = true and user.Read("super_child_mode") = "1"
        return true
    end if
    return false
end function

function hasChildModePassword() as Boolean
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("child_mode_pwd") = true and user.Read("child_mode_pwd") <> ""
        return true
    end if
    return false
end function

function getChildModePassword() as String
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("child_mode_pwd") = true
        return user.Read("child_mode_pwd")
    end if
    return ""
end function

function setChildModePassword(pwd as String)
    user = CreateObject("roRegistrySection", "User")
    user.Write("child_mode_pwd", pwd)
    user.Flush()
end function

function setChildModeEnabled(enabled as Boolean)
    user = CreateObject("roRegistrySection", "User")
    if enabled
        user.Write("child_mode", "1")
    else
        user.Write("child_mode", "0")
        user.Write("super_child_mode", "0")
    end if
    user.Write("child_mode_dirty", "1")
    user.Flush()
end function

function setSuperChildModeEnabled(enabled as Boolean)
    user = CreateObject("roRegistrySection", "User")
    if enabled
        user.Write("super_child_mode", "1")
        user.Write("child_mode", "1")
    else
        user.Write("super_child_mode", "0")
    end if
    user.Write("child_mode_dirty", "1")
    user.Flush()
end function

function getChildModeApiValue() as Integer
    if getChildModeEnabled() = false
        return 0
    end if
    if getSuperChildModeEnabled() = true
        return 2
    end if
    return 1
end function

function applyChildModeToRequest(arr as Object) as Object
    if arr.module = "Add_captcha" or arr.module = "Login_captcha_v2" or arr.module = "Device_v2"
        return arr
    end if
    arr["childmode"] = getChildModeApiValue()
    return arr
end function

function hasLoginUserData(data as Dynamic) as Boolean
    if data = invalid
        return false
    end if
    if Type(data) <> "roAssociativeArray"
        return false
    end if
    if data.DoesExist("uid") = false
        return false
    end if
    return data.uid <> invalid
end function

function captchaCodeToString(code as Dynamic) as String
    if code = invalid
        return ""
    end if
    if GetInterface(code, "ifString") <> invalid
        return code
    end if
    t = Type(code)
    if t = "String" or t = "roString"
        return code
    end if
    if t = "Integer" or t = "roInt" or t = "LongInteger" or t = "Float" or t = "Double" or t = "Boolean"
        return code.ToStr()
    end if
    ' last resort for unexpected scalar types from JSON/SG fields
    s = FormatJson(code)
    if s = invalid or s = ""
        return ""
    end if
    if Len(s) >= 2 and Left(s, 1) = Chr(34) and Right(s, 1) = Chr(34)
        return Mid(s, 2, Len(s) - 2)
    end if
    return s
end function

function isLoginApiResponse(content as Object) as Boolean
    if content = invalid
        return false
    end if
    if content.type <> invalid
        return false
    end if
    if content.code = invalid
        return false
    end if
    if content.code.ToStr() <> "1"
        return false
    end if
    return hasLoginUserData(content.data)
end function

function verifyChildModePassword(pwd as String) as Boolean
    if hasChildModePassword() = false
        return true
    end if
    return pwd = getChildModePassword()
end function

function childModeStatusText() as String
    if getChildModeEnabled() = false
        return "Off"
    end if
    if getSuperChildModeEnabled() = true
        return "Super On"
    end if
    return "On"
end function

function superChildModeStatusText() as String
    if getSuperChildModeEnabled() = true
        return "On"
    end if
    return "Off"
end function

function isLoginExpiredCode(code as Dynamic) as Boolean
    if code = invalid
        return false
    end if
    codeStr = code.ToStr()
    return codeStr = "-10001" or codeStr = "-10022"
end function

function shouldSkipLoginExpiryCheck(module as Dynamic) as Boolean
    if module = invalid
        return false
    end if
    moduleStr = module.ToStr()
    if moduleStr = "Add_captcha" or moduleStr = "Login_captcha_v2" or moduleStr = "Srttrans_v4"
        return true
    end if
    return false
end function

sub clearLoginUserInfo()
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("uid") = false and user.Exists("uid_v2") = false
        return
    end if
    sessionStore = CreateObject("roRegistrySection", "ApiSessionV2")
    sessionStore.Delete(user.Read("uid"))
    sessionStore.Flush()
    user.Delete("uid")
    user.Delete("uid_v2")
    user.Delete("appid")
    user.Delete("avatar")
    user.Delete("bind_gmail")
    user.Delete("email")
    user.Delete("family")
    user.Delete("isvip")
    user.Delete("nickname")
    user.Delete("username")
    user.Delete("dead_time")
    user.Flush()
end sub

sub notifyLoginExpired()
    scene = m.top.getScene()
    if scene <> invalid
        scene.forceRelogin = true
    end if
end sub

function processApiResponse(response as String, module as Dynamic) as String
    if response = "" or shouldSkipLoginExpiryCheck(module) = true
        return response
    end if
    if looksLikeNdjson(response) = true
        return response
    end if
    parsed = ParseJson(response)
    if parsed = invalid or parsed.code = invalid
        return response
    end if
    if isLoginExpiredCode(parsed.code) = true
        clearLoginUserInfo()
        notifyLoginExpired()
    end if
    return response
end function

function looksLikeNdjson(raw as String) as Boolean
    if raw = invalid or raw = ""
        return false
    end if
    if Instr(1, raw, "}" + chr(10) + "{") > 0
        return true
    end if
    if Instr(1, raw, "}" + chr(13) + chr(10) + "{") > 0
        return true
    end if
    if Instr(1, raw, "}{") > 0
        return true
    end if
    if Instr(1, raw, chr(34) + "type" + chr(34) + ":" + chr(34) + "meta" + chr(34)) > 0
        return true
    end if
    if Instr(1, raw, chr(34) + "type" + chr(34) + ":" + chr(34) + "cues" + chr(34)) > 0
        return true
    end if
    if Instr(1, raw, chr(34) + "type" + chr(34) + ":" + chr(34) + "ping" + chr(34)) > 0
        return true
    end if
    closePos = Instr(1, raw, "}")
    if closePos > 0 and Instr(closePos + 1, raw, "{") > 0
        return true
    end if
    return false
end function
