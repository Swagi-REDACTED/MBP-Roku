'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.code = m.top.findNode("code")
    m.message = m.top.findNode("loginMessage")
    m.expire = m.top.findNode("expire_bg")
    m.refresh = m.top.findNode("Refresh")
    m.refresh.setFocus(true)
    m.refresh.observeField("itemSelected","refreshCode")

    arr = {"type":"code"}
    m.codeContentTask = createObject("RoSGNode","GetContentReader")
    m.codeContentTask.content = arr
    m.codeContentTask.observeField("content", "setCode")
    m.codeContentTask.control = "RUN"
end function

sub setCode()
    content = m.codeContentTask.content

    if content = invalid or content.type = "code"
        return
    end if
    if content.login_error <> invalid and content.login_error <> ""
        m.code.text = ""
        m.message.text = content.login_error
        m.expire.visible = true
        m.refresh.setFocus(true)
        return
    end if
    codeStr = captchaCodeToString(content.code)
    if codeStr = ""
        return
    end if
    m.expire.visible = false
    m.code.text = codeStr

    m.timer2 = CreateObject("roSGNode", "Timer")
    m.timer2.duration = 300
    m.timer2.repeat = false
    m.timer2.control = "start"
    m.timer2.ObserveField("fire","expire")

    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 3
    m.timer.repeat = true
    m.timer.control = "start"
    m.timer.ObserveField("fire","changeLogin")
end sub

sub expire()
    m.code.text = ""
    m.message.text = "Code Expired"
    m.expire.visible = true
    m.refresh.setFocus(true)
end sub

sub refreshCode()
    arr = {"type":"code"}
    m.codeContentTask = createObject("RoSGNode","GetContentReader")
    m.codeContentTask.content = arr
    m.codeContentTask.observeField("content", "setCode2")
    m.codeContentTask.control = "RUN"
end sub

sub setCode2()
    content = m.codeContentTask.content

    if content = invalid or content.type = "code"
        return
    end if
    if content.login_error <> invalid and content.login_error <> ""
        m.code.text = ""
        m.message.text = content.login_error
        m.expire.visible = true
        m.refresh.setFocus(true)
        return
    end if
    codeStr = captchaCodeToString(content.code)
    if codeStr = ""
        return
    end if
    m.expire.visible = false
    m.code.text = codeStr

    if m.timer2 <> invalid
        m.timer2.control = "stop"
    end if
    m.timer2 = CreateObject("roSGNode", "Timer")
    m.timer2.duration = 300
    m.timer2.repeat = false
    m.timer2.control = "start"
    m.timer2.ObserveField("fire","expire")
end sub

sub changeLogin()
    if m.loginCheckInFlight = true
        return
    end if
    if m.code.text = invalid or m.code.text = ""
        return
    end if
    m.loginCheckInFlight = true
    arr = {"type":"logincode","code":m.code.text}
    m.loginContentTask = createObject("RoSGNode","GetContentReader")
    m.loginContentTask.content = arr
    m.loginContentTask.observeField("content", "loginInfo")
    m.loginContentTask.control = "RUN"
end sub

sub loginInfo()
    m.loginCheckInFlight = false
    if m.loginContentTask = invalid
        return
    end if
    content = m.loginContentTask.content
    if isLoginApiResponse(content) = false
        return
    end if
    m.timer.control = "stop"
        user = CreateObject("roRegistrySection", "User")
        user.Write("uid",content.data.uid.Tostr())
        user.Write("uid_v2",content.data.uid_v2)
        ' user.Write("uid_token",content.data.uid_token)
        user.Write("appid",content.data.appid)
        user.Write("avatar",content.data.avatar)
        user.Write("bind_gmail",content.data.bind_gmail)
        user.Write("email",content.data.email)
        user.Write("family",content.data.family.Tostr())
        user.Write("isvip",content.data.isvip.Tostr())
        user.Write("nickname",content.data.nickname)
        user.Write("username",content.data.username)
        user.Write("dead_time",content.data.dead_time.Tostr())

        user2 = content.data
        userinfo = {"uid":user2.uid,"uid_v2":user2.uid_v2,"appid":user2.appid,"avatar":user2.avatar,"bind_gmail":user2.bind_gmail,"email":user2.email,"family":user2.family,"isvip":user2.isvip,"nickname":user2.nickname,"username":user2.username,"dead_time":user2.dead_time}
        accounts = CreateObject("roRegistrySection", "accounts")
        if accounts.Exists("list") = false
          accounts.Write("list",FormatJson([userinfo]))
        else
          list = accounts.Read("list")
          list = ParseJson(list)
          status = 0
          for each key in list
            if key.uid = user2.uid
              status = 1
            end if
          end for
          if status = 0
            list.Push(userinfo)
            accounts.Write("list",FormatJson(list))
          end if
        end if

        arr = {"type":"device"}
        m.deviceTask = createObject("RoSGNode","GetContentReader")
        m.deviceTask.content = arr
        m.deviceTask.control = "RUN"

        m.top.new_uid = user2.uid
end sub