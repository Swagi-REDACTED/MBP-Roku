'********** Copyright 2016 Roku Corp.  All Rights Reserved. **********

function init()
    m.list = m.top.findNode("list")
    m.accountbg = m.top.findNode("accountbg")
    m.userlist = m.top.findNode("userlist")
    m.server_bg = m.top.findNode("server_bg")
    m.serverlist = m.top.findNode("serverlist")
    m.serverlist.ObserveField("itemSelected", "select_server")

    m.list.content = buildSettingList()
    m.list.ObserveField("itemSelected", "getuser_list")
    
    m.list.setFocus(true)
end function

function buildSettingList() as Object
    user = CreateObject("roRegistrySection", "User")
    avatar = user.Read("avatar")
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    child.title = "Manage Accounts"
    child.hdposterurl = "pkg:/images/account2.png"
    child.Description = avatar
    child = contentRoot.createChild("ContentNode")
    child.title = "Choose Server"
    child = contentRoot.createChild("ContentNode")
    child.title = "Child Mode"
    child.hdposterurl = "pkg:/images/list_icon.png"
    if getChildModeEnabled() = true
        child.title = "Child Mode: On"
    else
        child.title = "Child Mode: Off"
    end if
    child = contentRoot.createChild("ContentNode")
    child.hdposterurl = "pkg:/images/key_tip.png"
    if user.Exists("skip_intro_outro") and user.Read("skip_intro_outro") = "0"
        child.title = "Skip Intro/Outro: Off"
    else
        child.title = "Skip Intro/Outro: On"
    end if
    return contentRoot
end function

sub getuser_list()
    index = m.list.itemSelected
    if index = 0
        user = CreateObject("roRegistrySection", "User")
        contentRoot = createObject("roSGNode", "ContentNode")
        child = contentRoot.createChild("ContentNode")
        child.title = user.Read("username")
        child.hdposterurl = user.Read("avatar")
        isvip = user.Read("isvip").ToInt()
        family = user.Read("family").ToInt()
        data = CreateObject("roAssociativeArray")
        if isvip = 1 or family > 0
            dead_time = user.Read("dead_time").ToInt()
            date = CreateObject("roDateTime")
            date.FromSeconds(dead_time)
            time = date.asDateStringLoc("dd-MM-y")
            data["vip"] = 1
            child.Description = "Expire date: "+time
        else
            data["vip"] = 0
            child.Description = "Not a VIP"
        end if
        data["uid"] = user.Read("uid").ToInt()
        child.shortdescriptionline1 = "true"
        child.addField("data", "assocarray", false)
        child.data = data

        accounts = CreateObject("roRegistrySection", "accounts")
        list = accounts.Read("list")
        list = ParseJson(list)
        for each item in list
            if user.Read("uid") <> item.uid.Tostr()
                child = contentRoot.createChild("ContentNode")
                child.title = item.username
                child.hdposterurl = item.avatar
                data2 = CreateObject("roAssociativeArray")
                if item.isvip = 1 or item.family > 0
                    dead_time = item.dead_time
                    date = CreateObject("roDateTime")
                    date.FromSeconds(dead_time)
                    time = date.asDateStringLoc("dd-MM-y")
                    child.Description = "Expire date: "+time
                    data2["vip"] = 1
                else
                    data2["vip"] = 0
                    child.Description = "Not a VIP"
                end if
                data2["uid"] = item.uid
                child.shortdescriptionline1 = "false"
                child.addField("data", "assocarray", false)
                child.data = data2
            end if
        end for
        child = contentRoot.createChild("ContentNode")
        child.title = "Add New Account"
        child.hdposterurl = "pkg:/images/add_user.png"
        child.Description = "add"
        m.userlist.content = contentRoot
        m.userlist.setFocus(true)
        m.accountbg.visible = true
    elseif index = 1
        arr = {"type":"server_list"}
        m.serverTask = createObject("RoSGNode","GetContentReader")
        m.serverTask.content = arr
        m.serverTask.observeField("content", "serverlist")
        m.serverTask.control = "RUN"
    elseif index = 2
        child_mode = createObject("roSGNode", "ChildMode")
        child_mode.id = "child_mode"
        m.top.appendChild(child_mode)
        m.child_mode = m.top.findNode("child_mode")
        m.child_mode.observeField("changed", "onChildModeChanged")
        m.child_mode.setFocus(true)
    elseif index = 3
        user = CreateObject("roRegistrySection", "User")
        if user.Exists("skip_intro_outro") and user.Read("skip_intro_outro") = "0"
            user.Write("skip_intro_outro", "1")
        else
            user.Write("skip_intro_outro", "0")
        end if
        m.list.content = buildSettingList()
        m.list.setFocus(true)
    end if
end sub

sub onChildModeChanged()
    if m.child_mode.changed = true
        m.top.removeChild(m.child_mode)
        m.child_mode = invalid
        user = CreateObject("roRegistrySection", "User")
        user.Write("child_mode_dirty", "1")
        m.list.content = buildSettingList()
        m.list.setFocus(true)
    end if
end sub

function serverlist()
    if m.serverTask.content.type <> invalid
        return false
    end if
    if m.serverTask.content = invalid or m.serverTask.content.code <= 0
        return false
    end if

    select_server2 = "0"
    user = CreateObject("roRegistrySection", "User")
    if user.Exists("select_server") = true
        select_server2 = user.Read("select_server")
    end if

    content = m.serverTask.content
    ContentNode = createObject("RoSGNode","ContentNode")
    for each key in content.data.our
        ItemContent = ContentNode.createChild("ContentNode")
        ItemContent.title = key.country
        ItemContent.Description = key.description
        if key.group_id = select_server2
            ItemContent.shortdescriptionline1 = "true"
        end if
        data = CreateObject("roAssociativeArray")
        data["group_id"] = key.group_id
        ItemContent.addField("data", "assocarray", false)
        ItemContent.data = data
    end for

    m.serverlist.content = ContentNode
    m.server_bg.visible = true
    m.serverlist.setFocus(true)
end function

sub select_server()
    item = m.serverlist.content.getChild(m.serverlist.itemSelected)
    user = CreateObject("roRegistrySection", "User")
    user.Write("select_server", item.data.group_id)
    for i = 0 to m.serverlist.content.getChildCount() - 1
        server = m.serverlist.content.getChild(i)
        server.update({"shortdescriptionline1":"false"}, false)
    end for
    item.update({"shortdescriptionline1":"true"}, false)
end sub

function searchToContentNode2(Content as Object) as Object
    arr = []
    if m.type = "playlists"
        for each key in Content
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.name
            ItemContent.hdposterurl = key.imgArr[0]
            data = CreateObject("roAssociativeArray")
            data["lid"] = key.lid
            data["count"] = key.count
            data["box_type"] = 3
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
    else
        for each key in Content
            ItemContent = createObject("RoSGNode","ContentNode")
            ItemContent.title = key.title
            ItemContent.hdposterurl = key.poster
            data = CreateObject("roAssociativeArray")
            data["mid"] = key.id
            data["box_type"] = key.box_type
            data["imdb_rating"] = key.imdb_rating
            data["tomato_meter"] = key.tomato_meter
            if key.tomato_meter_state <> invalid
                data["tomato_meter_state"] = key.tomato_meter_state
            else
                data["tomato_meter_state"] = ""
            end if
            if key.box_type = 2
                if key.season_episode <> invalid
                    data["season_episode"] = key.season_episode
                end if
            else
                if key.quality_tag <> invalid
                    data["quality_tag_new"] = key.quality_tag
                end if
            end if
            ItemContent.addField("data", "assocarray", false)
            ItemContent.data = data
            arr.Push(ItemContent)
        end for
    end if
    return arr
end function

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "back" then
            if m.accountbg.visible = true
                m.accountbg.visible = false
                m.list.setFocus(true)
                result = true
            end if
            if m.server_bg.visible = true
                m.server_bg.visible = false
                m.list.setFocus(true)
                result = true
            end if
            if m.child_mode <> invalid and m.child_mode.visible = true
                m.top.removeChild(m.child_mode)
                m.child_mode = invalid
                m.list.setFocus(true)
                result = true
            end if
        end if
    end if
    return result
end function