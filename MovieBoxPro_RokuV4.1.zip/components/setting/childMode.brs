function init()
    m.list = m.top.findNode("list")
    m.pin_bg = m.top.findNode("pin_bg")
    m.pin_title = m.top.findNode("pin_title")
    m.pin_display = m.top.findNode("pin_display")
    m.pin_error = m.top.findNode("pin_error")
    m.pin_pad = m.top.findNode("pin_pad")
    m.pin_pad.observeField("itemSelected", "pinKeySelected")
    m.list.observeField("itemSelected", "onItemSelected")
    m.pinInput = ""
    m.pendingAction = ""
    m.top.changed = false
    refreshList()
    m.list.setFocus(true)
end function

sub refreshList()
    contentRoot = createObject("roSGNode", "ContentNode")
    child = contentRoot.createChild("ContentNode")
    if getChildModeEnabled() = true
        child.title = "Child Mode: On"
    else
        child.title = "Child Mode: Off"
    end if
    child.hdposterurl = "pkg:/images/account2.png"
    child = contentRoot.createChild("ContentNode")
    child.title = "Set Password"
    child.hdposterurl = "pkg:/images/add_user.png"
    m.list.content = contentRoot
end sub

sub onItemSelected()
    index = m.list.itemSelected
    if index = 0
        toggleChildMode()
    elseif index = 1
        startSetPassword()
    end if
end sub

sub toggleChildMode()
    if getChildModeEnabled() = true
        m.pendingAction = "disable_child"
        openPinDialog("Enter password to turn off Child Mode")
    else
        if hasChildModePassword() = false
            startSetPassword()
            return
        end if
        m.pendingAction = "enable_child"
        openPinDialog("Enter password to turn on Child Mode")
    end if
end sub

sub startSetPassword()
    m.pendingAction = "set_password"
    m.pinInput = ""
    m.pin_display.text = ""
    m.pin_error.visible = false
    m.pin_title.text = "Set 4-digit password"
    buildPinPad()
    m.pin_bg.visible = true
    m.pin_pad.setFocus(true)
end sub

sub openPinDialog(title as String)
    m.pinInput = ""
    m.pin_display.text = ""
    m.pin_error.visible = false
    m.pin_title.text = title
    buildPinPad()
    m.pin_bg.visible = true
    m.pin_pad.setFocus(true)
end sub

sub buildPinPad()
    contentRoot = createObject("roSGNode", "ContentNode")
    keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "Clear", "0", "OK"]
    for each key in keys
        child = contentRoot.createChild("ContentNode")
        child.title = key
    end for
    m.pin_pad.content = contentRoot
end sub

sub pinKeySelected()
    key = m.pin_pad.content.getChild(m.pin_pad.itemSelected).title
    if key = "Clear"
        m.pinInput = ""
        m.pin_display.text = ""
        m.pin_error.visible = false
        return
    end if
    if key = "OK"
        submitPin()
        return
    end if
    if m.pinInput.Len() < 4
        m.pinInput = m.pinInput + key
        m.pin_display.text = maskPin(m.pinInput)
    end if
end sub

function maskPin(pwd as String) as String
    masked = ""
    for i = 1 to pwd.Len()
        masked = masked + "*"
    end for
    return masked
end function

sub submitPin()
    if m.pendingAction = "set_password"
        if m.pinInput.Len() <> 4
            m.pin_error.text = "Password must be 4 digits"
            m.pin_error.visible = true
            return
        end if
        setChildModePassword(m.pinInput)
        setChildModeEnabled(true)
        m.top.changed = true
        closePinDialog()
        refreshList()
        return
    end if

    if m.pinInput.Len() <> 4
        m.pin_error.text = "Password must be 4 digits"
        m.pin_error.visible = true
        return
    end if
    if verifyChildModePassword(m.pinInput) = false
        m.pin_error.text = "Incorrect password"
        m.pin_error.visible = true
        m.pinInput = ""
        m.pin_display.text = ""
        return
    end if

    if m.pendingAction = "disable_child"
        setChildModeEnabled(false)
    elseif m.pendingAction = "enable_child"
        setChildModeEnabled(true)
    end if
    m.top.changed = true
    closePinDialog()
    refreshList()
end sub

sub closePinDialog()
    m.pendingAction = ""
    m.pinInput = ""
    m.pin_bg.visible = false
    m.list.setFocus(true)
end sub

function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        if key = "back"
            if m.pin_bg.visible = true
                closePinDialog()
                result = true
            end if
        end if
    end if
    return result
end function
